package com.abb.uiautomation.core.report;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.abb.uiautomation.core.log.TestLogger;


	public class ExtentsReport {

		//static  ExcelReader reader=new ExcelReader(EnvironmentManager.getExcelConfigSheetName().trim());
		//static  String htmlreportLocation=reader.getValuefromConfigExcel("htmlreport");
		static String htmlreportLocation = "C:\\ABBAutomation_POM\\src\\main\\resources\\Reports";
		static ExtentReports report;
		public static  ExtentTest test;
		

		public static ExtentReports getReportObj() {
			return report; 
		}


		public static ExtentTest  getExtentTestObj(){
			return test;
		}
		/*
		    * This method is used to configure the report before test execution starts
		    */

		public static   ExtentReports configureReport() {
			try 
			{
					report=new ExtentReports(new File(htmlreportLocation)+"\\ExtentReportResult.html");
					report.loadConfig(new File(System.getProperty("user.dir")+"\\extent-config.xml"));	
					System.out.println("  $$$$$$      In configureReport      $$$$$$  " + report.getProjectName());
					System.out.println("  $$$$$$      In reportLocation      $$$$$$  " + htmlreportLocation + "\\ExtentReportResult.html");
					System.out.println("  $$$$$$      In reportConfig      $$$$$$  " + System.getProperty("user.dir")+"\\extent-config.xml");
				}
			catch(Exception e)
			{
					String nameofCurrMethod = new Throwable().getStackTrace()[0].getMethodName();
					TestLogger.errorMessage(" Method Name is : " + nameofCurrMethod
							+ "An exception occured while configuring report:" + e.getMessage());
					Reporter.log(" Method Name is : " + nameofCurrMethod
							+ "An exception occured while configuring report:" + e.getMessage());
			}
			return report;
		}
		
		
		/*
		    * This method is used to log the Fail message in Report
		    */
		public static void testFail(String methodName) {
			try {
				test.log(LogStatus.FAIL, methodName);
			}
			catch(Exception e) {

				String nameofCurrMethod = new Throwable().getStackTrace()[0].getMethodName();
				TestLogger.errorMessage(" Method Name is : " + nameofCurrMethod
						+ "An exception occured when logging fail status in report: " + e.getMessage());
				Reporter.log(" Method Name is : " + nameofCurrMethod
						+ "An exception occured when logging fail status in report: " + e.getMessage());	
			}
		}
		/*
		    * This method is used to log test name  message in Report
		    */
		public static void startTest(String testName) {
			try {
				test= report.startTest(testName);
				System.out.println("  $$$$$$      In configureReport startTest     $$$$$$  " + test.getTest().getName());
			}
			catch(Exception e) {

				String nameofCurrMethod = new Throwable().getStackTrace()[0].getMethodName();
				TestLogger.errorMessage(" Method Name is : " + nameofCurrMethod
						+ "An exception occured when logging start status in report:" + e.getMessage());
				Reporter.log(" Method Name is : " + nameofCurrMethod
						+ "An exception occured when logging start status in report: " + e.getMessage());
			}

		}
		/*
		    * This method is used to log the Info message in Report
		    */

		public static void testInfo(String testName) {
			try {
				test.log(LogStatus.INFO, testName);
			}
			catch(Exception e) {
				String nameofCurrMethod = new Throwable().getStackTrace()[0].getMethodName();
				TestLogger.errorMessage(" Method Name is : " + nameofCurrMethod
						+ "An exception occured when logging Info status in report: " + e.getMessage());
				Reporter.log(" Method Name is : " + nameofCurrMethod
						+ "An exception occured when logging Info status in report: " + e.getMessage());		
			}
		}
		
		/*
		    * This method is used to log the Error message in Report
		    */
		public static void testError(String testName) {
			try {
				test.log(LogStatus.ERROR, testName);
			}
			catch(Exception e) {

				String nameofCurrMethod = new Throwable().getStackTrace()[0].getMethodName();
				TestLogger.errorMessage(" Method Name is : " + nameofCurrMethod
						+ "An exception occured when logging fail Error in report: " + e.getMessage());
				Reporter.log(" Method Name is : " + nameofCurrMethod
						+ "An exception occured when logging Error status in report: " + e.getMessage());	
			}

		}
		
		public static String getScreenshot(WebDriver driver, String screenshotName) throws Exception {
			String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
	                //after execution, you could see a folder "FailedTestsScreenshots" under src folder
			//String destination = System.getProperty("user.dir") + "/FailedTestsScreenshots/"+screenshotName+dateName+".png";
			String destination = "C:\\ABBAutomation_POM\\src\\main\\resources\\Reports\\TestSceenshots\\"+screenshotName+dateName+".png";
			
			File finalDestination = new File(destination);
			FileUtils.copyFile(source, finalDestination);
			return destination;
		}
		
		public static void attachScreenshot(WebDriver driver, String screenshotName)
		{
			 String screenshotPath = null;
			try {
				screenshotPath = getScreenshot(driver, screenshotName);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				//To add it in the extent report
			 test.log(LogStatus.PASS, screenshotPath);
		}
		
		   /*
		    * This method is used to log the Warning message in Report
		    */

		public static void testWarnMessage(String testName) {
			try {
				test.log(LogStatus.WARNING, testName);
			}
			catch(Exception e) {

				String nameofCurrMethod = new Throwable().getStackTrace()[0].getMethodName();
				TestLogger.errorMessage(" Method Name is : " + nameofCurrMethod
						+ "An exception occured when logging Warning status in report: " + e.getMessage());
				Reporter.log(" Method Name is : " + nameofCurrMethod
						+ "An exception occured when logging Warning status in report: " + e.getMessage());	
			}
		}
	   /*
	    * This method is used to log the pass message in Report
	    */
		public static void testPasedMessage(String testName) {
			try {
				test.log(LogStatus.PASS, testName);
			}
			catch(Exception e){
				String nameofCurrMethod = new Throwable().getStackTrace()[0].getMethodName();
				TestLogger.errorMessage(" Method Name is : " + nameofCurrMethod
						+ "An exception occured when logging Pass status in report: " + e.getMessage());
				Reporter.log(" Method Name is : " + nameofCurrMethod
						+ "An exception occured when logging Pass status in report: " + e.getMessage());	

			}
		}
		
	   /*
	    * This Method is used to flush once Test Execution is Finished
	    */
		public static void endTest() {
			try {
				//	report.endTest(test);
				System.out.println("  $$$$$$      In configureReport endTest     $$$$$$  ");
				report.flush();
			}
			catch(Exception e) {
				String nameofCurrMethod = new Throwable().getStackTrace()[0].getMethodName();
				Reporter.log(" Method Name is : " + nameofCurrMethod
						+ " ,An exception occured while flushing  report:" + e.getMessage());
				TestLogger.errorMessage(" Method Name is : " + nameofCurrMethod
						+ " ,An exception occured while flushing  report:" + e.getMessage());
			}
		}



	  /*
	   * Thi method is used to get the method resuslt once its executed
	   */
		public static void getResult(ITestResult result, String methodName) {

			try {
				if (result.getStatus() == ITestResult.FAILURE) {
					test.log(LogStatus.FAIL, "Test case Failed check the details in Test Runner logs Tab or Lo4j logs");

					//test.log(LogStatus.WARNING, "API Log Link : <a href='logslocation'>API LINK</a>");
					int counter=1;
					for (String logs : Reporter.getOutput()) {
						report.setTestRunnerOutput(counter+". "+logs);
						System.out.print("");
						counter++;
					}

				} else if (result.getStatus() == ITestResult.SUCCESS) {
					//test.log(LogStatus.PASS, methodName + " PASSED");
					int counter=1;
					for (String logs : Reporter.getOutput()) {
						report.setTestRunnerOutput(counter+". "+logs);
						System.out.print("");
						counter++;

					}

				} else if(result.getStatus()==ITestResult.SKIP){
					test.log(LogStatus.SKIP, " Test Skipped");
					int counter=1;
					for (String logs : Reporter.getOutput()) {
						report.setTestRunnerOutput(counter+". "+logs);
						System.out.print("");
						counter++;

					}


				}
			} catch (Exception e) {
				String nameofCurrMethod = new Throwable().getStackTrace()[0].getMethodName();
				TestLogger.errorMessage("Method Name is : " + nameofCurrMethod
						+ " ,An exception occured while getting result:" + e.getMessage());
				Reporter.log("Method Name is : " + nameofCurrMethod
						+ " ,An exception occured while getting result:" + e.getMessage());


			}
		}



	}

