package com.abb.uiautomation.core.pages.SAD;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.HashMap;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.utils.WebDriverManager;

//import junit.framework.Assert;

public class SADEquipmentMappingPage extends WebDriverManager{
	
	public SADEquipmentMappingPage() {
		
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
		}
	JavascriptExecutor jse = (JavascriptExecutor)driver;
	
	@FindBy(xpath = "(//div/span[text()='India > Region-4 > Plant 20 - Pulp & Paper Business'])[1]")
	public WebElement lbl_Location;
	
	@FindBy(xpath = "//html/body/app-root/div[2]/app-detail/div[2]/iframe")
	public WebElement iframeElement;
	
	//@FindBy(xpath = "//div[text()=' Search Type:']/following::input[1]")
	@FindBy(xpath = "(//input[@placeholder='Select Search Type'])[1]")		
	public WebElement SearchType;
	
	@FindBy(xpath = "//span[text()=' Description ']")
	public WebElement DescriptionCheckBox;
	
	@FindBy(xpath = "//span[text()=' Code ']")
	public WebElement CodeCheckBox;
	
	@FindBy(xpath = "//span[text()=' Name ']")
	public WebElement NameCheckBox;
	
	@FindBy(xpath = "//span[text()=' Object Type ']")
	public WebElement ObjectTypeCheckBox;
	
	@FindBy(xpath = "//span[text()=' PID Tag ']")
	public WebElement PIDTagCheckBox;
	
	@FindBy(xpath = "//div[.=' Search Equipment:']/following::input[1]")
	public WebElement SearchEquipmentTextBox;
	
	@FindBy(xpath ="//div[.=' Search Equipment:']/following::button[1]")
	public WebElement SearchButton;
	
	@FindBy(xpath="//div[.=' Search Results ']//following::span[.=' Select All ']/preceding::label[1]")
	public WebElement SelectAllCheckBox;
	
	@FindBy(xpath="//app-system-equipments//div[2]/div[3]/button")
	public WebElement AddEquipmentButton;
	
	@FindBy(xpath="//span[text()=' Save ']")
	public WebElement SaveButton;
	
	public void CreateSADEquipmentMapping(HashMap<String, String> parameterMap) throws InterruptedException
	{
		
		WebElement ele = null;
		System.out.println("Moved to frame title");

		System.out.println("Moved to frame");
		try 
		{
			Thread.sleep(5000);
		} catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ele = new WebDriverWait(driver, 90).until(ExpectedConditions.visibilityOf(SearchType));
		if (ele.isDisplayed())
		{
			System.out.println("-----CreateSADEquipmentMapping---- SearchType Element Dispalyed");
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].click()", ele);
			ExtentsReport.testInfo("SADEquipmentMappingPage Clicked on SerachType Successful");
		}
		else
		{
			System.out.println("-----CreateSADEquipmentMapping---- SearchType Element Dispalyed");
		}
		
		if (parameterMap.get("Description").equalsIgnoreCase("yes")) 
		{
			DescriptionCheckBox.click();
			ExtentsReport.testInfo("SADEquipmentMappingPage Clicked on Decsription Checkbox Successful");
		}
		if (parameterMap.get("Code").equalsIgnoreCase("yes")) 
		{
			CodeCheckBox.click();
			ExtentsReport.testInfo("SADEquipmentMappingPage Clicked on Code Checkbox Successful");
		}
		if (parameterMap.get("Name").equalsIgnoreCase("yes"))
		{
			NameCheckBox.click();
			ExtentsReport.testInfo("SADEquipmentMappingPage Clicked on Name Checkbox Successful");
		}
		if (parameterMap.get("ObjectType").equalsIgnoreCase("yes"))
		{
			ObjectTypeCheckBox.click();
			ExtentsReport.testInfo("SADEquipmentMappingPage Clicked on ObjectType Checkbox Successful");
		}
		if (parameterMap.get("PIDTag").equalsIgnoreCase("yes"))
		{
			PIDTagCheckBox.click();
			ExtentsReport.testInfo("SADEquipmentMappingPage Clicked on PID Checkbox Successful");
		}
		
		SearchEquipmentTextBox.sendKeys(parameterMap.get("SearchEquipment"));
		ExtentsReport.testInfo("SADEquipmentMappingPage Entered " + parameterMap.get("SearchEquipment") +" into 'Search Equipment' Successful");
		
		//SearchButton.click();
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", SearchButton);
		ExtentsReport.testInfo("SADEquipmentMappingPage Clicked on 'Search' Button Successful");
		
		if (parameterMap.get("SelectAll").equalsIgnoreCase("yes"))
		{
			JavascriptExecutor jse1 = (JavascriptExecutor)driver;
			jse1.executeScript("arguments[0].click()", SelectAllCheckBox);
			ExtentsReport.testInfo("SADEquipmentMappingPage Clicked on 'SelectAll' Checkbox Successful");
		}
		
		//AddEquipmentButton.click();
		
		jse.executeScript("arguments[0].click()", AddEquipmentButton);
		ExtentsReport.testInfo("SADEquipmentMappingPage Clicked on 'Add Equipment' Button Successful");
		//SaveButton.click();
		//=====================================================
		//Thread.sleep(15000);
		
		try {
			WebElement ele1 = new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(lbl_Location));
			ExtentsReport.testInfo("SADEquipmentMappingPage Element '"+ele1+" Displayed on Page");
			//Assert.assertTrue("The Elemet " + ele1 + " is appeared on Page", true);
			//Assert.assertEquals(true, lbl_Location.isDisplayed());
			System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$Element is found$$$$$$$$$$$$$$$$$$$$$$$$");
		} catch (Throwable t) {
			System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$Element NOT found$$$$$$$$$$$$$$$$$$$$$$$$");
			System.out.println(t.getMessage());
			//Assert.assertTrue(t.getMessage(), false);
			//Assert.assertFalse(false);
			t.printStackTrace();
		}
		//=====================================================
		/*WebElement ele1 = new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(lbl_Location));
		Assert.assertEquals(true,ele1.isDisplayed());
		System.out.println("ele1 is located*********Validation Success");*/
		
		jse.executeScript("arguments[0].click()", SaveButton);
		ExtentsReport.testInfo("SADEquipmentMappingPage Clicked on Save Successful");
		
		ExtentsReport.testPasedMessage("SADEquipmentMappingPage Saved Successfully");
		
		//driver.switchTo().defaultContent();	
		
	
		
	}
	

	
	
	
	

}
