package com.abb.uiautomation.core.pages.SAD;

import java.util.HashMap;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.utils.WebDriverManager;

//import junit.framework.Assert;

public class SADTagSchematicPage extends WebDriverManager {
	
	public SADTagSchematicPage() {
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[contains(@class,'note')]/following::div[contains(@class,'available-tag drag-cursor')]")
	public WebElement lbl_TagList;
	
	@FindBy(xpath = "//img[@class='img-system ng-star-inserted']")
	public WebElement img_TagListDropArea;
	
	@FindBy(xpath = "//span[text()=' Save ']")
	public WebElement btn_Save;
	
	@FindBy(xpath = "//div[text()=' Note: For mapping, drag and drop the tags from this container to the schematic.']/preceding::span[1]")
	public WebElement lbl_Location;
	


	public void CreateSADTagSchematic(HashMap<String, String> parameterMap) {
		Actions act = new Actions (driver);
		WebElement ele = null;
		/*WebDriverWait wait = new WebDriverWait(driver, 10000);  
	 	wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("iframe-div"));*/
	 	System.out.println("Moved to frame");
	 	
	 	ele = new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(img_TagListDropArea));
		if (ele.isDisplayed())
		{
			System.out.println("-----CreateSADTagSchematic---- TagListDrop Element Dispalyed");
			ele.click();
		}
		else
		{
			System.out.println("-----CreateSADTagMapping---- SearchType Element Dispalyed");
		}
		
		//act.dragAndDrop(lbl_TagList, img_TagListDropArea).build().perform();
		
		Actions builder = new Actions(driver);
		Action dragAndDrop = builder.clickAndHold(lbl_TagList).moveToElement(img_TagListDropArea).release(img_TagListDropArea).build();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		dragAndDrop.perform();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			WebElement ele1 = new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(lbl_Location));
			//Assert.assertTrue("The Elemet " + ele1 + " is appeared on Page", true);
			//Assert.assertEquals(true, lbl_Location.isDisplayed());
			System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$Element is found$$$$$$$$$$$$$$$$$$$$$$$$");
		} catch (Throwable t) {
			System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$Element NOT found$$$$$$$$$$$$$$$$$$$$$$$$");
			System.out.println(t.getMessage());
			//Assert.assertTrue(t.getMessage(), false);
			//Assert.assertFalse(false);
			t.printStackTrace();
		}
		
		btn_Save.click();
		
	}
}
