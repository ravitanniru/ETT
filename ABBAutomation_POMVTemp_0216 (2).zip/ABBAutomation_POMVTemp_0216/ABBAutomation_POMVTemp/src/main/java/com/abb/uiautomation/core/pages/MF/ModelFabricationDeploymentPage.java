package com.abb.uiautomation.core.pages.MF;

import java.util.HashMap;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class ModelFabricationDeploymentPage extends WebDriverManager{
	
	public ModelFabricationDeploymentPage() {
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//html/body/app-root/div[2]/app-detail/div[2]/iframe")
	public WebElement iframeElement;
	
	@FindBy(xpath ="//table/tbody//td[contains(.,'Heat_Exchanger')]/following-sibling::td/span[contains(@class,'icon-abb_model-running icon_abb_dias icon-running-model icon-running-model-enable')]")
	public WebElement img_RunModel_HE;
	
	@FindBy(xpath ="//table/tbody//td[contains(.,'Sensitivity_analyis')]/following-sibling::td/span[contains(@class,'icon-abb_model-running icon_abb_dias icon-running-model icon-running-model-enable')]")
	public WebElement img_RunModel_SA;
	
	@FindBy(xpath ="//button//span[contains(.,'New Deployment')]")
	public WebElement btn_NewDeployment;
	
	@FindBy(xpath = "//span[contains(@class,'icon-abb_deployment icon_abb_dias')]")
	public WebElement icon_Deployment;
	
	@FindBy(xpath = "//span[contains(@class,'icon-abb_model-registry icon_abb_dias')]")
	public WebElement icon_ModelRegistry;
	
	@FindBy(xpath="//span[contains(@class,'icon-abb_data-explore1 icon_abb_dias')]")
	public WebElement icon_DataExplore;
	
	public void MFSelectModel(HashMap<String, String> parameterMap) {
		
		WebElement ele = null;		
		String ElementName = parameterMap.get("ModelName");

		System.out.println("Eelement Name in MFSelectModel " + ElementName);
		
		if (ElementName.equals("Heat_Exchanger")) {
			ele = new WebDriverWait(driver, 12000).until(ExpectedConditions.visibilityOf(img_RunModel_HE));
		} else if (ElementName.equals("Sensitivity_analyis")) {
			ele = new WebDriverWait(driver, 12000).until(ExpectedConditions.visibilityOf(img_RunModel_SA));
		}
		
		if (ele.isDisplayed())
		{
			System.out.println("Element - " + ElementName + " - Displayed");
			ele.click();
			ExtentsReport.testInfo("ModelFabricDeploymentPage select " + ElementName +" from Deployed Model's list Successful");
		}
		else
		{
			System.out.println("Element - " + ElementName + " - Not Displayed");
		}
	}
	
	public void MFSelectMovetoTab(HashMap<String, String> parameterMap)
	{
		WebElement ele = null;
		
		String ElementName = parameterMap.get("SideMenuOptionSelect");
		System.out.println("Eelement Name in SideMenuOptionSelect " + ElementName);
		
		ele = new WebDriverWait(driver, 12000).until(ExpectedConditions.visibilityOf(icon_Deployment));
		
		if (ele.isDisplayed())
		{
			System.out.println("Element - " + ElementName + " - Displayed");
			
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].click()", ele);
			ExtentsReport.testInfo("ModelFabricDeploymentPage select " + ElementName +" Successful");
//			ele.click();
		}
		else
		{
			System.out.println("Element - " + ElementName + " - Not Displayed");
		}
	}
	
	public void MFNewDeployment(HashMap<String, String> parameterMap) {
		
		WebElement ele = null;

		String ElementName = parameterMap.get("option");

		System.out.println("Eelement Name in MFRunModel " + ElementName);
		ele = new WebDriverWait(driver, 30000).until(ExpectedConditions.visibilityOf(btn_NewDeployment));
		if (ele.isDisplayed())
		{
			System.out.println("Element - " + ElementName + " - Displayed");
			ele.click();
			ExtentsReport.testInfo("ModelFabricDeploymentPage Click on " + ElementName +" Successful");
		}
		else
		{
			System.out.println("Element - " + ElementName + " - Not Displayed");
		}
	}
	
	

}
