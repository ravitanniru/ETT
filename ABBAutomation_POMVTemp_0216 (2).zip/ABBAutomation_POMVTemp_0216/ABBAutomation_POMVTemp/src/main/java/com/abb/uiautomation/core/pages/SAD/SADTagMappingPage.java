package com.abb.uiautomation.core.pages.SAD;

import java.util.HashMap;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

//import junit.framework.Assert;

public class SADTagMappingPage extends WebDriverManager {

	public SADTagMappingPage() {
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath="//div[.='Search Type:']/following::input[1]")
	public WebElement btn_SearchType;
	
	@FindBy(xpath="//span[text()=' Description ']/preceding-sibling::div")
	public WebElement chk_Description;
	
	@FindBy(xpath="//span[text()=' Code ']/preceding-sibling::div")
	public WebElement chk_Code;
	
	@FindBy(xpath="//span[text()=' Source ']/preceding-sibling::div")
	public WebElement chk_Source;
	
	@FindBy(xpath="//span[text()=' UOM ']/preceding-sibling::div")
	public WebElement chk_UOM;
	
	@FindBy(xpath="//span[text()=' Parameter Group ']/preceding-sibling::div")
	public WebElement chk_PamrameterGroup;
	
	@FindBy(xpath="//span[text()=' Parameter Type ']/preceding-sibling::div")
	public WebElement chk_parameterType;
	
	@FindBy(xpath="//span[text()=' Parameter Category ']/preceding-sibling::div")
	public WebElement chk_parameterCategory;
	
	
	@FindBy(xpath="//div[text()='Search Tag:']/following::input[1]")
	public WebElement txt_SerchTag;
	
	               
	@FindBy(xpath="//div[text()='Search Tag:']/following::button[1]")
	public WebElement btn_Search;

	@FindBy(xpath="//div[text()='Search Results']/following::mat-checkbox[1]")
	public WebElement chk_SelectAll;
	
	
	@FindBy(xpath="//span[text()=' Save ']/preceding::button/span[text()=' Add Tag ']")
	public WebElement btn_AddTag;
	
	@FindBy(xpath="//span[text()=' Save ']")
	public WebElement btn_Save;
	
	
	@FindBy(xpath="//app-system-tags/div//div[1]/div[2]/span[2]")
	public WebElement lbl_Location;
	
	            
	public void CreateSADTagMapping(HashMap<String, String> parameterMap) throws InterruptedException {
		
		WebElement ele = null;
		
		ele = EventLibrary.Verify_Element_Exist(btn_SearchType);
		EventLibrary.Click_Element_JSE(ele);
		ExtentsReport.testInfo("SADTagMappingPage Clicked on 'SerachType' Successful");
	 	
		
		if (parameterMap.get("Description").equalsIgnoreCase("yes")) 
		{
			EventLibrary.Select_Checkbox(chk_Description);
			ExtentsReport.testInfo("SADTagMappingPage Clicked on 'Description' Checkbox Successful");
		}
		
		if (parameterMap.get("Code").equalsIgnoreCase("yes")) 
		{
			EventLibrary.Select_Checkbox(chk_Code);
			ExtentsReport.testInfo("SADTagMappingPage Clicked on 'Code' Checkbox Successful");
		}
		
		if (parameterMap.get("Source").equalsIgnoreCase("yes")) 
		{
			EventLibrary.Select_Checkbox(chk_Source);
			ExtentsReport.testInfo("SADTagMappingPage Clicked on 'Source' Checkbox Successful");
		}
		
		if (parameterMap.get("UOM").equalsIgnoreCase("yes")) 
		{
			EventLibrary.Select_Checkbox(chk_UOM);
			ExtentsReport.testInfo("SADTagMappingPage Clicked on 'UOM' Checkbox Successful");
		}
		
		if (parameterMap.get("ParameterGroup").equalsIgnoreCase("yes")) 
		{
			EventLibrary.Select_Checkbox(chk_PamrameterGroup);
			ExtentsReport.testInfo("SADTagMappingPage Clicked on 'ParameterGroup' Checkbox Successful");
		}
		
		if (parameterMap.get("ParameterType").equalsIgnoreCase("yes")) 
		{
			EventLibrary.Select_Checkbox(chk_parameterType);
			ExtentsReport.testInfo("SADTagMappingPage Clicked on 'ParameterType' Checkbox Successful");
		}
		
		if (parameterMap.get("ParameterConfiguration").equalsIgnoreCase("yes")) 
		{
			EventLibrary.Select_Checkbox(chk_parameterCategory);
			ExtentsReport.testInfo("SADTagMappingPage Clicked on 'ParameterConfiguration' Checkbox Successful");
		}
		
		
		EventLibrary.Enter_TextBox_Value(txt_SerchTag, parameterMap.get("SearchTag"));
		ExtentsReport.testInfo("SADTagMappingPage Entered " + parameterMap.get("SearchTag") +" into 'Search Tag' Successful");
		
		Thread.sleep(1000);
		
		EventLibrary.Click_Element_JSE(btn_Search);
		ExtentsReport.testInfo("SADTagMappingPage Clicked on 'Search' Button Successful");
		
		if (parameterMap.get("SelectAll").equalsIgnoreCase("yes"))
		{	
			JavascriptExecutor jse1 = (JavascriptExecutor)driver;
			jse1.executeScript("arguments[0].click()", chk_SelectAll);
			ExtentsReport.testInfo("SADTagMappingPage Clicked on 'SelectAll' Checkbox Successful");
		}
		else{
			System.out.println("not clicked=============******************=============");
		}
		
		EventLibrary.Click_Element(btn_AddTag);
		ExtentsReport.testInfo("SADTagMappingPage Clicked on 'Add Tag' Button Successful");
		Thread.sleep(1000);
		
		try {
			WebElement ele1 = new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(lbl_Location));
			//Assert.assertTrue("The Elemet " + ele1 + " is appeared on Page", true);
			//Assert.assertEquals(true, lbl_Location.isDisplayed());
			System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$Element is found$$$$$$$$$$$$$$$$$$$$$$$$");
		} catch (Throwable t) {
			System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$Element NOT found$$$$$$$$$$$$$$$$$$$$$$$$");
			System.out.println(t.getMessage());
			//Assert.assertTrue(t.getMessage(), false);
			//Assert.assertFalse(false);
			t.printStackTrace();
		}
		
		EventLibrary.Click_Element(btn_Save);
		btn_Save.click();
		ExtentsReport.testInfo("SADTagMappingPage Clicked on Save Successful");
		
		ExtentsReport.testPasedMessage("SADTagMappingPage Saved Successfully");
		
	}

	
}
