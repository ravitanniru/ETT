package com.abb.uiautomation.core.services;

import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.apache.commons.exec.util.MapUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;

import com.abb.uiautomation.core.constants.AbbConstants;
import com.abb.uiautomation.core.constants.Correlation;
import com.abb.uiautomation.core.interfaces.IKeywords;
import com.abb.uiautomation.core.log.TestLogger;
import com.abb.uiautomation.core.database.*;
import com.abb.uiautomation.core.pages.*;
import com.abb.uiautomation.core.utils.WebDriverManager;
import com.abb.uiautomation.core.utils.XlsxFileUtils;
import com.aventstack.extentreports.ExtentReporter;
import com.aventstack.extentreports.ExtentTest;
import com.relevantcodes.extentreports.ExtentReports;
import com.abb.uiautomation.core.report.ExtentsReport;

/**
 * 
 * @author INRAKUM106
 *
 */
public class keywordInvokeService extends WebDriverManager {

	IKeywords keywords;
	
	XlsxFileUtils testSuiteFile = new XlsxFileUtils();

	XSSFWorkbook testSuiteworkBook = new XSSFWorkbook();
	XlsxFileUtils environmentFile = new XlsxFileUtils();
	XSSFWorkbook environmentworkBook = new XSSFWorkbook();
	keywordService keywordservice = new keywordService();
	XSSFSheet testsuiteSheet, testcaseSheet, testdataSheet,environmentDetailsSheet;
	databaseService dbService = new databaseService();
	Method[] method;

	private int testStep;
	private int totalSteps;
	private int lastTestStep;
	private int testCaseCount;
	private String testStepId;
	private boolean res;
	private boolean bResult;

	private long day;
	private long hour;
	private long second;
	private long minute;
	private long endTime;
	private long startTime;
	private long totalTime;
	private long totalCount;
	private long batchTotalTime;

	private Date date = new Date();

	private String xpath;
	private String elementName;
	private String keyword;
	private String expectedResult;
	private String testData;
	private String locatorType;
	private String locatorValue;

	private String testSheet;
	private String timeStamp;
	private String testCaseID;
	private String controlName;
	private String controlText;
	private String totalTimeCountNew;
	private String batchtotalTimenew;

	// private HashMap<String, String> testcaseMap = new HashMap<String, String>();

	
	private HashMap<String, HashMap<String, String>> testcaseMap = new LinkedHashMap<String, HashMap<String, String>>();
	public Map<String, String> parameterMap = new LinkedHashMap<String, String>();
	public HashMap<String, String> environmentDetailsMap = new LinkedHashMap<String, String>();
/**
 * 
 * @param keywords
 */
	public keywordInvokeService(IKeywords keywords) {
		this.keywords = keywords;
		method = this.keywords.getClass().getMethods();
	}
/**
 * 
 * @param EnviornmentName
 * @param ModuleName
 * @param ExecutionType
 * @param BrowserType
 * @throws Exception
 */
	public void execute(String EnviornmentName,String ModuleName, String ExecutionType, String BrowserType) throws Exception {
		runTestStep(EnviornmentName,ModuleName,ExecutionType,BrowserType);
	}

/**
 * 
 * @return
 */

	private int setTestCaseCount() {
		if (!res) {
			testCaseCount = 0;
			res = true;
		} else {
		}
		return testCaseCount;
	}
/**
 * 
 * @param EnvironmentName
 * @param ModuleName
 * @param ExecutionType
 * @param BrowserType
 * @return
 * @throws Exception
 */
	public boolean runTestStep(String EnvironmentName,String ModuleName, String ExecutionType, String BrowserType) throws Exception {

		//Start Of Enviornment Configuration;
		
		environmentFile.setExcelFile("C:\\Abbuiautomation\\EnviornmentConfigurationDetails.xlsx");
		environmentworkBook = environmentFile.getWorkBook();
		environmentDetailsSheet = environmentworkBook.getSheet(EnvironmentName);
		
		
		environmentDetailsMap.put("EnvironmentName", environmentFile.getCellData(1, 2 , EnvironmentName));
		environmentDetailsMap.put("BaseURL", environmentFile.getCellData(2, 2 , EnvironmentName));
		environmentDetailsMap.put("TestSuiteFileLocation", environmentFile.getCellData(3, 2 , EnvironmentName));
		
		
		environmentDetailsMap.put("DBhostname", environmentFile.getCellData(4, 2 , EnvironmentName));
		environmentDetailsMap.put("DBdatabasename", environmentFile.getCellData(5, 2 , EnvironmentName));
		environmentDetailsMap.put("DBUser",environmentFile.getCellData(6, 2 , EnvironmentName));
		environmentDetailsMap.put("DBpassword",environmentFile.getCellData(7, 2 , EnvironmentName)); 
		environmentDetailsMap.put("sqlserverport",environmentFile.getCellData(8, 2 , EnvironmentName));
		environmentDetailsMap.put("sqlserverjdbc",environmentFile.getCellData(9, 2 , EnvironmentName));
		
		dbService.dbConnection(environmentDetailsMap.get("sqlserverjdbc"),
				environmentDetailsMap.get("DBhostname"),
				environmentDetailsMap.get("sqlserverport"),
				environmentDetailsMap.get("DBdatabasename"),
				environmentDetailsMap.get("DBUser"), 
				environmentDetailsMap.get("DBpassword")); 
		
		System.out.println("Enviornment Details : " + environmentDetailsMap);
		//End Of Enviornment Configuration.

		//Start Of Test Case Extraction

		testSuiteFile.setExcelFile(environmentDetailsMap.put("TestSuiteFileLocation", environmentFile.getCellData(3, 2 , EnvironmentName)));
		testSuiteworkBook = testSuiteFile.getWorkBook();

		ExtentsReport.configureReport();

		TestLogger.testMessage("ABB Automation Test Suite Execution has started");
		Reporter.log("ABB Automation Test Suite Execution has started");

		int totalNumOfTestcases = 0, numOftestcasesToExecute = 0;
		

		testsuiteSheet = testSuiteworkBook.getSheet(AbbConstants.TestSuiteSheetName);
		testcaseSheet = testSuiteworkBook.getSheet(AbbConstants.TestCaseSheetName);
		testdataSheet = testSuiteworkBook.getSheet(AbbConstants.TestDataSheetName);

		// TestLogger.testMessage("Test Suite execution Started");

		TestLogger.testMessage("Test Suite execution Started");
		for (Row rowObj : testsuiteSheet) {
			System.out.println("In row object iteration");
			HashMap<String, String> testcaseDetailsMap = new LinkedHashMap<String, String>();
			if (rowObj.getRowNum() != 0) {
				
				String testcaseID = rowObj.getCell(AbbConstants.COL_TESTSUITESHEET_TESTCASE_ID).getStringCellValue();
				String testCaseToExecute = rowObj.getCell(AbbConstants.COL_TESTSUITESHEET_TESTCASETOEXECUTE).getStringCellValue();
				int testCaseSheetRowNum = testSuiteFile.getRowContains(testcaseID, 0, AbbConstants.TestCaseSheetName)
						+ 1;
				int testDataSheetRowNum = testSuiteFile.getRowContains(testcaseID, 0, AbbConstants.TestDataSheetName)
						+ 1;
				String testCaseModuleName = rowObj.getCell(AbbConstants.COL_TESTSUITESHEET_MODULE_NAME).getStringCellValue();
				String testCaseExecutionType = rowObj.getCell(AbbConstants.COL_TESTSUITESHEET_EXECUTION_TYPE).getStringCellValue();
						
				System.out.print("<<<<<  TestCase ID : " + testcaseID);
				System.out.print("  testCaseSheetRowNum :  " + testCaseSheetRowNum);
				System.out.print("  testDataSheetRowNum :  " + testDataSheetRowNum);
				System.out.print("  testCaseModuleName :  " + testCaseModuleName);
				System.out.println("  testCaseExecutionType :  " + testCaseExecutionType + "  >>>>>>");

				if (testCaseToExecute.equalsIgnoreCase("yes") && 
						testCaseModuleName.equalsIgnoreCase(ModuleName) &&
						testCaseExecutionType.equalsIgnoreCase(ExecutionType)) {
					numOftestcasesToExecute++;
				}

				testcaseDetailsMap.put("testcaseToExecute", testCaseToExecute);
				testcaseDetailsMap.put("testcaseRowNum", Integer.toString(testCaseSheetRowNum));
				testcaseDetailsMap.put("testdataRownum", Integer.toString(testDataSheetRowNum));
				testcaseDetailsMap.put("testcaseModuleName", testCaseModuleName);
				testcaseDetailsMap.put("testcaseExecutionType", testCaseExecutionType);
				testcaseMap.put(testcaseID, testcaseDetailsMap);
				System.out.println(testcaseMap);
				totalNumOfTestcases++;
			}
		}

		TestLogger.testMessage("Total Number of Test Cases in this Suite : " + totalNumOfTestcases);
		Reporter.log("Total Number of Test Cases in this Suite : " + totalNumOfTestcases);
		TestLogger.testMessage("Number of Test Cases to be Executed in this Session : " + numOftestcasesToExecute);
		Reporter.log("Number of Test Cases to be Executed in this Session : " + numOftestcasesToExecute);

		for (Entry<String, HashMap<String, String>> entry : testcaseMap.entrySet()) {

			String testcaseID = entry.getKey();
			HashMap testcaseDetails = testcaseMap.get(testcaseID);

			System.out.println(".....testcaseID......" + testcaseID);
			System.out.println(".....testcaseDetails.." + testcaseDetails);

			String testcasetoExecute = (String) testcaseDetails.get("testcaseToExecute");
			String testcaseRowNum = (String) testcaseDetails.get("testcaseRowNum");
			String testdataRowNum = (String) testcaseDetails.get("testdataRownum");
			String testcaseModuleName = (String) testcaseDetails.get("testcaseModuleName");
			String testcaseExecutionType = (String) testcaseDetails.get("testcaseExecutionType");

			if (testcasetoExecute.equalsIgnoreCase("yes") && 
					testcaseModuleName.equalsIgnoreCase(ModuleName) &&
					testcaseExecutionType.equalsIgnoreCase(ExecutionType)) {

				ExtentsReport.startTest(testcaseID);
				ExtentsReport.testInfo("Test Case Name : " + testcaseID + "Started Execution");
				TestLogger.testMessage("Test Case Name : " + testcaseID);
				Reporter.log("Test Case Name : " + testcaseID);

				Row testcaseRowObj = testcaseSheet.getRow(Integer.parseInt(testcaseRowNum) - 1);
				Row testdataparamNameRowObj = testdataSheet.getRow(Integer.parseInt(testdataRowNum) - 1);
				Row testdataparamValueRowObj = testdataSheet.getRow(Integer.parseInt(testdataRowNum));

				int testdatacellIndex = testdataparamNameRowObj.getFirstCellNum() + 2;

				System.out.print("...testdatacellIndex " + testdatacellIndex);
				System.out.println("....testdatacellIndexLast " + testdataparamNameRowObj.getLastCellNum() + "....");

				for (int testcaseIndex = testcaseRowObj.getFirstCellNum() + 1; testcaseIndex < testcaseRowObj
						.getLastCellNum(); testcaseIndex++) {
					Cell testcaseIndexCell = testcaseRowObj.getCell(testcaseIndex);
					String testcaseIndexCellValue = testcaseIndexCell.getStringCellValue();

					if (testcaseIndexCellValue.length() > 0) {
						String methodName = testcaseIndexCellValue;
						String pageClassName = Correlation.correlationMap.get(methodName);
						System.out.print("++++++ Class Name : " + pageClassName);
						System.out.println("  Method Name : " + methodName + " ++++++");

						parameterMap.clear();

						TestLogger.testMessage("Test Step Name : " + methodName);
						Reporter.log("Test Step Name : " + methodName);

						for (int testdataIndex = testdatacellIndex; testdataIndex <= testdataparamNameRowObj
								.getLastCellNum() - 1; testdataIndex++) {
							System.out.print("...testdatacellIndex " + testdatacellIndex);
							System.out.println("....testdatacellIndex " + testdatacellIndex + "....");
							String parameterCellValue = testdataparamNameRowObj.getCell(testdataIndex)
									.getStringCellValue();
							String[] parameterCellArray = parameterCellValue.split("[.]");
							String parameterMethodName = parameterCellArray[0];
							System.out.println(
									"parameterMethodName : " + parameterMethodName + "...methodName ..." + methodName);

							if (parameterMethodName.equalsIgnoreCase(methodName)) {
								String parameterName = parameterCellArray[1];
								String parameterValue = testdataparamValueRowObj.getCell(testdataIndex)
										.getStringCellValue();
								System.out.print("------parameterName : " + parameterName);
								System.out.println(" parameterValue : " + parameterValue + "------");
								parameterMap.put(parameterName, parameterValue);

							} else {
								System.out.println("...In Continue...");
								testdatacellIndex = testdataIndex++;
								break;
							}
						}
						
						 Class classObj = Class.forName("com.abb.uiautomation.core.pages." +
						 pageClassName); System.out.println("com.abb.uiautomation.core.pages." +
						 pageClassName); Object methodObj = classObj.newInstance();
						 
						 System.out.println(methodObj.getClass());
						 
						 System.out.println("Method Name    " + methodName);
						 System.out.println(parameterMap);
						
						
						 Method method = methodObj.getClass().getDeclaredMethod(methodName,HashMap.class); 
						 
						 method.setAccessible(true); System.out.println("Before invoke method");
						 method.invoke(methodObj, parameterMap);
						 
					} else {
						break;
					}
				}

				ExtentsReport.endTest();
			}
		}
		return false;
	}

	public void invokeKeyword(final String elementName, final String actionKeyword, final String locatorType,
			final String locatorValue, final String testData, final String expectedResult, final String testStepId)
			throws Exception {

		// Object object = null;

		try {
			for (int i = 0; i < method.length; i++) {
				if (method[i].getName().equals(actionKeyword)) {
					TestLogger.testMessage("Test Step Name : " + method[i].getName());
					Reporter.log("Test Step Name : " + method[i].getName());
					System.out.println("in InvokeKeyword " + method[i].getName());
					// Object status = method[i].invoke(this.keywords, actionKeyword, locatorType,
					// locatorValue, testData, expectedResult,
					// testStepId);

					boolean TestStatus = (boolean) (method[i].invoke(this.keywords, elementName, actionKeyword,
							locatorType, locatorValue, testData, expectedResult, testStepId));

					System.out.println("_______________________________________________");
					System.out.println("in InvokeKeyword testSepId TestStatus" + TestStatus);
					System.out.println("_______________________________________________");
					// System.out.println("in InvokeKeyword testSepId" +
					// status.getClass().getResource(expectedResult));

				}
			}
		} catch (Exception e) {
			// log.error("Exception occured while executing the test case");
			throw e;
		}

		// return object;
	}

	private String String(Object invoke) {
		// TODO Auto-generated method stub
		return null;
	}
}
