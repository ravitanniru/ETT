package com.abb.uiautomation.core.pages.PH;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class PlatFormHorizontalPage extends WebDriverManager {
	//WebDriver driver;

	public PlatFormHorizontalPage() {
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}
	
	//Data required for Roles creation Table 
	protected static final int ROLENAME = 1;
	protected static final int DESCRIPTION = 2;
	protected static final int LASTUPDATED = 3;
	protected static final int USERS = 4;
	protected static final int ACTIVEINACTIVE = 5;
	protected static final int DELETE = 6;
	// --------------------- Landing Page ---------------------------------------
	/*
	 * @FindBy(xpath =
	 * "//img[@src = 'fonts/abb_svg_icons/abb_administrartion.svg']") public
	 * WebElement img_Platform_HorizontalSVGImage;
	 */

	@FindBy(xpath = "//div[.=' Role & User Management']")
	public WebElement btn_Role_n_Usermanagement;

	// ----------------------New Role Creation------------------------------------
	@FindBy(xpath = "//div[text()='Platform Administration']")
	public WebElement lbl_Platform_Administration;

	@FindBy(xpath = "//span[.=' New Role ']")
	public WebElement btn_NewRole;


	@FindBy(xpath = "//input[@formcontrolname='name']")
	public WebElement txt_Role_Name;
	//public WebElement txt_Role_Name = EventLibrary.JSE_GetElementByID("mat-input-1",driver);
		
	@FindBy(xpath = "//textarea[@formcontrolname='description']")
	public WebElement txtArea_Description;
	//public WebElement txtArea_Description = EventLibrary.JSE_GetElementByID("mat-input-2",driver) ;
	
	@FindBy(id="mat-input-3")
	public WebElement List_PermissionAccess;
	/*@FindBy(xpath = "//select[contains(.,'Select Application')]//following::div[contains(text(),'Tenant Management')]//following::div[@class='mat-slide-toggle-thumb'][1]")
	public WebElement List_PermissionAccess;*/
	//public WebElement List_PermissionAccess = EventLibrary.JSE_GetElementByID("mat-input-3",driver);
	
	
	/*
	 * Select class method is placed in Generic utility to use the below webelement
	 */
	
	//public WebElement btn_Access_Slide_Toggle = EventLibrary.JSE_GetElementByID("mat-slide-toggle-30-input",driver);
	
	@FindBy(xpath = "//button[contains(.,'Save')]")
	public WebElement btn_Save;
	//public WebElement btn_Save = EventLibrary.JSE_GetElementByTagName("button",1,driver);
	
	// -------------Role Definition------------------------------------------
	@FindBy(xpath = "//a[.='Role Definition']")
	public WebElement lbl_Role_Definition;

	//@FindBy(id = "mat-input-4")
	@FindBy(xpath = "//input[@placeholder='Search']")
	public WebElement txt_Search_Role_Definition;
	
	
	//@FindBy(className = "icon-abb_search_16 icon_abb_16 icon")
	@FindBy(xpath = "//input[@placeholder='Search']/following-sibling::div[2]")
	public WebElement btn_Search_Role_Definitionbtn;
	
	/*@FindBy(id="mat-slide-toggle-3-input")
	//@FindBy(xpath = "//table/tbody//td[text()=' AutoTestRole1 ']//following-sibling::td//div[@class='mat-slide-toggle-thumb']")
	public WebElement btn_Active_Inactive;*/
	
	
	//@FindBy(xpath="//table/tbody//td[5]/mat-slide-toggle[@class='toggle-btn mat-slide-toggle mat-accent mat-checked']")
	@FindBy(xpath="//table/tbody//td[5]/mat-slide-toggle/label//input[@aria-checked = 'true']")
	WebElement btn_ActivatedRole ;
	
	
	@FindBy(xpath="//button[@class='icon-abb_trash_24 icon_abb_24 icon-delete']")
	WebElement btn_DeleteRole ;
	
	@FindBy(xpath = "//span[.=' OK ']")
	public WebElement btn_OK_Delete;
	
	/*
	 * Below method is generic method to feth the data from table Role List on Role
	 * Definition Page Note: provide the unique string as parameter value
	 */
	public static WebElement find_Role_List_Table_Element(String RoleName , int Tablecolumn) {
		
		switch(Tablecolumn) {
		case ROLENAME:
			return EventLibrary.WaitForElement(driver.findElement(By.xpath("//table/tbody//td[text()=' " + RoleName + " ']")), 30) ;
		case DESCRIPTION:	
			return driver.findElement(By.xpath("//table/tbody//td[text()=' " + RoleName + " ']/following-sibling::td[1]"));
		case LASTUPDATED:
			return driver.findElement(By.xpath("//table/tbody//td[text()=' " + RoleName + " ']/following-sibling::td[2]"));
		case USERS:
			return driver.findElement(By.xpath("//table/tbody//td[text()=' " + RoleName + " ']/following-sibling::td[3]"));	
		case ACTIVEINACTIVE:
			return driver.findElement(By.xpath("//table/tbody//td[text()=' " + RoleName + " ']//following-sibling::td//div[@class='mat-slide-toggle-thumb']"));
		case DELETE:
			return driver.findElement(By.xpath("//table/tbody//td[text()=' " + RoleName + " ']//following::button[@class='icon-abb_trash_24 icon_abb_24 icon-delete']"));	
		default: return null;
		}
		
	}

	@FindBy(xpath = "//input[@placeholder='Search']/following::div[contains(@class,'icon-abb_search')]")
	public WebElement btn_Search_Role_Definition;

	/*@FindBy(xpath = "//table/tbody//td[5]//div[contains(@class,'mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin')]")
	public WebElement btn_Active_InActive;*/

	@FindBy(xpath = "//table/tbody//td[5]/mat-slide-toggle[contains(@class,'mat-checked')]")
	public WebElement btn_Activated;

	@FindBy(xpath = "//table/tbody//td[6 ]/button[contains(@mattooltip,'Delete')]")
	public WebElement btn_Delete;


	
	// ----------Allocate Permission to Role--------------------

	@FindBy(xpath = "//select[contains(.,'Select Application')]")
	public WebElement sel_SelectApplication;

	public static WebElement find_Permission_Access_Element(String Permission) {

		return driver
				.findElement(By.xpath("//select[contains(.,'Select Application')]//following::div[contains(text(),'"
						+ Permission + "')]//following::div[@class='mat-slide-toggle-thumb'][1]"));

	}
	
	public WebElement find_Permission_Access_Element_checked(String Permission) {

		return driver.findElement(
				By.xpath("//select[contains(.,'Select Application')]//following::div[contains(text(),'" + Permission
						+ "')]//following::div[@class='mat-slide-toggle-thumb'][1]/ancestor::div/mat-slide-toggle[contains(@class,'mat-checked')]"));

	}

	@FindBy(xpath = "//button[@mattooltip='Add Application']")
	public WebElement btn_AddApplication;
	
	//=================Mapping User andRole =========================
	@FindBy(xpath="//mat-sidenav//ul/li[4]")
	public WebElement lbl_Mapping_User_andRole ;
	
	@FindBy(xpath="//mat-sidenav//ul/li[3]")
	public WebElement lbl_RoleDefinition ;
	
	@FindBy(xpath="//button/span[text()=' Assign Role ']")
	public WebElement btn_AssignRole ;
	
	@FindBy(xpath="//a[.='Assign Roles']")
	public WebElement lbl_AssignRoles ;
	
	//@FindBy(id="mat-input-8")
	@FindBy(xpath="//input[@formcontrolname='userName']")
	public WebElement txt_User_AssignRole ;
	
	@FindBy(xpath="//div[@class='mat-select-value']")
	public static WebElement lst_RolesSelect ;
	
	//@FindBy(id="mat-input-9")
	@FindBy(xpath="//input[@placeholder='Search']")
	public WebElement txt_Mapped_User_Role_Search ;
	
	@FindBy(xpath="//input[@placeholder='Search']/following-sibling::div[1]")
	public WebElement btn_Mapped_User_Role_Search ;
	
	@FindBy(xpath = "//mat-chip[1]")
	public WebElement lbl_chip;
	
	/*
	 * Below method will help in fetching the Created Role list based on the role name 
	 * provided as parameter
	 */
	public static WebElement RolesTobeAssignedTouserElement(String Rolename) throws Exception {
		EventLibrary.Click_Element(lst_RolesSelect);
		System.out.println(Rolename);
		return EventLibrary.Verify_Element_Exist( driver.findElement(By.xpath("//span[.='"+Rolename+" ']/preceding::mat-pseudo-checkbox[1]")));
	}

	
	
	public void MoveToRolesAndUserManagementTab(HashMap<String, String> parameterMap) throws Exception {
		System.out.println("Enterd MoveToRolesAndUserManagementTab@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ");
		WebElement ele = null;
		System.out.println("Moved to frame title");
		EventLibrary.waitforFrametoLoadAndSwitchToFrame("1","iframe-div");
		System.out.println("Moved to frame");
		String ElementName = parameterMap.get("tabName");

		System.out.println("Eelement Name in SADMoveToTab " + ElementName);
		if (ElementName.equalsIgnoreCase("Role & User Management")) {

			ele = new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(btn_Role_n_Usermanagement));
			System.out.println("in PH");
			EventLibrary.Click_Element(ele);
			EventLibrary.Verify_Element_Exist(btn_NewRole);
			
		}
	}

	public void PlatformAdminCreateRole(HashMap<String, String> parameterMap) throws Exception {
		
		EventLibrary.Click_Element(btn_NewRole);
		EventLibrary.Enter_TextBox_Value(txt_Role_Name, parameterMap.get("RoleName"));
		EventLibrary.Enter_TextBox_Value(txtArea_Description, parameterMap.get("Description"));
		EventLibrary.Select_ListElement(List_PermissionAccess, 1, parameterMap.get("Permission"));
		WebElement AccessElement =find_Permission_Access_Element(parameterMap.get("PermissionAccess"));
		EventLibrary.Click_Element(AccessElement);
		EventLibrary.Click_Element(btn_Save);
		
		//Search for Role created
		EventLibrary.Enter_TextBox_Value(txt_Search_Role_Definition, parameterMap.get("RoleName"));
		EventLibrary.Click_Element(btn_Search_Role_Definitionbtn);
		/*
		 * Below lines of code helps to fetch the Role definition column elements and their values 
		 * are extracted using getText method
		 */
		WebElement createdRole = find_Role_List_Table_Element(parameterMap.get("RoleName"),1);
		String CreatedRoleName = createdRole.getText();
		WebElement createdRoleDescription = find_Role_List_Table_Element(parameterMap.get("RoleName"),2);
		String createdRoleDescriptionValue = createdRoleDescription.getText();
		System.out.println("===========================================");
		System.out.println(CreatedRoleName);
		System.out.println(createdRoleDescriptionValue);
		System.out.println(parameterMap.get("RoleName"));
		
		//Verify Role is created
		Assert.assertEquals(CreatedRoleName, parameterMap.get("RoleName"));
		System.out.println(parameterMap.get("Description"));
		Assert.assertEquals(createdRoleDescriptionValue, parameterMap.get("Description"));
		
		//Verify Activate the Role
		//EventLibrary.Click_Element(btn_Active_Inactive);
		WebElement ActivateRole = find_Role_List_Table_Element(parameterMap.get("RoleName"),5);
		EventLibrary.Click_Element(ActivateRole);
		WebElement RoleActivated = EventLibrary.Verify_Element_Exist(btn_ActivatedRole);
		Assert.assertTrue(RoleActivated.isDisplayed());
		System.out.println("Test case 27 completes");
		//==============Test case No 27 completed===========================================
	}
	
	public void PlatformAdminDeleteRole(HashMap<String, String> parameterMap) throws InterruptedException {
		
		
		EventLibrary.Click_Element(lbl_RoleDefinition);
		EventLibrary.Enter_TextBox_Value(txt_Search_Role_Definition, parameterMap.get("RoleName"));
		//EventLibrary.Click_Element(btn_Search_Role_Definitionbtn);
		EventLibrary.Click_Element_JSE(btn_Search_Role_Definitionbtn);
		WebElement RoleToBeDeleted = find_Role_List_Table_Element(parameterMap.get("RoleName"), 1);
		String RoleToBeDeletedName = RoleToBeDeleted.getText();
		
		//Delete Role 
		if(RoleToBeDeletedName.equalsIgnoreCase(parameterMap.get("RoleName"))) {
		EventLibrary.mouseOver(btn_DeleteRole);
		EventLibrary.Click_Element(btn_DeleteRole);
		EventLibrary.Click_Element(btn_OK_Delete);
		}
		//Search for Role deleted
		EventLibrary.Enter_TextBox_Value(txt_Search_Role_Definition, parameterMap.get("RoleName"));
		EventLibrary.Click_Element(btn_Search_Role_Definitionbtn);
		
		// Verify Role is deleted
		try {
		EventLibrary.Static_Wait(15);
		WebElement deletedRole = find_Role_List_Table_Element(parameterMap.get("RoleName"),1);
		}catch(Exception e) {
			System.out.println("Role deleted verification");
			Assert.assertTrue(true, " Role is deleted successfully ");
		}
		
		System.out.println("Test case number 29 completes");
	}
	
	public void PlatformAdminAssignRoleToUser(HashMap<String, String> parameterMap) throws Exception {
		//EventLibrary.Click_Element(lbl_Mapping_User_andRole);
		EventLibrary.Click_Element_JSE(lbl_Mapping_User_andRole);
		EventLibrary.Click_Element(btn_AssignRole);
		
		//Verify once after click on Assign Role user landed on Mapping User RolesAssign Roles page
		EventLibrary.Verify_Element_Exist(lbl_AssignRoles);
		Assert.assertTrue(true, "Mapping User RolesAssign Roles is verified ");
		EventLibrary.Enter_TextBox_Value(txt_User_AssignRole, parameterMap.get("UsermailId"));
		EventLibrary.Static_Wait(10);
		WebElement roleToBeAssignedToUser = RolesTobeAssignedTouserElement(parameterMap.get("RoleName"));
		EventLibrary.Static_Wait(10);
		EventLibrary.Click_Element_JSE(roleToBeAssignedToUser);
		EventLibrary.Click_Element_JSE(btn_Save);
		
		//EventLibrary.Enter_Textbox_value_JSE(txt_Mapped_User_Role_Search, parameterMap.get("UsermailId"));
		EventLibrary.Click_Element_JSE(btn_Mapped_User_Role_Search);
		EventLibrary.getAction().sendKeys(Keys.ENTER).build().perform();
		
		EventLibrary.Static_Wait(10);
		
		WebElement User = find_Role_List_Table_Element(parameterMap.get("UsermailId") , 1);
		String UserName = User.getText();
		WebElement Role = find_Role_List_Table_Element(parameterMap.get("UsermailId") , 2);
		String RoleMapped = Role.getText();
		
		System.out.println("User name for role mapping is "+UserName);
		System.out.println("Role name for role mapping is "+RoleMapped);
		
		//Verify assigned role for a user in mapping user & role list 
		Assert.assertEquals(UserName, parameterMap.get("UsermailId"));
		Assert.assertEquals(RoleMapped, parameterMap.get("RoleName"));
		
		System.out.println("test case 28 completes");
	}
	
	public void PlatformAdminRemoveRole(HashMap<String, String> parameterMap) throws InterruptedException {
		EventLibrary.Click_Element(lbl_Mapping_User_andRole);
		//EventLibrary.Enter_Textbox_value_JSE(txt_Mapped_User_Role_Search, parameterMap.get("UsermailId"));
		EventLibrary.Click_Element_JSE(btn_Mapped_User_Role_Search);
		EventLibrary.getAction().sendKeys(Keys.ENTER).build().perform();
		WebElement RoleToBeRemovedUser = find_Role_List_Table_Element(parameterMap.get("UsermailId"), 1);
		String RoleToBeDeletedUserName = RoleToBeRemovedUser.getText();
		if(RoleToBeDeletedUserName.equalsIgnoreCase(parameterMap.get("UsermailId"))) {
			WebElement RoleToBeRemoved = find_Role_List_Table_Element(parameterMap.get("UsermailId"), 3);
			EventLibrary.Click_Element(RoleToBeRemoved);
			EventLibrary.Click_Element(btn_OK_Delete);
		}
		
		//Verify for Removed Role
		//EventLibrary.Enter_Textbox_value_JSE(txt_Mapped_User_Role_Search, parameterMap.get("UsermailId"));
		EventLibrary.Click_Element_JSE(btn_Mapped_User_Role_Search);
		EventLibrary.getAction().sendKeys(Keys.ENTER).build().perform();
		
		try {
			EventLibrary.Static_Wait(15);
			WebElement deletedRole = find_Role_List_Table_Element(parameterMap.get("UsermailId"),1);
			}catch(Exception e) {
				System.out.println("Role removed verification");
				Assert.assertTrue(true, " Role is removed successfully ");
			}
		System.out.println("Test case number 30 completes");
	}
}
