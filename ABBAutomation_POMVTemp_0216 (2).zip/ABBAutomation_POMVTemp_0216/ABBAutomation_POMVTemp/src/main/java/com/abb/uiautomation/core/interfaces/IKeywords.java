package com.abb.uiautomation.core.interfaces;

public interface IKeywords {
	
	//void navigate();
	boolean launchBrowser(String elementName,String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId);
	
	boolean quitBrowser(String elementName,String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId) throws Exception;

	boolean inputText(String elementName,String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId) throws Exception;
	
	boolean click(String elementName,String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId) throws Exception;
	
	boolean isElementExist(String elementName,String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId);

	boolean navigate(String elementName,String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId);
	
	boolean select(String elementName,String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId) throws Exception;
	
	boolean staticWait(String elementName,String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId);
	
	boolean uploadFile(String elementName,String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId);
	
	boolean selectCheckBox(String elementName,String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId);
	
	boolean dragDrop(String elementName,String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId);
	
	boolean compareData(String elementName,String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId);
}
