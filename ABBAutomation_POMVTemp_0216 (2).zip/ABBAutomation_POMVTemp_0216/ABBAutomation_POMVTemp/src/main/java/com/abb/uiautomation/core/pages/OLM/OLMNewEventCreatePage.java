package com.abb.uiautomation.core.pages.OLM;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class OLMNewEventCreatePage extends WebDriverManager {

	public OLMNewEventCreatePage() {
		// this.driver = WebDriverManager.getWebDriver("Chrome");
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "iframe-div")
	public WebElement frame_iframeParent;

	// ID -DYNAMIC
	// @FindBy(id="mat-input-2")
	@FindBy(xpath = "(//select)[2]")
	public WebElement lst_Country;

	// ID -DYNAMIC
	// @FindBy(id="mat-input-3")
	@FindBy(xpath = "(//select)[3]")
	public WebElement lst_Region;

	// ID -DYNAMIC
	// @FindBy(id="mat-input-4")
	@FindBy(xpath = "(//select)[4]")
	public WebElement lst_Plant;

	// ID -DYNAMIC
	// @FindBy(id="mat-input-5")
	@FindBy(xpath = "(//select)[5]")
	public WebElement lst_Area;

	// ID -DYNAMIC
	// @FindBy(id="mat-input-6")
	@FindBy(xpath = "(//select)[6]")
	public WebElement lst_Unit;

	// ID -DYNAMIC
	// @FindBy(id="mat-input-7")
	@FindBy(xpath = "(//select)[7]")
	public WebElement lst_LossDetails;

	// ID - NOT AVAILABLE
	//@FindBy(xpath = "//button/span[text()=' OK ']")
	@FindBy(xpath = "//button//span[contains(.,'OK')]")
	public WebElement btn_OK;

	// ID - NOT AVAILABLE
	//@FindBy(xpath = "//button/span[text()=' Cancel ']")
	@FindBy(xpath = "//button//span[contains(.,'Cancel')]")
	public WebElement btn_Cancel;

	// ID - NOT AVAILABLE
	//@FindBy(xpath = "//button/span[text()=' Save ']")
	@FindBy(xpath = "//button//span[contains(.,'Save')]")
	public WebElement btn_Save;

	// ID - NOT AVAILABLE
	//@FindBy(xpath = "//button/span[text()=' Submit ']")
	@FindBy(xpath = "//button//span[contains(.,'Submit')]")
	public WebElement btn_Submit;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//button/span[text()=' Apply ']")
	public WebElement btn_Apply;

	// ID - DYNAMIC
	// @FindBy(id="mat-input-19")
	@FindBy(xpath = "//textarea[@formcontrolname='Description']")
	public WebElement txt_Description;

	// ID - DYNAMIC
	// @FindBy(id="mat-input-23")
	//@FindBy(xpath = "//input[@formcontrolname='EventStartDate']")
	@FindBy(xpath = "(//button[@type='button'][@aria-label='Open calendar'])[1]")
	public WebElement Input_EventStartDate;
	
	@FindBy(xpath = "//table[@class='mat-calendar-table']/tbody/tr/td[@aria-label='")
	public WebElement Calendar_Date_Select;

	// ID - DYNAMIC
	// @FindBy(id="mat-input-24")
	//@FindBy(xpath = "//input[@formcontrolname='EventEndDate']")
	@FindBy(xpath = "(//button[@type='button'][@aria-label='Open calendar'])[2]")
	public WebElement input_EventEndDate;

	// ID - DYNAMIC
	// @FindBy(id="mat-input-25")
	@FindBy(xpath = "//input[@formcontrolname='Link']")
	public WebElement input_Link;

	// ID - NOT AVAILABLE - Need to Check
	@FindBy(xpath = "//*[@id='mat-tab-content-0-0']/div/olm-event-product-loss-tab/form/div[3]/div[4]/div[2]/div")
	public WebElement btn_SeacrhLink;

	// ID - DYNAMIC
	// @FindBy(id="mat-input-26")
	@FindBy(xpath = "(//input[@formcontrolname='Clf_Loss_Value_Pi'])[1]")
	public WebElement input_TheftCurrency;

	// ID - DYNAMIC
	// @FindBy(id="mat-input-33")
	@FindBy(xpath = "(//input[@formcontrolname='Clf_Loss_Value_Pi'])[2]")
	public WebElement input_DamageCurrency;

	// ID - DYNAMIC
	// @FindBy(id="mat-input-27")
	@FindBy(xpath = "(//input[@formcontrolname='Clf_Percentage'])[1]")
	public WebElement input_TheftLoss;

	// ID - DYNAMIC
	// @FindBy(id="mat-input-34")
	@FindBy(xpath = "(//input[@formcontrolname='Clf_Percentage'])[2]")
	public WebElement input_DamageLoss;

	// ID-DYNAMIC
	// @FindBy(id="mat-input-28")
	@FindBy(xpath = "(//textarea[@formcontrolname='Loss_Type_Name'])[1]/following::span[1]")
	public WebElement input_TheftLossTypeName;

	// ID-DYNAMIC
	// @FindBy(id="mat-input-35")
	@FindBy(xpath = "(//textarea[@formcontrolname='Loss_Type_Name'])[2]/following::span[1]")
	public WebElement input_DamageLossTypeName;

	// (//table)[2]/tbody

	// ID-DYNAMIC
	// @FindBy(id="mat-input-29")
	//@FindBy(xpath = "(//input[@formcontrolname='Malfunction_Start_Date'])[1]")
	@FindBy(xpath = "(//button[@type='button'][@aria-label='Open calendar'])[3]")
	public WebElement input_TheftMalfunctionStartDate;
	
	// ID-DYNAMIC
	// @FindBy(id="mat-input-30")
		//@FindBy(xpath = "(//input[@formcontrolname='Malfunction_End_Date'])[1]")
	@FindBy(xpath = "(//button[@type='button'][@aria-label='Open calendar'])[4]")
		public WebElement input_TheftMalfunctionEndDate;

	// ID-DYNAMIC
	// @FindBy(id="mat-input-36")
	//@FindBy(xpath = "(//input[@formcontrolname='Malfunction_Start_Date'])[2]")
	@FindBy(xpath = "(//button[@type='button'][@aria-label='Open calendar'])[5]")
	public WebElement input_DamageMalfunctionStartDate;

	// ID-DYNAMIC
	// @FindBy(id="mat-input-37")
	//@FindBy(xpath = "(//input[@formcontrolname='Malfunction_End_Date'])[2]")
	@FindBy(xpath = "(//button[@type='button'][@aria-label='Open calendar'])[6]")
	public WebElement input_DamageMalfunctionEndDate;

	// ID-DYNAMIC
	// @FindBy(id="mat-input-31")
	@FindBy(xpath = "(//textarea[@formcontrolname='Comment_Text'])[1]")
	public WebElement input_TheftComments;

	// ID-DYNAMIC
	// @FindBy(id="mat-input-37")
	@FindBy(xpath = "(//textarea[@formcontrolname='Comment_Text'])[2]")
	public WebElement input_DamageComments;
	
	@FindBy(xpath= "//textarea[@placeholder='Please enter your comments here, if any!']")
	public WebElement input_EventComments;
		
		

	
	public void OLMNewEventCreate(HashMap<String, String> parameterMap) {
		
		WebElement ele = null;
		
		
		try {
			ele = EventLibrary.Verify_Element_Exist(lst_Country);
			EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Country"));
			
			ele = EventLibrary.Verify_Element_Exist(lst_Region);
			EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Region"));
			
			ele = EventLibrary.Verify_Element_Exist(lst_Plant);
			EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Plant"));
			
			ele = EventLibrary.Verify_Element_Exist(lst_Area);
			EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Area"));
			
			ele = EventLibrary.Verify_Element_Exist(lst_Unit);
			EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Unit"));
			
			ele = EventLibrary.Verify_Element_Exist(lst_LossDetails);
			EventLibrary.Select_ListElement(ele, 1, parameterMap.get("LossDetails"));
			
			Thread.sleep(1000);
			System.out.println("After Sleep");
			ele = EventLibrary.Verify_Element_Exist(btn_OK);
			
			EventLibrary.Click_Element_JSE(ele);

			
			ele = EventLibrary.Verify_Element_Exist(txt_Description);
			EventLibrary.Enter_TextBox_Value(ele,parameterMap.get("Description")); 
			
			ele = EventLibrary.Verify_Element_Exist(Input_EventStartDate);
			EventLibrary.Click_Element_JSE(ele);
			String dateVal = parameterMap.get("IncidentDate");
			String DateString = "//table[@class='mat-calendar-table']/tbody//td[@aria-label='" + dateVal + "']/div";
			System.out.println("     DateString   " + DateString);
			try {
				System.out.println("try 1");
			WebElement ele1 = driver.findElement(By.xpath(DateString));
			EventLibrary.Click_Element_JSE(ele1);
			
			}
			catch(Exception exp) {
				WebElement ele1 = driver.findElement(By.xpath(DateString));
				EventLibrary.Click_Element_JSE(ele1);
			}
			
			Thread.sleep(500);
			ele = EventLibrary.Verify_Element_Exist(input_EventEndDate);
			EventLibrary.Click_Element_JSE(ele);
			dateVal = parameterMap.get("ReportedDate");
			DateString = "//table[@class='mat-calendar-table']/tbody//td[@aria-label='" + dateVal + "']/div";
			System.out.println("     DateString   " + DateString);
			try {
				System.out.println("try 2");
				WebElement ele1 = driver.findElement(By.xpath(DateString));
				EventLibrary.Click_Element_JSE(ele1);
			}
			catch(Exception exp) {
				WebElement ele1 = driver.findElement(By.xpath(DateString));
				EventLibrary.Click_Element_JSE(ele1);
			}
			Thread.sleep(500);
			ele = EventLibrary.Verify_Element_Exist(input_TheftCurrency);
			EventLibrary.Enter_TextBox_Value(ele, parameterMap.get("TheftCurencyValue"));
			
			ele = EventLibrary.Verify_Element_Exist(input_TheftLossTypeName);
			EventLibrary.Click_Element_JSE(ele);			
			ele = driver.findElement(By.xpath("(//input[@type='radio'])[1]"));
			EventLibrary.Click_Element_JSE(ele);
			
			ele = EventLibrary.Verify_Element_Exist(btn_Apply);			
			EventLibrary.Click_Element_JSE(ele);
			
			ele = EventLibrary.Verify_Element_Exist(input_TheftMalfunctionStartDate);
			EventLibrary.Click_Element_JSE(ele);
			dateVal = parameterMap.get("TheftIncidentStartDate");
			driver.findElement(By.xpath("//table[@class='mat-calendar-table']//tbody//td[@aria-label='" + dateVal +"']/div")).click();
			
			ele = EventLibrary.Verify_Element_Exist(input_TheftMalfunctionEndDate);
			EventLibrary.Click_Element_JSE(ele);
			dateVal = parameterMap.get("TheftIncidentEndDate");
			driver.findElement(By.xpath("//table[@class='mat-calendar-table']//tbody//td[@aria-label='" + dateVal +"']/div")).click();
			
			ele = EventLibrary.Verify_Element_Exist(input_TheftComments);
			EventLibrary.Enter_TextBox_Value(ele,parameterMap.get("TheftIncidentComments"));
				
			ele = EventLibrary.Verify_Element_Exist(input_DamageCurrency);
			EventLibrary.Enter_TextBox_Value(ele, parameterMap.get("DamageCurencyValue"));
			
			ele = EventLibrary.Verify_Element_Exist(input_DamageLossTypeName);
			EventLibrary.Click_Element_JSE(ele);			
			ele = driver.findElement(By.xpath("(//input[@type='radio'])[2]"));
			EventLibrary.Click_Element_JSE(ele);
			
			ele = EventLibrary.Verify_Element_Exist(btn_Apply);			
			EventLibrary.Click_Element_JSE(ele);
			
			ele = EventLibrary.Verify_Element_Exist(input_DamageMalfunctionStartDate);
			EventLibrary.Click_Element_JSE(ele);
			dateVal = parameterMap.get("DamageIncidentStartDate");
			driver.findElement(By.xpath("//table[@class='mat-calendar-table']//tbody//td[@aria-label='" + dateVal +"']/div")).click();
			
			ele = EventLibrary.Verify_Element_Exist(input_DamageMalfunctionEndDate);
			EventLibrary.Click_Element_JSE(ele);
			dateVal = parameterMap.get("DamageIncidentEndDate");
			driver.findElement(By.xpath("//table[@class='mat-calendar-table']//tbody//td[@aria-label='" + dateVal +"']/div")).click();
			
			ele = EventLibrary.Verify_Element_Exist(input_DamageComments);
			EventLibrary.Enter_TextBox_Value(ele,parameterMap.get("DamageIncidentComments"));
			
			ele = EventLibrary.Verify_Element_Exist(btn_Submit);
			EventLibrary.Click_Element(ele);
			
			ele = EventLibrary.Verify_Element_Exist(input_EventComments);
			EventLibrary.Enter_TextBox_Value(ele,parameterMap.get("EventComments"));
			
			ele = EventLibrary.Verify_Element_Exist(btn_OK);
			EventLibrary.Click_Element(ele);
					
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
