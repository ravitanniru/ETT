package com.abb.uiautomation.core.utils;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.opera.OperaDriver;

public class WebDriverManager {
	
	public static final String WEBDRIVER_LOCATION = System.getProperty("user.dir")+"/src/main/resources/webdrivers";
	public static WebDriver driver;
	
	public static WebDriver getWebDriver(final String browserName) {
		//WebDriver driver = null;
		switch (browserName.toUpperCase()) {
		case "CHROME":
			System.setProperty("webdriver.chrome.driver", WEBDRIVER_LOCATION + "/chromedriver.exe");
			ChromeOptions capabilities = new ChromeOptions();
			capabilities.setAcceptInsecureCerts(true);
			driver = new ChromeDriver(capabilities);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			break;
		case "IE":
			System.setProperty("webdriver.ie.driver",WEBDRIVER_LOCATION + "/IEDriverServer.exe");
			driver = new InternetExplorerDriver();
			break;
		case "FIREFOX":
			System.setProperty("webdriver.gecko.driver", WEBDRIVER_LOCATION + "/geckodriver.exe");
			FirefoxProfile profile = new FirefoxProfile();
			profile.setPreference("browser.cache.disk.enable", false);
			profile.setPreference("browser.cache.memory.enable", false);
			profile.setPreference("browser.cache.offline.enable", false);
			profile.setPreference("network.http.use-cache", false);
			FirefoxOptions options = new FirefoxOptions().setProfile(profile);
			driver = new FirefoxDriver(options);
			break;
		case "OPERA":
			System.setProperty("webdriver.opera.driver", WEBDRIVER_LOCATION + "/operadriver.exe");
			driver = new OperaDriver();
			break;
		}
		return driver;
	}

}
