package com.abb.uiautomation.core.pages.MF;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.HashMap;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class ModelFabricationDeploymentActionPage extends WebDriverManager{
	
	public ModelFabricationDeploymentActionPage() {
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//html/body/app-root/div[2]/app-detail/div[2]/iframe")
	public WebElement iframeElement;
	
	@FindBy(xpath = "//div[text()='Model Details']")
	public WebElement tab_ModelDetails;
	
	@FindBy(xpath = "//div[text()='Configuration']")
	public WebElement tab_Configuration;
	
	@FindBy(xpath = "//div[text()='Run Model']")
	public WebElement tab_RunModel;
	
	//@FindBy(xpath ="//input[@value='file']")
	@FindBy(xpath ="//div[text()='File ']/preceding-sibling::div")
	public WebElement radio_RunModel_File;
	
	@FindBy(xpath ="//input[@value='json']")
	public WebElement radio_RunModel_json;
	
	@FindBy(xpath ="//button//span[contains(.,'Upload')]")
	public WebElement btn_RunModel_FileUpload;
	
	@FindBy(xpath ="//textarea[@formcontrolname='inputParam']")
	public WebElement txtarea_RunModel_Input;
	
	@FindBy(xpath = "//span[contains(., 'Run')]")
	public WebElement btn_RunModel_Run;
	
	@FindBy(xpath = "//div[@class='table-container']/div/pre")
	public WebElement txtarea_RunModel_Output;
	
	@FindBy(xpath = "//span[contains(@class,'icon-abb_deployment icon_abb_dias')]")
	public WebElement icon_Deployment;
	
	@FindBy(xpath = "//span[contains(@class,'icon-abb_model-registry icon_abb_dias')]")
	public WebElement icon_ModelRegistry;
	
	@FindBy(xpath="//span[contains(@class,'icon-abb_data-explore1 icon_abb_dias')]")
	public WebElement icon_DataExplore;
	
	@FindBy(xpath="//span[contains(@class,'icon-abb_home_16 icon_abb_16')]")
	public WebElement icon_Home;
	
	@FindBy(xpath="//input[@formcontrolname='configName']")
	public WebElement txtbox_Configuration_ConfigurationName;
	
	@FindBy(xpath="//textarea[@formcontrolname='configDesc']")
	public WebElement txtarea_Configuration_Description;
	
	@FindBy(xpath="//*[@id=\"mat-radio-18\"]/label/div[2]/text()")
	public WebElement radio_Configuration_ConfigurationType_Advanced;
	
	@FindBy(xpath="//*[@id=\"mat-radio-5\"]/label/div[2]/text()")
	public WebElement radio_Configuration_ConfigurtaionType_Simple;
	
	@FindBy(xpath="//input[@formcontrolname='modelName']")
	public WebElement txtbox_ModelDetails_ModelName;
	
	@FindBy(xpath="//input[@formcontrolname='computeTarget']")
	public WebElement txtbox_ModelDetails_ComputeTarget;
	
	@FindBy(xpath="//input[@formcontrolname='deploymentName']")
	public WebElement txtbox_ModelDetails_DeploymentName;
	
	@FindBy(xpath="//input[@formcontrolname='pipDependencies']")
	public WebElement txtbox_ModelDetails_PIPDependencies;
	
	@FindBy(xpath="//textarea[@formcontrolname='deplymentPurpose']")
	public WebElement txtbox_ModelDetails_DeploymentPurpose;
	
	@FindBy(xpath="//input[@formcontrolname='condaDependencies']")
	public WebElement txtbox_ModelDetails_CondaDependencies;
	
	@FindBy(xpath="//textarea[@formcontrolname='script']")
	public WebElement txtbox_ModelDetails_Script;
	
	@FindBy(xpath="//span[text()='Upload']")
	public WebElement btn_ModelDetails_Upload;
	
	@FindBy(xpath="//span[text()='Copy URL']")
	public WebElement btn_ModelDetails_CopyURL;
	
	@FindBy(xpath="//span[text()=' Update ']")
	public WebElement btn_Update;
	
	@FindBy(xpath="//span[text()=' Cancel ']")
	public WebElement btn_Cancel;
	
	
	
	
	public void MFRunModel(HashMap<String, String> parameterMap) {
		
		WebElement ele = null;
		String ElementName = parameterMap.get("SelectInputType");

		System.out.println("Eelement Name in MFSelectModel " + ElementName);
		
		if (ElementName.equals("File"))
		{
			ele = new WebDriverWait(driver, 30000).until(ExpectedConditions.visibilityOf(radio_RunModel_File));
		}
		else if (ElementName.equals("json"))
		{
			ele = new WebDriverWait(driver, 30000).until(ExpectedConditions.visibilityOf(radio_RunModel_json));
		}
		
		if (ele.isDisplayed())
		{
			ele.click();
		}
		
		ExtentsReport.testInfo("ModelFabricDeploymentActionPage clicked on " + ElementName +" for Select Input Type Successful");
		ElementName = parameterMap.get("Upload");
		
		btn_RunModel_FileUpload.click();
		
		ExtentsReport.testInfo("ModelFabricDeploymentActionPage clicked on Upload button Successful");
		
		StringSelection ss = new StringSelection(parameterMap.get("Fileupload"));
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(ss, null);
	   // Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
	    Robot robot;
		try {
			robot = new Robot();
			robot.delay(300);
			robot.keyPress(KeyEvent.VK_ENTER);
	        robot.keyRelease(KeyEvent.VK_ENTER);
	        robot.keyPress(KeyEvent.VK_CONTROL);
	        robot.keyPress(KeyEvent.VK_V);
	        robot.keyRelease(KeyEvent.VK_V);
	        robot.keyRelease(KeyEvent.VK_CONTROL);
	        robot.keyPress(KeyEvent.VK_ENTER);
	        robot.delay(200);
	        robot.keyRelease(KeyEvent.VK_ENTER);
		}
		catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ExtentsReport.testInfo("ModelFabricDeploymentActionPage Uploaded file " + parameterMap.get("Fileupload") +" successful");
		
		ElementName = parameterMap.get("Input");
		
		ele = new WebDriverWait(driver, 12000).until(ExpectedConditions.visibilityOf(txtarea_RunModel_Input));
		
		if (ele.isDisplayed())
		{
			ele.sendKeys(ElementName);
		}
		
		ExtentsReport.testInfo("ModelFabricDeploymentActionPage Entered " + ElementName +" into Input Textbox successful");
		
		ele = new WebDriverWait(driver, 12000).until(ExpectedConditions.visibilityOf(btn_RunModel_Run));
		btn_RunModel_Run.click();
		
		
		
		
	}
}
