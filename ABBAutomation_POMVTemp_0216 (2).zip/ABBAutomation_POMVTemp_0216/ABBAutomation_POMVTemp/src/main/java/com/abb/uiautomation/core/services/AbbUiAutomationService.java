package com.abb.uiautomation.core.services;

import com.abb.uiautomation.core.report.ExtentsReport;

public class AbbUiAutomationService {
	
	/*public void execute(String filePath) throws Exception {
		
		keywordInvokeService keywordInvokeService = new keywordInvokeService(new keywordService());
		keywordInvokeService.execute(filePath);
	}*/
	
	public void execute(String EnviornmentName,String ModuleName, String ExecutionType, String BrowserType) throws Exception {
		
		keywordInvokeService keywordInvokeService = new keywordInvokeService(new keywordService());
		keywordInvokeService.execute(EnviornmentName,ModuleName,ExecutionType,BrowserType);
	}
	
	

	public static void main(String args[]) throws Exception {
		
		//String filePath = "C:\\Abbuiautomation\\SanityTestsuitePOM_VTemp.xlsx";
		AbbUiAutomationService service = new AbbUiAutomationService();
		service.execute("UAT","Sanity Pack","Sanity","Chrome");
	}
}
