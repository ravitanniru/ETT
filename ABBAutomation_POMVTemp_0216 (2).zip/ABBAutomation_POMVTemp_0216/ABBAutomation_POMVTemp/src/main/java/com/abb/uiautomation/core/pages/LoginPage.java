package com.abb.uiautomation.core.pages;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.abb.uiautomation.core.constants.AbbConstants;
import com.abb.uiautomation.core.log.TestLogger;
import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class LoginPage extends WebDriverManager{

	//WebDriver driver;

	public LoginPage() {
		
		this.driver = WebDriverManager.getWebDriver("Chrome");
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}

	public void navigate() 
	{
		String testData = AbbConstants.URL;
		System.out.println("I am in navigate");
		try {
			System.out.println(driver);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			System.out.println(testData);
			driver.get(testData);
			ExtentsReport.testInfo("URL Opened : " + testData + " Successfully");
		} 
		catch (Exception exp)
		{
			throw exp;

		}
	}
	
	
	
	 @FindBy(id = "i0116")
	 public WebElement txtbox_SignIn;
	 
	// ---------------------SIgn In Text Box ---------------------
	 
	 @FindBy(id = "idSIButton9")
	 public WebElement btn_Next;
	 
	public void LoginDAC(HashMap<String, String> parameterMap)
	// public void LoginDAC(String SigninName)
	 {
		ExtentsReport.testInfo("LoginDAC Action Method Start");
		 navigate();
		 EventLibrary.Static_Wait(5000);
		 try {
			EventLibrary.Enter_TextBox_Value(txtbox_SignIn, parameterMap.get("SigninName"));		
			ExtentsReport.testInfo("Entered SigIn Name : " + parameterMap.get("SigninName") + " Successfully");
			EventLibrary.Click_Element(btn_Next);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		 ExtentsReport.testInfo("LoginDAC Action Method End");
	 }
}

