package com.abb.uiautomation.core.pages.SAD;


import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.abb.uiautomation.core.constants.AbbConstants;
import com.abb.uiautomation.core.log.TestLogger;
import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class SADHomePage extends WebDriverManager{
	
	public SADHomePage() {
		// this.driver = WebDriverManager.getWebDriver("Chrome");
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//html/body/app-root/div[2]/app-detail/div[2]/iframe")
	public WebElement iframeElement;
	
	@FindBy(xpath = "(//div[@class='title'])[1]")
	public WebElement SystemConfigurtaionElement;
	
	@FindBy(xpath = "(//div[@class='title'])[2]")
	public WebElement AnomalyDetectionElement;
	
	public void SADMoveToTab(HashMap<String, String> parameterMap) {
		
		WebElement ele = null;
		System.out.println("Moved to frame title");
		
		WebDriverWait wait = new WebDriverWait(driver, 5000);  
	 	wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("iframe-div"));
		

		System.out.println("Moved to frame");
		String ElementName = parameterMap.get("tabName");

		System.out.println("Eelement Name in SADMoveToTab " + ElementName);
		if (ElementName.equalsIgnoreCase("System Configuration")) {
			
			System.out.println("in SAD");
			ele = new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(SystemConfigurtaionElement));
			
		} else if (ElementName.equalsIgnoreCase("Anomaly Detection")) {
			
			ele = new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(AnomalyDetectionElement));
		}

		if (ele.isDisplayed()) {
			
			System.out.println("Element - " + ElementName + " - Displayed");
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ele.click();
			ExtentsReport.testInfo("SADNewSystemPage Clicked on " + ElementName +" Successful");
			//driver.switchTo().defaultContent();
			
		} else {
			
			System.out.println("Element - " + ElementName + " - Not Displayed");
			
		}
	}
	}
	


