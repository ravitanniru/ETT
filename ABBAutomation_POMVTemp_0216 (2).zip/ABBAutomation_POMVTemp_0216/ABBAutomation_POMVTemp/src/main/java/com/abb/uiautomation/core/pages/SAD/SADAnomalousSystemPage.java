package com.abb.uiautomation.core.pages.SAD;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.abb.uiautomation.core.constants.AbbConstants;
import com.abb.uiautomation.core.log.TestLogger;
import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class SADAnomalousSystemPage extends WebDriverManager{
	
	public SADAnomalousSystemPage() {
		// this.driver = WebDriverManager.getWebDriver("Chrome");
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//html/body/app-root/div[2]/app-detail/div[2]/iframe")
	public WebElement iframeElement;
	
	//ID available but its Dynamic
	//@FindBy(id = "mat-input-12")
	//@FindBy(xpath ="//select[contains(.,'ALL')]")
	@FindBy(xpath = "(//select)[1]")
	public WebElement lst_Country;
	
	//ID available but its Dynamic
	//@FindBy(id = "mat-input-13")
	@FindBy(xpath ="(//select)[2]")
	public WebElement lst_Region;
	
	//ID available but its Dynamic
	//@FindBy(id = "mat-input-14")
	@FindBy(xpath ="(//select)[3]")
	public WebElement lst_Plant;
	
	//ID not available
	@FindBy(xpath = "//button/span[text()= ' Submit ']")
	public WebElement btn_Submit;
	
	public void SADAnomalousSystemPage(HashMap<String, String> parameterMap)
	{
		
	}
	
}
