package com.abb.uiautomation.core.pages.SAD;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class SADOpertaionRange extends WebDriverManager{
	
	public SADOpertaionRange() {
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}
	JavascriptExecutor jse = (JavascriptExecutor)driver;
	
	@FindBy(xpath="//input[@placeholder='Tag Description']/preceding::select[1]")
	public WebElement lst_Tag;
	
	
	@FindBy(xpath="//input[@placeholder='Normal Value']")
	public WebElement txt_NormalValue;
	
	
	@FindBy(xpath="//input[@placeholder='+ Range (%)']")
	public WebElement txt_PlusRange;
	
	@FindBy(xpath="//input[@placeholder='- Range (%)']")
	public WebElement txt_MinusRange;
	
	
	/*@FindBy(xpath="//input[@placeholder='- Range (%)']/following::mat-checkbox[contains(@class,'checkbox')][1]")
	public WebElement chk_MainTag;*/
	
	@FindBy(xpath="//input[@placeholder='- Range (%)']/following::mat-checkbox/label/div/input[@type='checkbox']")
	public WebElement chk_MainTag;
	
	
	@FindBy(xpath="//span[text()=' Save ']")
	public WebElement btn_Save;

	public void CreateSADOpertaionRange(HashMap<String, String> parameterMap) throws InterruptedException {
		WebElement ele = null;
		Thread.sleep(1000);
		/*ele = EventLibrary.Verify_Element_Exist(lst_Tag);
		if (ele.isDisplayed())
		{
			System.out.println("-----CreateSADTagSchematic---- Tag Dropdown Element Dispalyed");
			
		}
		else
		{
			System.out.println("-----CreateSADTagMapping---- Tag Dropdown Element Dispalyed");
		}*/
			
		//EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Tag"));
		try{
				  Select select = new Select(lst_Tag);
				  select.selectByValue("0");
			  }
			  catch(Exception e){
			     System.out.println(e.getMessage());
			    WebElement ele1 = driver.findElement(By.xpath("//input[@placeholder='Tag Description']/preceding::select[1]"));
			    Select sel = new Select(ele1);
			    sel.selectByVisibleText(parameterMap.get("Tag"));
			  }
			
		EventLibrary.Enter_TextBox_Value(txt_NormalValue, parameterMap.get("NormalValue"));
		EventLibrary.Enter_TextBox_Value(txt_PlusRange, parameterMap.get("PlusRange"));
		EventLibrary.Enter_TextBox_Value(txt_MinusRange, parameterMap.get("MinusRange"));		
		EventLibrary.Click_Element_JSE(chk_MainTag);
		
		Thread.sleep(1000);
		
		try{
			  Select select = new Select(lst_Tag);
			  select.selectByValue("0");
		  }
		  catch(Exception e){
		     System.out.println(e.getMessage());
		    WebElement ele1 = driver.findElement(By.xpath("//input[@placeholder='Tag Description']/preceding::select[1]"));
		    Select sel = new Select(ele1);
		    sel.selectByVisibleText(parameterMap.get("Tag"));
		  }
		
		EventLibrary.Click_Element(btn_Save);

	}
}
