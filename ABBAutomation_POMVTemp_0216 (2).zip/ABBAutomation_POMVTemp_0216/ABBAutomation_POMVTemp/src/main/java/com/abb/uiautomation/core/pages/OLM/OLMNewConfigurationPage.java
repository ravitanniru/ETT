package com.abb.uiautomation.core.pages.OLM;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class OLMNewConfigurationPage extends WebDriverManager {
	
	public OLMNewConfigurationPage() {
		// this.driver = WebDriverManager.getWebDriver("Chrome");
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "iframe-div")
	public WebElement frame_iframeParent;
	
	//ID -DYNAMIC
	//@FindBy(id="mat-select-0")
	@FindBy(xpath="(//div/mat-select)[1]")
	public WebElement lst_SelectType;
	
	//ID -DYNAMIC
	//@FindBy(id="mat-select-4")
	@FindBy(xpath="(//div/mat-select)[5]")
	public WebElement lst_SelectPeriod;
	
	//ID -DYNAMIC
	//@FindBy(id="mat-input-0")
	@FindBy(xpath="(//div/input[@placeholder='Search']")
	public WebElement input_SelectPeriod;
	
	//@ID - NOT AVAILABLE
	@FindBy(xpath="//div/input[@placeholder='Search']/following::div[1]")
	public WebElement btn_SerachIcon;
	
	//ID - NOT AVAILABLE
	@FindBy(xpath="//button/span[text()=' New Configuration ']")
	public WebElement btn_NewConfiguration;
	
	public void OLMNewConfiguration(HashMap<String, String> parameterMap) {
		
		WebElement ele = null;
		
		String ElementName = parameterMap.get("option");

		System.out.println("Eelement Name in ConfigureNewSystem " + ElementName);
		
		if (ElementName.equalsIgnoreCase("New Configuration")) {	
			
			System.out.println(">>>> " + this.getClass().getName() + " in New Configuration");
			ele = EventLibrary.Verify_Element_Exist(btn_NewConfiguration);
		} 
		
		if (ele.isDisplayed()) {
			
			System.out.println(">>>> " + this.getClass().getName() + "Element - " + ElementName + " - Displayed");
			
			EventLibrary.Click_Element_JSE(ele);
			//ExtentsReport.testInfo("SADNewSystemPage Clicked on " + ElementName +" Successful");
			
		} else {
			System.out.println(">>>> " + this.getClass().getName() + "Element - " + ElementName + " - Not Displayed");
		}
	}

}
