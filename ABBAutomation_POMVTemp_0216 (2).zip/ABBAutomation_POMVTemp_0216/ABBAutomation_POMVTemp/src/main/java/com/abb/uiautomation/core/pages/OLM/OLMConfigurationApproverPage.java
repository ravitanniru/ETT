package com.abb.uiautomation.core.pages.OLM;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class OLMConfigurationApproverPage extends WebDriverManager {

	public OLMConfigurationApproverPage() {
		// this.driver = WebDriverManager.getWebDriver("Chrome");
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//span[@class = 'title'][text() = 'Approvers']")
	public WebElement banner_Approvers;
	
	// ID - DYNAMIC
	// @FindBy(id="mat-input-8")
	@FindBy(xpath = "(//select)[10]")
	public WebElement lst_SelectReviewer;

	// ID - DYNAMIC
	// @FindBy(id="mat-input-9")
	@FindBy(xpath = "(//select)[11]")
	public WebElement lst_SelectApprover;

	// ID - DYNAMIC
	// @FindBy(id="mat-input-10")
	@FindBy(xpath = "//textarea[@formcontrolname='approverDescription']")
	public WebElement textarea_ApproverDescription;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//button/span[text() = ' Cancel ']")
	public WebElement btn_Cancel;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//button/span[text() = ' Save ']")
	public WebElement btn_Save;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//button/span[text() = ' Submit ']")
	public WebElement btn_submit;
	
	public void OLMConfigurationApprover(HashMap<String, String> parameterMap)
	{
		WebElement ele = null;
		
		try {
			
			EventLibrary.Click_Element_JSE(banner_Approvers);
			
			ele = EventLibrary.Verify_Element_Exist(lst_SelectReviewer);
			EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Reviewer"));
			
			ele = EventLibrary.Verify_Element_Exist(lst_SelectApprover);
			EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Approver"));
			
			ele = EventLibrary.Verify_Element_Exist(textarea_ApproverDescription);
			EventLibrary.Enter_TextBox_Value(ele, parameterMap.get("approverDescription"));
			
			ele = EventLibrary.Verify_Element_Exist(btn_Save);
			EventLibrary.Click_Element_JSE(ele);
			
			ele = EventLibrary.Verify_Element_Exist(btn_submit);
			EventLibrary.Click_Element_JSE(ele);
			
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
