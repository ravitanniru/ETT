package com.abb.uiautomation.core.pages;

import java.util.HashMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.utils.WebDriverManager;

public class ClosePage extends WebDriverManager{
	
	public ClosePage() {
		//this.driver = WebDriverManager.getWebDriver("Chrome");
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}
	
	public boolean CloseCurrentBrowser(HashMap<String, String> parameterMap) {
		System.out.println("I am in quitBrowser");

			try {
				Thread.sleep(10000);
				this.driver.quit();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return true;
	
	/*	finally
		{
			return false;
		}*/
	}
}