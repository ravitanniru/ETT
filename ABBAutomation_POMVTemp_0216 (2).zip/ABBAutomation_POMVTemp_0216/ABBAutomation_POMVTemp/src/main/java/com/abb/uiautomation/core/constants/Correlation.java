package com.abb.uiautomation.core.constants;

import java.util.HashMap;

import com.abb.uiautomation.core.pages.*;

public class Correlation {

	public static final HashMap<String, String> correlationMap = new HashMap<String, String>() {
		{
			put("LoginDAC", "LoginPage");
			put("MoveToApplication","HomePage");
			put("CloseCurrentBrowser","ClosePage");
			put("VerifyHomePageElements", "HomePage");
			
			put("SADMoveToTab","SAD.SADHomePage");
			put("ConfigureNewSystem", "SAD.SADNewSystemPage");
			put("CreateSADSystemDetails","SAD.SADSystemDetailsPage");
			put("CreateSADEquipmentMapping","SAD.SADEquipmentMappingPage");
			put("CreateSADTagMapping","SAD.SADTagMappingPage");
			put("CreateSADTagSchematic","SAD.SADTagSchematicPage");
			put("CreateSADOpertaionRange","SAD.SADOpertaionRange");
			put("CreateSADSummary","SAD.SADSummaryPage");
			put("DeleteSystem","SAD.SADNewSystemPage");
			
			put("SADAnomalousSystem","SAD.SADAnomalousSystemPage");
			put("SADSystemOverview","SAD.SADSystemOverviewPage");
			put("SADSyetmHistoricalOverview","SAD.SADSyetmHistoricalOverviewPage");
			put("SADHistoricalAnomalyTrend","SAD.SADHistoricalAnomalyTrendPage");
			put("SADCorrectionAnalysis","SAD.SADCorrectionAnalysisPage");
			
			put("OLMMoveToTab","OLM.OLMHomePage");
			put("OLMNewConfiguration","OLM.OLMNewConfigurationPage");
			put("OLMConfigurationCreateNew","OLM.OLMConfigurationSelectLocationPage");
			put("OLMConfigurationLossCategories","OLM.OLMConfigurationLossCategoriesPage");
			put("OLMConfigurationActualTarget","OLM.OLMConfigurationActualTargetPage");
			put("OLMConfigurationNotifictionRules","OLM.OLMConfigurationNotifictionRulesPage");
			put("OLMConfigurationApprover","OLM.OLMConfigurationApproverPage");
			
			put("OLMNewEvent","OLM.OLMNewEventPage");
			put("OLMNewEventCreate","OLM.OLMNewEventCreatePage");
			
			put("OLMRCALeadTask","OLM.OLMRCALeadTaskPage");
			
			put("MFMoveToTab","MF.ModelFabricHomePage");
			put("MFSelectModel","MF.ModelFabricationDeploymentPage");
			put("MFSelectMovetoTab","MF.ModelFabricationDeploymentPage");
			put("MFRunModel","MF.ModelFabricationDeploymentActionPage");
			
			put("MFNewDeployment","MF.ModelFabricationDeploymentPage");
			put("MFNewDeploymentActivity","MF.ModelFabricationNewDeploymentPage");
			
			put("ModelFabricDataExplorationSubmit","MF.ModelFabricDataExplorationPage");
			put("MoveToRolesAndUserManagementTab","PH.PlatFormHorizontalPage");
			put("PlatformAdminCreateRole","PH.PlatFormHorizontalPage");
			put("PlatformAdminAssignRoleToUser","PH.PlatFormHorizontalPage");
			put("PlatformAdminDeleteRole","PH.PlatFormHorizontalPage");
			put("PlatformAdminRemoveRole","PH.PlatFormHorizontalPage");
			put("MoveToBusinessServicesTab","KSH.KnowlegeServiceHubPage");
			put("KSHCreateService","KSH.KnowlegeServiceHubPage");
			put("KSHEditSrvice","KSH.KnowlegeServiceHubPage");
			put("KSHCopySrvice","KSH.KnowlegeServiceHubPage");
			put("KSHDeleteSrvice","KSH.KnowlegeServiceHubPage");			
			

		}
	};
}

