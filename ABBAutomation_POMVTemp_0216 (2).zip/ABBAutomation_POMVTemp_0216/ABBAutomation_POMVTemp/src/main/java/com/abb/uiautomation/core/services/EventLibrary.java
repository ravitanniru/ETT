package com.abb.uiautomation.core.services;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.utils.WebDriverManager;

public class EventLibrary extends WebDriverManager {

	protected static WebDriver driver = WebDriverManager.driver;
	public static long explicit_timeoutInSeconds =60 ;

	/*protected static final int ID = 1;
	protected static final int CLASS = 2;
	protected static final int LINKTEXT = 3;
	protected static final int XPATH = 4;
	protected static final int CSS = 5;
	protected static final int TAGNAME = 6;*/

	protected static final int VISIBLETEXT = 1;
	protected static final int VALUE = 2;
	protected static final int INDEX = 3;

	public static final String FRAMENAME = "1";
	public static final String FRAMEID = "2";
	private static final String FRAMELEMENT = "3";

	/*
	 * 1)The below method is used to initialize the Webdriver with corresponding
	 * browser
	 */

	/* The below method is used to get the timeStamp */

	public static String Get_Time_Stamp() {
		DateFormat customDate = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
		Date CurrentDate = new Date();
		return customDate.format(CurrentDate);
	}

	/* The below method is used to check if alert is present */

	public static boolean Is_AlertPresent() {
		try {
			Alert a = new WebDriverWait(driver, 5).until(ExpectedConditions.alertIsPresent());
			if (a != null) {
				driver.switchTo().alert().accept();
				return true;
			} else {
				throw new Throwable();
			}
		} catch (Throwable e) {
			return false;
		}

	}

	/* The below method is used to check if alert is present */

	public static String Handle_Alert(WebDriver driver) {
		boolean alert_Status = Is_AlertPresent();
		if (alert_Status == true) {
			Alert alt = driver.switchTo().alert();
			String altMessage = alt.getText();
			alt.accept();
			return altMessage;
		}else {
			return null;
		}
		
	}

	/* The below method is used to switch to frame using frame element */
	public static void waitforFrametoLoadAndSwitchToFrame(String FrameIdentifier, String FrameInfo) {

		switch (FrameIdentifier) {
		case FRAMENAME:
			try {
				WebDriverWait wait = new WebDriverWait(driver, 1);
				System.out.println("i m inside framename");
				wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(FrameInfo));
				System.out.println("detected frame ");
			} catch (org.openqa.selenium.NoSuchElementException | org.openqa.selenium.StaleElementReferenceException
					| org.openqa.selenium.TimeoutException e) {
				System.out.println("There is an exception");
				e.printStackTrace();
			}
			break;
		case FRAMEID:
			try {
				WebDriverWait wait = new WebDriverWait(driver, 1);

				wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(FrameInfo));
				System.out.println("detected frame ");
			} catch (org.openqa.selenium.NoSuchElementException | org.openqa.selenium.StaleElementReferenceException
					| org.openqa.selenium.TimeoutException e) {
				System.out.println("There is an exception");
				e.printStackTrace();
			}
			break;
		case FRAMELEMENT:
			try {
				WebDriverWait wait = new WebDriverWait(driver, 1);

				wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(FrameInfo));
				System.out.println("detected frame ");
			} catch (org.openqa.selenium.NoSuchElementException | org.openqa.selenium.StaleElementReferenceException
					| org.openqa.selenium.TimeoutException e) {
				System.out.println("There is an exception");
				e.printStackTrace();
			}
			break;
		}
	}

	/* The below method is used to switch back to main window */

	public static void swithToMainWin() {
		driver.switchTo().defaultContent();
	}

	/*
	 * The below method is used to closing the driver instance and closing the
	 * browser instance/s intiated by driver instance
	 */

	public void tearDown() {
		driver.close();
		driver.quit();
		driver = null;
	}

	/* The below method is used to Capturing the Screenshot */

	public static String Take_ScreenShot(WebDriver driver) {

		System.out.println("enterd inside take screenshot");
		TakesScreenshot screen = (TakesScreenshot) driver;
		File Source = screen.getScreenshotAs(OutputType.FILE);
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		String DestinationString = System.getProperty("user.dir") + "/TestSceenshots/" + timeStamp + ".png";
		File DestinationPath = new File(DestinationString);

		try {
			FileUtils.copyFile(Source, DestinationPath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return DestinationString;
	}

	/* The below method is used wait for element to be visible on DOM */

	public static WebElement WaitForElement(WebElement element, long explicit_timeoutInSeconds) {
		WebDriverWait wait = new WebDriverWait(driver, explicit_timeoutInSeconds);
		try {
			element = wait.until(ExpectedConditions.visibilityOf(element));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return element;
	}

	/* The below method is used to apply implicit wait */

	public static void Implicit_Wait(int implicit_TimeOutInSeconds) throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(implicit_TimeOutInSeconds, TimeUnit.SECONDS);
	}

	/* The below method is used to apply wait of thread.sleep */

	public static void Static_Wait(long threadWait_TimeoutInSeconds) {
		try {
			Thread.sleep(threadWait_TimeoutInSeconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/* The below method is used to create an Action class */
	public static Actions getAction() {
		Actions action = new Actions(driver);
		return action;
	}

	/* The below method is used to create an Robot class */

	public static Robot getRobot() throws AWTException {
		Robot robot = new Robot();
		robot.delay(300);
		return robot;
	}

	/*
	 * The below method is used to select the checkbox with the specified value from
	 * multiple checkboxes.
	 */

	public void Select_List_Option_Value(WebElement element, String valueToSelect) {
		List<WebElement> allOptions = element.findElements(By.tagName("Option"));
		for (WebElement option : allOptions) {
			System.out.println("Option value " + option.getText());
			if (valueToSelect.equals(option.getText())) {
				option.click();
				break;
			}
		}
	}

	/*
	 * The below method is used to Select a Checkbox, if it is not selected already
	 */
	public static void Select_Checkbox(WebElement element) {
		try {
			if (element.isSelected()) {
				System.out.println("Checkbox: " + element + "is already selected");
			} else {
				element.click();
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to select the checkbox: " + element);
		}
	}
	/* The below method isused to De-select a Checkbox, if it is selected already */

	public void DeSelect_Checkbox(WebElement element) {
		try {
			if (element.isSelected()) {
				element.click();
			} else {
				System.out.println("Checkbox: " + element + "is already deselected");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to deselect checkbox: " + element);
		}
	}

	/*
	 * The below method is used to select the listelement / option from the select
	 * listbox
	 */

	public static void Select_ListElement(WebElement element, int selectStrategy, Object strategyValue)
			throws InterruptedException {
		try {
			System.out.println("@@@@@@@@@@@@  "+element);
			System.out.println("@@@@@@@@@@@@  "+selectStrategy);
			System.out.println("@@@@@@@@@@@@  "+strategyValue);
			EventLibrary.WaitForElement(element, explicit_timeoutInSeconds);
			WebElement webElement = element;
			
			
			Select select = new Select(webElement);

			switch (selectStrategy) {
			case VISIBLETEXT:
				System.out.println("case 1");
				select.selectByVisibleText((String) strategyValue);
				break;
			case VALUE:
				System.out.println("case 2");
				select.selectByValue((String) strategyValue);
				break;
			case INDEX:
				System.out.println("case 3");
				select.selectByIndex(((Integer) strategyValue).intValue());
				break;
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}
	}

	/* The below method is used to mouse Hover on element */

	public static void mouseOver(WebElement element) throws InterruptedException {
		try {
			new Actions(driver).moveToElement(element).perform();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/* The below methos is to perform the Dag and Drop */

	public static void Drag_And_Drop(WebElement DragFromElement, WebElement DropToElement) {
		try {
			new Actions(driver).dragAndDrop(DragFromElement, DropToElement).build().perform();
		} catch (Exception e) {
			Actions builder = new Actions(driver);
			Action dragAndDrop = builder.clickAndHold(DragFromElement).moveToElement(DropToElement)
					.release(DropToElement).build();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			dragAndDrop.perform();
		}
	}

	/* The below method is used to Enter value to text box */

	public static void Enter_TextBox_Value(WebElement element, String textValue) throws InterruptedException {
		try {
			element = WaitForElement(element, explicit_timeoutInSeconds);
			element.sendKeys(textValue);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/* The below method is used to click on element */

	public static void Click_Element(WebElement element) throws InterruptedException {
		try {
			//element = WaitForElement(element, explicit_timeoutInSeconds);
			element.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/* The below method is used to click on element */

	public static void Click_Wait_Element(WebElement element) throws InterruptedException {
		try {
			element = WaitForElement(element, explicit_timeoutInSeconds);
			element.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/* The below method is used to fetch the text out of element */

	public static String GetTxt_Element(WebElement element) throws InterruptedException {
		String eleText = "";
		try {
			element = WaitForElement(element, explicit_timeoutInSeconds);
			eleText = element.getText();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return eleText;
	}
	/* The below method is used to click on element using JavascriptExecutor */

	public static void Click_Element_JSE(WebElement element) {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].click()", element);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void Upload_File(String filePath) {
		StringSelection stringselection = new StringSelection(filePath);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringselection, null);
		Robot robot;
		try {
			robot = new Robot();
			robot.delay(300);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.delay(200);
			robot.keyRelease(KeyEvent.VK_ENTER);
		} catch (AWTException e) {
			e.printStackTrace();
		}
	}

	/* The below method is used to set the desired capabilities for chrome */

	public static DesiredCapabilities setCapabilities() {
		DesiredCapabilities caps = DesiredCapabilities.chrome();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--incognito");
		// options.setExperimentalOption("prefs", prefs);
		caps.setCapability(ChromeOptions.CAPABILITY, options);
		caps.setAcceptInsecureCerts(true);
		return caps;
	}
	
	public static WebElement JSE_GetElementByID(String idValue , WebDriver driver) {
		String javascript = "return document.getElementById('"+idValue+"')";  
		System.out.println(javascript);
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;  
		return  (WebElement) jsExecutor.executeScript(javascript); 
	}
	
	public static WebElement JSE_GetElementByTagName(String tagName,int index , WebDriver Driver) {
		String javascript = "return document.getElementsByTagName('"+tagName+"')["+index+"]";  
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;  
		return (WebElement) jsExecutor.executeScript(javascript); 
	}
	
	public static WebElement Verify_Element_Exist(WebElement element) {
		try {
			element = new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(element));
		}catch(Exception e) {
			e.printStackTrace();
		}
		return element;
		
	}
	
}
