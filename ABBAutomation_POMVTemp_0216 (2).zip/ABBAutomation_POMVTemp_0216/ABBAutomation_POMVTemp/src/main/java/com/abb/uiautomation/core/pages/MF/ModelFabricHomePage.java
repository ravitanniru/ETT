package com.abb.uiautomation.core.pages.MF;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.abb.uiautomation.core.constants.AbbConstants;
import com.abb.uiautomation.core.log.TestLogger;
import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class ModelFabricHomePage extends WebDriverManager {
	
	public ModelFabricHomePage()
	{
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//html/body/app-root/div[2]/app-detail/div[2]/iframe")
	public WebElement iframeElement;
	
	@FindBy(xpath ="//div[text()='Deployment']")
	public WebElement lnk_Deployement;
	
	@FindBy(xpath ="//div[text()='Model Registry']")
	public WebElement lnk_ModelRegistry;
	
	@FindBy(xpath ="//div[text()='Data Exploration']")
	public WebElement lnk_DataExploration;
	
	public void MFMoveToTab(HashMap<String, String> parameterMap) {
		
		WebElement ele = null;
		System.out.println("Moved to frame title");
		try {
			Thread.sleep(30000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebDriverWait wait = new WebDriverWait(driver, 80000);
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("iframe-div"));

		System.out.println("Moved to frame");
		String ElementName = parameterMap.get("tabName");

		System.out.println("Eelement Name in MFMoveToTab " + ElementName);
		
		if (ElementName.equalsIgnoreCase("Deployment")) {			
			ele = new WebDriverWait(driver, 30000).until(ExpectedConditions.visibilityOf(lnk_Deployement));		
			System.out.println("Deployment option available");
		} else if (ElementName.equalsIgnoreCase("Model Registry")) {
			
			ele = new WebDriverWait(driver, 30000).until(ExpectedConditions.visibilityOf(lnk_ModelRegistry));
		} else if (ElementName.equalsIgnoreCase("Data Exploration")) {
			
			ele = new WebDriverWait(driver, 30000).until(ExpectedConditions.visibilityOf(lnk_DataExploration));
		}

		if (ele.isDisplayed()) {
			ele.click();
			ExtentsReport.testInfo("ModelFabricHomePage Move To Tab " + ElementName +" Successful");
		} else {
			System.out.println("Element - " + ElementName + " - Not Displayed");
		}
	}
	}