package com.abb.uiautomation.core.services;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;

import com.abb.uiautomation.core.interfaces.IKeywords;
import com.abb.uiautomation.core.log.TestLogger;
import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.utils.ByObjectUtils;
import com.abb.uiautomation.core.utils.EventExecutor;
import com.abb.uiautomation.core.utils.WebDriverManager;
import com.abb.uiautomation.core.constants.AbbConstants;

public class keywordService implements IKeywords {

	protected WebDriver driver;

	public keywordService(WebDriver driver) {
		this.driver = driver;
	}

	public keywordService() {
		super();
	}

	@SuppressWarnings("finally")
	@Override
	public boolean launchBrowser(String elementName,String keyword, String locatorType, String locatorValue, String testData,
			String expectedResult, String testStepId) {
		System.out.println("I am in launchBrowser");
		try 
		{
			this.driver = WebDriverManager.getWebDriver(testData);
			this.driver.manage().window().maximize();
			return true;
		} 
		catch (Exception exp) {

			throw exp;
		}
		finally
		{
			return false;
		}
	}
	
	
	@SuppressWarnings("finally")
	@Override
	public boolean navigate(String elementName,String keyword, String locatorType, String locatorValue, String testData,
			String expectedResult, String testStepId) {
		System.out.println("I am in navigate");
		try {
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.get(testData);
			
			ExtentsReport.testPasedMessage("Navigate to " + testData + " Successful");
			TestLogger.testMessage("Navigate to " + testData + " Successful");
			Reporter.log("Navigate to " + testData + " Successful");
			
			return true;

		} catch (Exception exp) 
		{
			ExtentsReport.testFail("Navigate to " + testData + " Unsuccessful");
			TestLogger.testMessage("Navigate to " + testData + " Unsuccessful");
			Reporter.log("Navigate to " + testData + " Unsuccessful");
			throw exp;
			
		}
	/*  finally 
		{
			return false;
		}*/
	}
	

	public boolean quitBrowser(String elementName,String keyword, String locatorType, String locatorValue, String testData,
			String expectedResult, String testStepId) throws Exception {
		System.out.println("I am in quitBrowser");
		try {
			Thread.sleep(20000);
			this.driver.quit();
			return true;
		} catch (Exception exp) 
		{

			throw exp;
		}
	/*	finally
		{
			return false;
		}*/
	}
	
	

	public boolean staticWait(String elementName,String keyword, String locatorType, String locatorValue, String testData,
			String expectedResult, String testStepId) {
		System.out.println("I am in staticWait");

			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			//driver.quit();
			return true;
		
	/*	finally
		{
			return false;
		}*/
	}


	@Override
	public boolean inputText(String elementName,String keyword, String locatorType, String locatorValue, String testData,
			String expectedResult, String testStepId) throws Exception {
		System.out.println("I am in inputText");
		
		try {
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			
			if (locatorValue.contains("loginfmt")) {
				By element = ByObjectUtils.getByObject(locatorType, locatorValue);
				EventExecutor.enterText(driver, element, testData);
			}
			else
			{
				EventExecutor.enterTextiframe(driver, locatorType,locatorValue,testData);
			}
			
			ExtentsReport.testPasedMessage("inputText to " + elementName + " - " + testData + " Successful");
			TestLogger.testMessage("inputText to " + elementName + " - " + testData + " Successful");
			Reporter.log("inputText to " + elementName + " - " + testData + " Successful");
			
			return true;
		} catch (Exception exp) {
			
			ExtentsReport.testFail("inputText to " + elementName + " - " + testData +" Unsuccessful");
			TestLogger.testMessage("inputText to " + elementName + " - " + testData +" Unsuccessful");
			Reporter.log("inputText to " + elementName + " - " + testData +" Unsuccessful");
			throw exp;
		}
	/*	finally
		{
			ExtentsReport.testFail("inputText to " + elementName + " - " + testData +" Unsuccessful");
			TestLogger.testMessage("inputText to " + elementName + " - " + testData +" Unsuccessful");
			Reporter.log("inputText to " + elementName + " - " + testData +" Unsuccessful");
			return false;
		}*/
	}



	@Override
	public boolean click(String elementName,String keyword, String locatorType, String locatorValue, String testData,
			String expectedResult,	String testStepId) throws Exception {
		System.out.println("I am in click");
		try {
			driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
			By element = ByObjectUtils.getByObject(locatorType, locatorValue);
			EventExecutor.iframeClick(driver, locatorType,locatorValue,testData);		
			ExtentsReport.testPasedMessage("Click on " + elementName + " - " + testData + " Successful");
			TestLogger.testMessage("Click on " + elementName + " - " + testData + " Successful");
			Reporter.log("Click on " + elementName + " - " + testData +" Successful");
			
			return true;
		} catch (Exception exp) {
			
			ExtentsReport.testFail("Click on " + elementName + " - " + testData + " Unsuccessful");
			TestLogger.testMessage("Click on " + elementName + " - " + testData + " Unsuccessful");
			Reporter.log("Click on " + elementName + " - " + testData + " Unsuccessful");
			exp.printStackTrace();
			throw exp;
		}
	/*	finally
		{
			ExtentsReport.testFail("Click on " + elementName + " - " + testData + " Unsuccessful");
			TestLogger.testMessage("Click on " + elementName + " - " + testData + " Unsuccessful");
			Reporter.log("Click on " + elementName + " - " + testData + " Unsuccessful");
			return false;
		}*/
	}


	@Override
	public boolean isElementExist(String elementName,String keyword, String locatorType, String locatorValue, String testData,
			String expectedResult, String testStepId) {
		System.out.println("I am in isElementExist");
		try {
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			By element = ByObjectUtils.getByObject(locatorType, locatorValue);
			boolean status = EventExecutor.isElementExist(driver, locatorType,locatorValue,testData);
			if (status) {
				
				ExtentsReport.testPasedMessage("Verify Element Exist for " + elementName + " - " + testData + " Successful");
				TestLogger.testMessage("Verify Element Exist for " + elementName + " - " + testData + " Successful");
				Reporter.log("Verify Element Exist for " + elementName + " - " + testData + " Successful");
			}
			else {
				
				ExtentsReport.testFail("Verify Element Exist for " + elementName + " - " + testData + " Unsuccessful");
				TestLogger.testMessage("Verify Element Exist for " + elementName + " - " + testData + " Unsuccessful");
				Reporter.log("Verify Element Exist for " + elementName + " - " + testData + " Unsuccessful");
			}
			return status;
		} catch (Exception exp) {
			
			ExtentsReport.testFail("Verify Element Exist for " + elementName + " - " + testData + " Unsuccessful");
			TestLogger.testMessage("Verify Element Exist for " + elementName + " - " + testData + " Unsuccessful");
			Reporter.log("Verify Element Exist for " + elementName + " - " + testData + " Unsuccessful");
			throw exp;
		}
	/*	finally
		{
			ExtentsReport.testFail("Verify Element Exist for " + elementName + " - " + testData + " Unsuccessful");
			TestLogger.testMessage("Verify Element Exist for " + elementName + " - " + testData + " Unsuccessful");
			Reporter.log("Verify Element Exist for " + elementName + " - " + testData + " Unsuccessful");
			return false;
		}*/
	}


	@Override
	public boolean select(String elementName,String keyword, String locatorType, String locatorValue, String testData, 
			String expectedResult,	String testStepId) throws Exception {
		System.out.println("I am in Select");
		try {
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			By element = ByObjectUtils.getByObject(locatorType, locatorValue);
			EventExecutor.selectiframe(driver, locatorType,locatorValue,testData);
			ExtentsReport.testPasedMessage("Select Element from " + elementName + " - " + testData + " Successful");
			TestLogger.testMessage("Select Element from " + elementName + " - " + testData + " Successful");
			Reporter.log("Select Element from  " + elementName + " - " + testData +" Successful");
			return true;
		} 
		catch (Exception exp) 
		{
			ExtentsReport.testFail("Select Element from " + elementName + " - " + testData + " Unsuccessful");
			TestLogger.testMessage("Select Element from " + elementName + " - " + testData + " Unsuccessful");
			Reporter.log("Select Element from  " + elementName + " - " + testData +" Unsuccessful");
			throw exp;
		}
	/*	finally
		{
			ExtentsReport.testPasedMessage("Select Element from " + elementName + " - " + testData + " Unsuccessful");
			TestLogger.testMessage("Select Element from " + elementName + " - " + testData + " Unsuccessful");
			Reporter.log("Select Element from  " + elementName + " - " + testData +" Unsuccessful");
			return false;
		}*/
	}



	public boolean uploadFile(String elementName,String keyword, String locatorType, String locatorValue, String testData,
			String expectedResult, String testStepId)
	{
		try 
		{
			EventExecutor.uploadFile(driver, locatorType,locatorValue,testData);
			ExtentsReport.testPasedMessage("Upload File for " + elementName + " - " + testData + " Successful");
			TestLogger.testMessage("Upload File for " + elementName + " - " + testData + " Successful");
			Reporter.log("Upload File for " + elementName + " - " + testData +" Successful");
			return true;
		} 
		catch (InterruptedException e)
		{
			ExtentsReport.testFail("Upload File for " + elementName + " - " + testData + " Unsuccessful");
			TestLogger.testMessage("Upload File for " + elementName + " - " + testData + " Unsuccessful");
			Reporter.log("Upload File for " + elementName + " - " + testData +" Unsuccessful");
			e.printStackTrace();
		}
	/*	finally
		{
			ExtentsReport.testPasedMessage("Upload File for " + elementName + " - " + testData + " Unsuccessful");
			TestLogger.testMessage("Upload File for " + elementName + " - " + testData + " Unsuccessful");
			Reporter.log("Upload File for " + elementName + " - " + testData +" Unsuccessful");
			return false;
		}*/
		return false;
	}
	
	public boolean compareData(String elementName,String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId)
	{
		boolean status = EventExecutor.compareData(driver, locatorType,locatorValue,testData);
		
		if (status)
		{
			ExtentsReport.testPasedMessage("Data Comparision " + elementName + " - " + testData + " Successful");
			TestLogger.testMessage("Data Comparision " + elementName + " - " + testData + " Successful");
			Reporter.log("Data Comparision " + elementName + " - " + testData +" Successful");
			return true;
		}
		
		else
		{
			ExtentsReport.testFail("Data Comparision " + elementName + " - " + testData + " Unsuccessful");
			TestLogger.testMessage("Data Comparision " + elementName + " - " + testData + " Unsuccessful");
			Reporter.log("Data Comparision " + elementName + " - " + testData +" Unsuccessful");
			return false;
		}
		
		
	}
	

	public boolean selectCheckBox(String elementName,String keyword, String locatorType, String locatorValue, String testData,
			String expectedResult, String testStepId) 
	{
		try 
		{
			EventExecutor.selectCheckBox(driver, locatorType,locatorValue,testData);
			ExtentsReport.testPasedMessage("Checkbox Select for " + elementName + " - " + testData + " Successful");
			TestLogger.testMessage("Checkbox Select for " + elementName + " - " + testData + " Successful");
			Reporter.log("Checkbox Select for " + elementName + " - " + testData +" Successful");
			return true;
		} 
		catch (InterruptedException e) 
		{
			ExtentsReport.testPasedMessage("Checkbox Select for " + elementName + " - " + testData + " Unsuccessful");
			TestLogger.testMessage("Checkbox Select for " + elementName + " - " + testData + " Unsuccessful");
			Reporter.log("Checkbox Select for " + elementName + " - " + testData +" Unsuccessful");
			e.printStackTrace();
		}
	/*	finally
		{
			ExtentsReport.testPasedMessage("Checkbox Select for " + elementName + " - " + testData + " Unsuccessful");
			TestLogger.testMessage("Checkbox Select for " + elementName + " - " + testData + " Unsuccessful");
			Reporter.log("Checkbox Select for " + elementName + " - " + testData +" Unsuccessful");
			return false;
		}*/
		return false;
	}
	

	public boolean dragDrop(String elementName,String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId)
	{
		try 
		{
			EventExecutor.dragDrop(driver, locatorType,locatorValue,testData);
			ExtentsReport.testPasedMessage("Darg and Drop for " + elementName + " - " + testData + " Successful");
			TestLogger.testMessage("Darg and Drop for " + elementName + " - " + testData + " Successful");
			Reporter.log("Darg and Drop for " + elementName + " - " + testData +" Successful");
			return true;
		}
		catch (InterruptedException e) 
		{
			ExtentsReport.testPasedMessage("Darg and Drop for " + elementName + " - " + testData + " Unsuccessful");
			TestLogger.testMessage("Darg and Drop for " + elementName + " - " + testData + " Unsuccessful");
			Reporter.log("Darg and Drop for " + elementName + " - " + testData +" Unsuccessful");
			e.printStackTrace();
		}
	/*	finally
		{
			ExtentsReport.testPasedMessage("Darg and Drop for " + elementName + " - " + testData + " Unsuccessful");
			TestLogger.testMessage("Darg and Drop for " + elementName + " - " + testData + " Unsuccessful");
			Reporter.log("Darg and Drop for " + elementName + " - " + testData +" Unsuccessful");
			return false;
		}*/
		return false;
	}	
}
