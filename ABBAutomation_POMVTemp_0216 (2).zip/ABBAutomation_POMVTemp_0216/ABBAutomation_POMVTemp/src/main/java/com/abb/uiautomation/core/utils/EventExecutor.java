package com.abb.uiautomation.core.utils;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import javax.lang.model.element.Element;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EventExecutor
{
	

	public static void navigate(WebDriver driver, String testData) 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\JunkFolder\\ImpLibs\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
	}

	public static void enterText(WebDriver driver, By obj, String testData) 
	{

		//WebElement ele = (new WebDriverWait(driver, 120)).until(ExpectedConditions.presenceOfElementLocated(obj));
		
		 WebElement ele =  new WebDriverWait(driver, 120).
				 until(ExpectedConditions.visibilityOfElementLocated(obj));

		// driver.findElement(obj);
		highLighterMethod(driver, ele);
		ele.sendKeys(testData);
	}
	
	public static void enterTextiframe(WebDriver driver, String locatorType, String locatorValue, 
			String testData) throws InterruptedException 
	{
			System.out.println("In enterTextiframe");
			Thread.sleep(5000);
			driver.switchTo().frame(driver.findElement(By.xpath("//html/body/app-root/div[2]/app-detail/div[2]/iframe")));
			System.out.println("Moved to frame");
			WebElement ele = driver.findElement(By.xpath(locatorValue));
			System.out.println("Moved to frame element " + ele);
			ele.sendKeys(testData);
			driver.switchTo().defaultContent();
			}

	public static void click(WebDriver driver, By obj) {
		WebElement ele =  new WebDriverWait(driver, 120).
				 until(ExpectedConditions.visibilityOfElementLocated(obj));
		highLighterMethod(driver, ele);
		driver.findElement(obj).click();
	}
	
	public static void iframeClick(WebDriver driver, String locatorType, String locatorValue, 
			String testData) throws InterruptedException {
		
		if (locatorValue.contains("Advanced") || locatorValue.contains("(unsafe)") ||
				locatorValue.contains("Next") || locatorValue.contains("System Anomaly Detection") ||
				locatorValue.contains("navbox-trigger") || locatorValue.contains("abb_model-fabric.svg"))
						{
			By element = ByObjectUtils.getByObject(locatorType, locatorValue);
			click(driver,element);
		}
		else 
		{
			if (locatorValue.contains("title") || locatorValue.contains("[text()='Deployment']")) {
				Thread.sleep(20000);
			}
			else
			{
				Thread.sleep(1500);
			}
			System.out.println("Moved to frame title");
			driver.switchTo().frame(driver.findElement(By.xpath("//html/body/app-root/div[2]/app-detail/div[2]/iframe")));
			System.out.println("Moved to frame");
			WebElement ele = driver.findElement(By.xpath(locatorValue));
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("arguments[0].click()", ele);
			driver.switchTo().defaultContent();
		}
	}
	
	public static void selectiframe(WebDriver driver, String locatorType, String locatorValue, 
			String testData) throws InterruptedException {
		System.out.println("In enterTextiframe");
		Thread.sleep(2000);
		driver.switchTo().frame(driver.findElement(By.xpath("//html/body/app-root/div[2]/app-detail/div[2]/iframe")));
		System.out.println("Moved to frame");
		//WebElement ele = driver.findElement(By.xpath(locatorValue));
		Select ele = new Select(driver.findElement(By.xpath(locatorValue)));
		System.out.println("Moved to frame Select Element " + ele);
		ele.selectByIndex(1);
		//ele.selectByVisibleText(locatorValue);
		driver.switchTo().defaultContent();
		
	}
	
	public static void select(WebDriver driver, By obj, String testData) {
		WebElement ele = driver.findElement(obj);
		highLighterMethod(driver, ele);
		Select dropdown = new Select(driver.findElement(obj));
		dropdown.selectByVisibleText(testData);
	}

	public static boolean isElementExist(WebDriver driver, String locatorType, String locatorValue, String testData) {
		System.out.println("I am in isElementExist");
		if (locatorValue.contains("Note: For mapping, drag and drop the tags") ||
				locatorValue.contains("cdk-step-content-0-4") ||
				locatorValue.contains("cdk-step-content-0-5"))
		{
			System.out.println("Moved to frame title");
			driver.switchTo().frame(driver.findElement(By.xpath("//html/body/app-root/div[2]/app-detail/div[2]/iframe")));
			System.out.println("Moved to frame");
			By obj  = ByObjectUtils.getByObject(locatorType, locatorValue); 
			WebElement ele =  new WebDriverWait(driver, 120).
					 until(ExpectedConditions.visibilityOfElementLocated(obj));
			if (ele.isDisplayed())
			{
				highLighterMethod(driver, ele);
				driver.switchTo().defaultContent();
				return true;
			}
			else
				driver.switchTo().defaultContent();
				return false;
		}
		else
		{
			By obj  = ByObjectUtils.getByObject(locatorType, locatorValue); 
			WebElement ele =  new WebDriverWait(driver, 120).
					 until(ExpectedConditions.visibilityOfElementLocated(obj));
			if (ele.isDisplayed())
			{
				highLighterMethod(driver, ele);
				return true;
			}
			else
				return false;
		}
	}

	public static void highLighterMethod(WebDriver driver, WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('style', 'background: green; border: 3px solid blue;');", element);
	}

	public static void staticWait(WebDriver driver, String testData) {
		int waitTime = Integer.parseInt(testData);
		WebDriverWait wait = new WebDriverWait(driver, waitTime);
	}

	public static void uploadFile(WebDriver driver, String locatorType, String locatorValue, String testData) throws InterruptedException 
	{
		System.out.println("Moved to frame title");
		driver.switchTo().frame(driver.findElement(By.xpath("//html/body/app-root/div[2]/app-detail/div[2]/iframe")));
		System.out.println("Moved to frame");
		WebElement ele = driver.findElement(By.xpath(locatorValue));
		ele.click();
		
		
		
		StringSelection ss = new StringSelection(testData);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(ss, null);
	   // Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
	    Robot robot;
		try {
			robot = new Robot();
			robot.delay(300);
			robot.keyPress(KeyEvent.VK_ENTER);
	        robot.keyRelease(KeyEvent.VK_ENTER);
	        robot.keyPress(KeyEvent.VK_CONTROL);
	        robot.keyPress(KeyEvent.VK_V);
	        robot.keyRelease(KeyEvent.VK_V);
	        robot.keyRelease(KeyEvent.VK_CONTROL);
	        robot.keyPress(KeyEvent.VK_ENTER);
	        robot.delay(200);
	        robot.keyRelease(KeyEvent.VK_ENTER);
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Thread.sleep(10000);
		//driver.switchTo().activeElement().sendKeys(testData);
		driver.switchTo().defaultContent();	
    }

	public static void selectCheckBox(WebDriver driver, String locatorType, String locatorValue, String testData) throws InterruptedException {
		// TODO Auto-generated method stub
		System.out.println("In selectCheckBox");
		Thread.sleep(2000);
		driver.switchTo().frame(driver.findElement(By.xpath("//html/body/app-root/div[2]/app-detail/div[2]/iframe")));
		System.out.println("Moved to frame");
		WebElement ele = driver.findElement(By.xpath(locatorValue));
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click()", ele);
		//ele.click();
		driver.switchTo().defaultContent();
		
	}

	public static void dragDrop(WebDriver driver, String locatorType, String locatorValue, String testData) throws InterruptedException {
		System.out.println("In dargDrop");
		Thread.sleep(2000);
		driver.switchTo().frame(driver.findElement(By.xpath("//html/body/app-root/div[2]/app-detail/div[2]/iframe")));
		
		WebElement From = driver.findElement(By.xpath(locatorValue));
		WebElement To = driver.findElement(By.xpath("//div[@class='img-wrapper']"));
		
		Thread.sleep(2000);
		
		Actions act=new Actions(driver);
		
		System.out.println(act.toString());	
		act.dragAndDrop(From, To).build().perform();
		System.out.println("Action Performed");
		driver.switchTo().defaultContent();
		
	}

	public static boolean compareData(WebDriver driver, String locatorType, String locatorValue, String testData)
	{
		System.out.println("In compareData");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.switchTo().frame(driver.findElement(By.xpath("//html/body/app-root/div[2]/app-detail/div[2]/iframe")));
		
		WebElement area = driver.findElement(By.xpath(locatorValue));
		String actualText = area.getText();
		
		System.out.println("actualText   " + actualText);
		
		if (actualText.contains("Traceback (most recent call last)"))
		{
			driver.switchTo().defaultContent();
			return true;
		}
		else
		{
			driver.switchTo().defaultContent();
			return false;
		}
			
	}
	
	
}
