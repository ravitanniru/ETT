package com.abb.uiautomation.core.pages.KSH;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.abb.uiautomation.core.pages.PH.PlatFormHorizontalPage;
import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class KnowlegeServiceHubPage extends WebDriverManager {
	

	public KnowlegeServiceHubPage() {
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div[text()='Business Service']")
	public WebElement btn_Business_Service;
	
	
	@FindBy(xpath="//a[.='Business Service']")
	public WebElement lbl_Business_Service;
	
	
	@FindBy(xpath="//span[.=' Create Service ']")
	public WebElement btn_Create_Service;
	
	
	@FindBy(xpath="//input[@placeholder='Service ID']")
	public WebElement txt_ServiceId;
	
	
	@FindBy(xpath="//input[@placeholder='Service Name']")
	public WebElement txt_Service_Name;
	
	@FindBy(xpath="//textarea[@formcontrolname='svcDescription']")
	public WebElement txt_Service_Description;
	
	
	@FindBy(xpath="//input[contains(@formcontrolname,'tag')]")
	public WebElement txt_SearchTag;
	
	
	@FindBy(xpath="//textarea[@formcontrolname='queryString']")
	public WebElement txt_QueryString;
	
	
	@FindBy(xpath="//select[@formcontrolname='industryVertical']")
	public WebElement select_Industry;
	
	@FindBy(xpath = "//select[@formcontrolname='valuePillar']")
	public WebElement select_ValuePillar ;
	
	
	@FindBy(xpath = "//mat-select[@formcontrolname='valueDriver']")
	public WebElement select_ValueDriver ;
	
	
	@FindBy(xpath = "//select[@formcontrolname='svcType']")
	public WebElement select_ServiceType ;
	
	
	@FindBy(xpath = "//div[@class='mat-slide-toggle-thumb-container']")
	public WebElement btn_FlagStatus;
	
	
	@FindBy(xpath = "//button[contains(.,'Save')]")
	public WebElement btn_Save;
	
	
	@FindBy(xpath = "//mat-sidenav//ul/li[3]")
	public WebElement btn_BusinessService_SideNav;
	
	
	@FindBy(xpath = "//div[text()='Custom Service']")
	public WebElement tab_CustomService;
	
	
	@FindBy(xpath = "//input[@placeholder='Search']")
	public WebElement txt_BusinessServiceSearch;
	
	@FindBy(xpath = "//button//span[text()=' Update ']")
	public WebElement btn_UpdateService;
		
	@FindBy(xpath = "//button//span[text() = ' Copy Service ']")
	public WebElement btn_CopyService;
	
	
	@FindBy(xpath = "//button//span[text() = ' Run test ']")
	public WebElement btn_RunTest;
	
	
	@FindBy(xpath = "//button//span[text()=' YES ']")
	public WebElement btn_YES_to_delete_service;
	
	public static WebElement selectValueDriverOptions(String Value) {
		return driver.findElement(By.xpath("//span[text()='"+Value+"']"));
	}
	
	public void MoveToBusinessServicesTab(HashMap<String, String> parameterMap) throws Exception {
		System.out.println("Enterd MoveToRolesAndUserManagementTab@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ");
		WebElement ele = null;
		System.out.println("Moved to frame title");
		EventLibrary.waitforFrametoLoadAndSwitchToFrame("1","iframe-div");
		System.out.println("Moved to frame");
		String ElementName = parameterMap.get("tabName");

		System.out.println("Eelement Name in SADMoveToTab " + ElementName);
		if (ElementName.equalsIgnoreCase("Business Services")) {

			ele = new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(btn_Business_Service));
			System.out.println("in KSH");
			EventLibrary.Click_Element(ele);
			EventLibrary.Verify_Element_Exist(lbl_Business_Service);
			
		}
	}
	
	public void KSHCreateService(HashMap<String, String> parameterMap) throws InterruptedException {		
		
		EventLibrary.Click_Element_JSE(btn_Create_Service);
		EventLibrary.Enter_TextBox_Value(txt_ServiceId, parameterMap.get("ServiceId"));
		EventLibrary.Enter_TextBox_Value(txt_Service_Name, parameterMap.get("ServiceName"));
		EventLibrary.Enter_TextBox_Value(txt_Service_Description, parameterMap.get("ServiceDescription"));
		EventLibrary.Enter_TextBox_Value(txt_SearchTag, parameterMap.get("SearchTag"));
		EventLibrary.Enter_TextBox_Value(txt_QueryString, parameterMap.get("QueryString"));
		EventLibrary.Select_ListElement(select_ServiceType, 1, parameterMap.get("ServiceType"));
		EventLibrary.Select_ListElement(select_ValuePillar, 1, parameterMap.get("ValuePillar"));
		EventLibrary.Static_Wait(5);
		EventLibrary.Select_ListElement(select_Industry, 1, parameterMap.get("Industry"));
		EventLibrary.Static_Wait(5);
		EventLibrary.Click_Element_JSE(btn_FlagStatus);
		EventLibrary.Click_Element_JSE(select_ValueDriver);
		WebElement ValueDriverOption = selectValueDriverOptions(parameterMap.get("ValueDriver"));
		EventLibrary.Click_Element_JSE(ValueDriverOption);
		EventLibrary.Click_Element_JSE(btn_Save);
		EventLibrary.Static_Wait(5);

		EventLibrary.Click_Element_JSE(btn_BusinessService_SideNav);
		EventLibrary.Static_Wait(5);
		EventLibrary.Click_Element_JSE(tab_CustomService);
		EventLibrary.Static_Wait(5);
		EventLibrary.Enter_TextBox_Value(txt_BusinessServiceSearch, parameterMap.get("ServiceName"));
		EventLibrary.Static_Wait(5);
		EventLibrary.getAction().sendKeys(Keys.ENTER).build().perform();
		
		WebElement ServiceName = PlatFormHorizontalPage.find_Role_List_Table_Element(parameterMap.get("ServiceName"), 1);
		String ServiceNameText = ServiceName.getText();
		WebElement ServiceDesc = PlatFormHorizontalPage.find_Role_List_Table_Element(parameterMap.get("ServiceName"), 2);
		String ServiceDescText = ServiceDesc.getText();
		
		Assert.assertEquals(ServiceNameText, parameterMap.get("ServiceName"));
		Assert.assertEquals(ServiceDescText, parameterMap.get("ServiceDescription"));
		
		System.out.println("Test case 23 completes");
		
	}
	
	public void KSHEditSrvice(HashMap<String, String> parameterMap) throws InterruptedException {
		WebElement ServiceNameEdit = PlatFormHorizontalPage.find_Role_List_Table_Element(parameterMap.get("ServiceName"), 1);
		ServiceNameEdit.findElement(By.xpath("//span[@mattooltip = 'Edit']")).click();
		EventLibrary.Static_Wait(5);
		//EventLibrary.ClearAnd_Enter_TextBox_Value(txt_Service_Description, parameterMap.get("EditDescription"));
		EventLibrary.Click_Element(btn_UpdateService);
		EventLibrary.Static_Wait(3);
		
		EventLibrary.Click_Element_JSE(btn_BusinessService_SideNav);
		EventLibrary.Static_Wait(5);
		EventLibrary.Click_Element_JSE(tab_CustomService);
		EventLibrary.Static_Wait(5);
		EventLibrary.Enter_TextBox_Value(txt_BusinessServiceSearch, parameterMap.get("ServiceName"));
		EventLibrary.Static_Wait(5);
		EventLibrary.getAction().sendKeys(Keys.ENTER).build().perform();
		
		WebElement ServiceNameEdited = PlatFormHorizontalPage.find_Role_List_Table_Element(parameterMap.get("ServiceName"), 1);
		String ServiceNameEditText = ServiceNameEdited.getText();
		WebElement ServiceDescEdit = PlatFormHorizontalPage.find_Role_List_Table_Element(parameterMap.get("ServiceName"), 2);
		String ServiceDescEditText = ServiceDescEdit.getText();
		
		Assert.assertEquals(ServiceNameEditText, parameterMap.get("ServiceName"));
		Assert.assertEquals(ServiceDescEditText, parameterMap.get("EditDescription"));
		
		System.out.println("Test case 24 completes");
	}
	
	public void KSHCopySrvice(HashMap<String, String> parameterMap) throws InterruptedException {
		WebElement ServiceNameEdit = PlatFormHorizontalPage.find_Role_List_Table_Element(parameterMap.get("ServiceName"), 1);
		ServiceNameEdit.findElement(By.xpath("//span[@mattooltip = 'Copy as']")).click();
		EventLibrary.Static_Wait(3);
		//EventLibrary.ClearAnd_Enter_TextBox_Value(txt_ServiceId, parameterMap.get("serviceIdToCopyService"));
		//EventLibrary.ClearAnd_Enter_TextBox_Value(txt_Service_Name, parameterMap.get("serviceNameCopy"));
		EventLibrary.Click_Element(btn_FlagStatus);
		EventLibrary.Click_Element(btn_CopyService);
		EventLibrary.Static_Wait(5);
		EventLibrary.Click_Element(btn_RunTest);
		
		EventLibrary.Static_Wait(3);
		EventLibrary.Click_Element_JSE(btn_BusinessService_SideNav);
		EventLibrary.Static_Wait(5);
		EventLibrary.Click_Element_JSE(tab_CustomService);
		EventLibrary.Static_Wait(5);
		EventLibrary.Enter_TextBox_Value(txt_BusinessServiceSearch, parameterMap.get("serviceNameCopy"));
		EventLibrary.Static_Wait(5);
		EventLibrary.getAction().sendKeys(Keys.ENTER).build().perform();
		
		System.out.println("Verification of Tc 25");
		WebElement ServiceNameCopied = PlatFormHorizontalPage.find_Role_List_Table_Element(parameterMap.get("serviceNameCopy"), 1);
		String ServiceNameCopyText = ServiceNameCopied.getText();
		WebElement ServiceDescEdit = PlatFormHorizontalPage.find_Role_List_Table_Element(parameterMap.get("serviceNameCopy"), 2);
		String ServiceDescEditText = ServiceDescEdit.getText();
		System.out.println(ServiceNameCopyText);
		System.out.println(ServiceDescEditText);
		Assert.assertEquals(ServiceNameCopyText, parameterMap.get("serviceNameCopy"));
		Assert.assertEquals(ServiceDescEditText, parameterMap.get("EditDescription"));
		
		System.out.println("Test case 25 completed ...");	
	}
	
	public void KSHDeleteSrvice(HashMap<String, String> parameterMap) throws InterruptedException {
	
		//Delete Copied Business service 
		WebElement ServiceNametobeDeleted = PlatFormHorizontalPage.find_Role_List_Table_Element(parameterMap.get("serviceNameCopy"), 1);
		ServiceNametobeDeleted.findElement(By.xpath("//span[@mattooltip = 'Delete']")).click();
		EventLibrary.Static_Wait(3);
		EventLibrary.Click_Element(btn_YES_to_delete_service);
		EventLibrary.Static_Wait(3);
		txt_BusinessServiceSearch.clear();
		EventLibrary.Enter_TextBox_Value(txt_BusinessServiceSearch, parameterMap.get("serviceNameCopy"));
		EventLibrary.Static_Wait(3);
		EventLibrary.getAction().sendKeys(Keys.ENTER).build().perform();
		try {
			PlatFormHorizontalPage.find_Role_List_Table_Element(parameterMap.get("serviceNameCopy"), 1);
		}catch(Exception e) {
			Assert.assertTrue(true, "Service copied is removed successfully");
			System.out.println("Service copied is deleted");
		}
		EventLibrary.Static_Wait(3);
		
		//Delete Business service original
		txt_BusinessServiceSearch.clear();
		EventLibrary.Enter_TextBox_Value(txt_BusinessServiceSearch, parameterMap.get("serviceName"));
		EventLibrary.Static_Wait(3);
		EventLibrary.getAction().sendKeys(Keys.ENTER).build().perform();
		WebElement ServiceNameOriginal = PlatFormHorizontalPage.find_Role_List_Table_Element(parameterMap.get("serviceName"), 1);
		ServiceNameOriginal.findElement(By.xpath("//span[@mattooltip = 'Delete']")).click();
		EventLibrary.Static_Wait(3);
		EventLibrary.Click_Element(btn_YES_to_delete_service);
		EventLibrary.Static_Wait(3);
		txt_BusinessServiceSearch.clear();
		EventLibrary.Enter_TextBox_Value(txt_BusinessServiceSearch, parameterMap.get("serviceName"));
		EventLibrary.Static_Wait(3);
		EventLibrary.getAction().sendKeys(Keys.ENTER).build().perform();
		try {
			PlatFormHorizontalPage.find_Role_List_Table_Element(parameterMap.get("serviceName"), 1);
		}catch(Exception e) {
			Assert.assertTrue(true, "Business Service  is deleted successfully");
			System.out.println("Business Service  is deleted successfully");
		}
	}
}
