package com.abb.uiautomation.core.pages.SAD;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.HashMap;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

//import junit.framework.Assert;

public class SADSystemDetailsPage extends WebDriverManager {
	
	public SADSystemDetailsPage() {
	
	this.driver = WebDriverManager.driver;
	System.out.println("Login page Constructor " + driver);
	PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//html/body/app-root/div[2]/app-detail/div[2]/iframe")
	public WebElement iframeElement;
	
	@FindBy(xpath = "//input[@id='mat-input-6']")
	public WebElement SystemName;
	
	@FindBy(xpath= "//textarea[@id='mat-input-7']")
	public WebElement Description;
	
	@FindBy(xpath = "//select[@id='mat-input-8']")
	public WebElement select;
	
	@FindBy(xpath = "//div[contains(@class,'pointer-style icon-abb_search_32 icon_abb_32 icon icon-abb_search ng-star-inserted')]")
	public WebElement SearchLocation;
	
	@FindBy(xpath = "//select[contains(.,'Select Country')]")
	public WebElement Country;
	
	@FindBy(xpath = "//select[contains(.,'Select Region')]")
	public WebElement Region;
	
	@FindBy(xpath = "//select[contains(.,'Select Plant')]")
	public WebElement SelectPlant;
	
	@FindBy(xpath = "//button//span[contains(.,'Apply')]")
	public WebElement  Apply;
	
	@FindBy(xpath = "//select[@id='mat-input-11']")
	public WebElement ModelMapping_SelectModel;
	
	@FindBy(xpath = "//button//span[contains(.,'Upload')]")
	public WebElement FileUpload;
	
	@FindBy(xpath = "//button//span[contains(.,'Save')]")
	public WebElement SaveButton;
	
	/*@FindBy(xpath = "//app-system-equipments//div[1]/div[2]/span[2]")
	public WebElement lbl_Location;*/
	
	

	public void CreateSADSystemDetails(HashMap<String, String> parameterMap) throws InterruptedException {
		
		
		WebElement ele = null;
		
		EventLibrary.Enter_TextBox_Value(SystemName, parameterMap.get("SystemName"));
		ExtentsReport.testInfo("SADSystemDetailsPage Entered " + parameterMap.get("SystemName") +" into 'System Name' Successful");
		
		EventLibrary.Enter_TextBox_Value(Description, parameterMap.get("Description"));
		ExtentsReport.testInfo("SADSystemDetailsPage Entered " + parameterMap.get("Description") +" into 'System Description' Successful");
		
		ele = EventLibrary.Verify_Element_Exist(select);
		EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Class"));
		/*Select select1 = new Select(select);
		select1.selectByVisibleText(parameterMap.get("Class"));*/
		ExtentsReport.testInfo("SADSystemDetailsPage Selected " + parameterMap.get("Class") +" from 'Class' Successful");
		
		EventLibrary.Click_Element(SearchLocation);
//		SearchLocation.click();
		ExtentsReport.testInfo("SADSystemDetailsPage Clicked on " + parameterMap.get("Class") +" from 'Class' Successful");
		
		ele = EventLibrary.Verify_Element_Exist(Country);
		EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Country"));
		ExtentsReport.testInfo("SADSystemDetailsPage Selected " + parameterMap.get("Country") +" from 'Country' Successful");
		
		ele = EventLibrary.Verify_Element_Exist(Region);
		EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Region"));
		ExtentsReport.testInfo("SADSystemDetailsPage Selected " + parameterMap.get("Region") +" from 'Region' Successful");
		
		ele = EventLibrary.Verify_Element_Exist(SelectPlant);
		EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Plant"));
		ExtentsReport.testInfo("SADSystemDetailsPage Selected " + parameterMap.get("SelectPlant") +" from 'Select Plant' Successful");
		
		Thread.sleep(1000);
		EventLibrary.Click_Element_JSE(Apply);
		ExtentsReport.testInfo("SADSystemDetailsPage Clicked on Apply Successful");
		
		ele =  EventLibrary.Verify_Element_Exist(ModelMapping_SelectModel);
		EventLibrary.Select_ListElement(ele, 1, parameterMap.get("ModelMapping-SelectModel"));
		ExtentsReport.testInfo("SADSystemDetailsPage Selected " + parameterMap.get("ModelMapping-SelectModel") +" from 'ModelMapping-SelectModel' Successful");
		
		FileUpload.click();
		ExtentsReport.testInfo("SADSystemDetailsPage Clicked on Upload Successful");
		
		StringSelection ss = new StringSelection(parameterMap.get("Fileupload"));
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(ss, null);
	   // Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
	    Robot robot;
		try {
			robot = new Robot();
			robot.delay(300);
			robot.keyPress(KeyEvent.VK_ENTER);
	        robot.keyRelease(KeyEvent.VK_ENTER);
	        robot.keyPress(KeyEvent.VK_CONTROL);
	        robot.keyPress(KeyEvent.VK_V);
	        robot.keyRelease(KeyEvent.VK_V);
	        robot.keyRelease(KeyEvent.VK_CONTROL);
	        robot.keyPress(KeyEvent.VK_ENTER);
	        robot.delay(200);
	        robot.keyRelease(KeyEvent.VK_ENTER);
		}
		catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Thread.sleep(1000);
		ExtentsReport.testInfo("SADSystemDetailsPage Selected File " + ss + " Successful");
		
		EventLibrary.Click_Element(SaveButton);
		ExtentsReport.testInfo("SADSystemDetailsPage Clicked on Save Successful");
		
		ExtentsReport.testPasedMessage("SADSystemDetailsPage Saved Successfully");
	}
}

