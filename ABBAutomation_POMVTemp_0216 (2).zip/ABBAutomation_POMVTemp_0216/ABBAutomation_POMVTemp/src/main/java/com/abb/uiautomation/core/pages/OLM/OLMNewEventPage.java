package com.abb.uiautomation.core.pages.OLM;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class OLMNewEventPage extends WebDriverManager {

	public OLMNewEventPage() {
		// this.driver = WebDriverManager.getWebDriver("Chrome");
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "iframe-div")
	public WebElement frame_iframeParent;

	// ID -DYNAMIC
	// @FindBy(id="mat-select-0")
	@FindBy(xpath = "(//select)[1]")
	public WebElement lst_SelectStatus;

	// ID- DYNAMIC
	// @FindBy(id='mat-select-0']
	@FindBy(xpath = "//*[@placeholder='Select']")
	public WebElement lst_SelectSubType;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//Span[text()=' ALL ']")
	public WebElement chkBox_SubType_ALL;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//Span[text()=' Assigned to RCA ']")
	public WebElement chkBox_SubType_AssignedtoRCA;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//Span[text()=' Event Acknowledged ']")
	public WebElement chkBox_SubType_EventAcknowledged;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//Span[text()=' Event Approved ']")
	public WebElement chkBox_SubType_EventAproved;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//Span[text()=' Event Rejected ']")
	public WebElement chkBox_SubType_EventRejected;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//Span[text()=' Event Submitted ']")
	public WebElement chkBox_SubType_EventSubmitted;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//Span[text()=' Ignore Event ']")
	public WebElement chkBox_SubType_IgnoreEvent;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//Span[text()=' Pending For Initial Analysis ']")
	public WebElement chkBox_SubType_PendingForInitialAnalysis;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//Span[text()=' RCA Closed ']")
	public WebElement chkBox_SubType_RCAClosed;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//Span[text()=' RCA In Progress ']")
	public WebElement chkBox_SubType_RCAInProgress;

	// ID- DYNAMIC
	// @FindBy(id='mat-input-1']
	@FindBy(xpath = "//input[@placeholder='Search']")
	public WebElement txtbox_Search;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//input[@placeholder='Search']/following::div[1]")
	public WebElement btn_SerachIcon;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//button/span[text()=' New Event ']")
	public WebElement btn_NewEvent;

	public void OLMNewEvent(HashMap<String, String> parameterMap) {

		WebElement ele = null;
		ele = EventLibrary.Verify_Element_Exist(btn_NewEvent);
		EventLibrary.Click_Element_JSE(ele);
	}
}
