package com.abb.uiautomation.core.pages.OLM;

import java.util.HashMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class OLMRCALeadTaskPage extends WebDriverManager {

	public OLMRCALeadTaskPage() {
		// this.driver = WebDriverManager.getWebDriver("Chrome");
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "iframe-div")
	public WebElement frame_iframeParent;

	// ID -DYNAMIC
	// @FindBy(id="mat-input-0")
	@FindBy(xpath = "(//select)[1]")
	public WebElement lst_SelectType;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//mat-select[@role='listbox'][@placeholder='Select']")
	public WebElement lst_SelectSubType;

	@FindBy(xpath = "//span[text()=' ALL ']")
	public WebElement AllCheckBox;

	@FindBy(xpath = "//span[text()=' Chemicals ']")
	public WebElement ChemicalsCheckBox;

	@FindBy(xpath = "//span[text()=' Energy & Utilities ']")
	public WebElement EnergyNUtilitiesCheckBox;

	@FindBy(xpath = "//span[text()=' People Integrity ']")
	public WebElement PeopleIntegrityCheckBox;

	@FindBy(xpath = "//span[text()=' Production Loss ']")
	public WebElement ProductionLossCheckBox;

	@FindBy(xpath = "//span[text()=' Yield Loss ']")
	public WebElement YieldLossCheckBox;

	@FindBy(xpath = "//input[@formcontrolname='RCAStartDate']")
	public WebElement input_RCAStartDate;

	@FindBy(xpath = "//input[@formcontrolname='RCAEndDate']")
	public WebElement input_RCAEndDate;

	@FindBy(xpath = "//textarea[@formcontrolname='Conclusion']")
	public WebElement textarea_ConclusionComments;

	@FindBy(xpath = "(//select[@formcontrolname='userId'])[1]")
	public WebElement select_UserID;

	@FindBy(xpath = "(//input[@formcontrolname='description'])[1]")
	public WebElement input_UserID_Decsription;

	@FindBy(xpath = "(//a[@mattooltip='Add Row'])[1]")
	public WebElement link_UserID_Add;

	@FindBy(xpath = "//textarea[@placeholder='Please enter your comments here, if any!']")
	public WebElement textarea_Comments;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//button/span[text()=' OK ']")
	public WebElement btn_OK;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//button/span[text()=' Cancel ']")
	public WebElement btn_Cancel;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//button/span[text()=' Save ']")
	public WebElement btn_Save;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//button/span[text()=' Submit ']")
	public WebElement btn_Submit;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//button/span[text()=' Apply ']")
	public WebElement btn_Apply;
	
	//ID - NOT AVAILABLE
	@FindBy(xpath ="//table//tr//td[1]")
	public WebElement row_Select;
	
	@FindBy(xpath="(//input[@formcontrolname='Actions'])[1]")
	public WebElement input_Actions;
	
	@FindBy(xpath="(//select[@formcontrolname='Priority'])[1]")
	public WebElement select_Priority;
	
	@FindBy(xpath ="(//mat-checkbox)[1]")
	public WebElement checkBox_Row;
	
	@FindBy(xpath="//input[@formcontrolname='RCAStartDate']/following::div[1]")
	public WebElement date_RCAStartDate;
	
	@FindBy(xpath="//input[@formcontrolname='RCAEndDate']/following::div[1]")
	public WebElement date_RCAEndDate;
	
	@FindBy(xpath="//textarea[@formcontrolname='Conclusion']")
	public WebElement textarea_Conclusion;
	
	@FindBy(xpath="(//select[@formcontrolname='userId'])[1]")
	public WebElement lst_selectUser;
	
	@FindBy(xpath="(//input[@formcontrolname='description'])[1]")
	public WebElement input_description;
	
	
	public void OLMRCALeadTask(HashMap<String, String> parameterMap) {
		
		WebElement ele = null;
		
		ele = EventLibrary.Verify_Element_Exist(row_Select);
		ele.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
