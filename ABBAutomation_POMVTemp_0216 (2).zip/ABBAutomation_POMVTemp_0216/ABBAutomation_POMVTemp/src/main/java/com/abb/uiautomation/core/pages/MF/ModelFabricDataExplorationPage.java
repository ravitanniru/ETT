package com.abb.uiautomation.core.pages.MF;

import java.awt.AWTException;
import java.awt.List;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class ModelFabricDataExplorationPage extends WebDriverManager {
	
	public ModelFabricDataExplorationPage()
	{
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);	
	}
	
	//@FindBy(xpath ="//input[@type = 'radio'][@value='datalake']")
	//@FindBy(xpath="//input[@type = 'radio'][@name='upload'][@id='datalake']/following-sibling::label")
	@FindBy(xpath="//input[@id='datalake']")
	public WebElement radio_Uploadfrom_DataLake;
	
	//@FindBy(xpath ="//input[@type = 'radio'][@value='local']")
	//@FindBy(xpath="//input[@type = 'radio'][@name='upload'][@id='local']/following-sibling::label")
	@FindBy(xpath="//input[@id='local']")
	public WebElement radio_Uploadfrom_Local;

	@FindBy(xpath ="//div[@id='filesrc']/button[@class='upload-btn'][@id='call-to-local']")
	public WebElement btn_ChooseFile_local;
	
	@FindBy(xpath ="//div[@id='cdlsrc']/button[@class='upload-btn'][@id='call-to-cdl']")
	public WebElement btn_ChooseFile_dataLake;
	
	@FindBy(xpath ="//button[@type='submit'][contains(text(),'Submit')]")
	public WebElement btn_Submit;
	
	@FindBy(xpath="//a[contains(text(),'Overview')]")
	public WebElement lnk_Overview;
	
	@FindBy(xpath="//a[contains(text(),'Reproduction')]")
	public WebElement lnk_Reprodcution;
	
	@FindBy(xpath="//a[contains(text(),'Warnings')]")
	public WebElement lnk_Warnings;
	
	@FindBy(xpath="//*[@id='overview-warnings']/table/tbody/tr")
	public WebElement table_OverviewWarnings;
	
	public void ModelFabricDataExplorationSubmit(HashMap<String, String> parameterMap)
	{
		WebElement ele = null;
		/*WebDriverWait wait = new WebDriverWait(driver, 60);  
	 	wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("iframe-div"));*/
		
		driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[title='Data-Exploration']")));
		System.out.println("ModelFabricDataExplorationSubmit....0");
		String ElementName = parameterMap.get("UploadFrom");
		System.out.println("Element Name....0" + ElementName);
		if (ElementName.equalsIgnoreCase("local"))
		{
			System.out.println("ModelFabricDataExplorationSubmit....0");
			ele = new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOf(radio_Uploadfrom_DataLake));
			if (ele.isDisplayed())
			{
				ele.click();
			}
			System.out.println("ModelFabricDataExplorationSubmit....1");
			ele = new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOf(radio_Uploadfrom_Local));
			if (ele.isDisplayed())
			{
				ele.click();
			}
			System.out.println("ModelFabricDataExplorationSubmit....2");
			ele = new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOf(btn_ChooseFile_local));
			if (ele.isDisplayed())
			{
				ElementName = parameterMap.get("ChooseFile");
				//ele.click();
				JavascriptExecutor jse = (JavascriptExecutor)driver;
				jse.executeScript("arguments[0].click()", ele);
				driver.switchTo().alert().accept();
				
				StringSelection ss = new StringSelection(ElementName);
				Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
				clipboard.setContents(ss, null);
			   // Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
			    Robot robot;
				try {
					robot = new Robot();
					robot.delay(300);
					robot.keyPress(KeyEvent.VK_ENTER);
			        robot.keyRelease(KeyEvent.VK_ENTER);
			        robot.keyPress(KeyEvent.VK_CONTROL);
			        robot.keyPress(KeyEvent.VK_V);
			        robot.keyRelease(KeyEvent.VK_V);
			        robot.keyRelease(KeyEvent.VK_CONTROL);
			        robot.keyPress(KeyEvent.VK_ENTER);
			        robot.delay(200);
			        robot.keyRelease(KeyEvent.VK_ENTER);
				}
				catch (AWTException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println("ModelFabricDataExplorationSubmit....012");
		}
		/*else
		{
			System.out.println("ModelFabricDataExplorationSubmit....3");
			ele = new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOf(radio_Uploadfrom_DataLake));
			if (ele.isDisplayed())
			{
				//ele.click();
				JavascriptExecutor jse = (JavascriptExecutor)driver;
				jse.executeScript("arguments[0].click()", ele);
				
			}
			System.out.println("ModelFabricDataExplorationSubmit....4");
			ele = new WebDriverWait(driver, 50).until(ExpectedConditions.visibilityOf(btn_ChooseFile_dataLake));
			if (ele.isDisplayed())
			{
				//ele.click();
				JavascriptExecutor jse = (JavascriptExecutor)driver;
				jse.executeScript("arguments[0].click()", ele);
			}
			System.out.println("ModelFabricDataExplorationSubmit....012");
		}
		*/
		ExtentsReport.testInfo("ModelFabricDeploymentActionPage clicked on " + ElementName +" for 'Upload From' Successful");
		
		ElementName = parameterMap.get("ChooseFile");
		
		//btn_ChooseFile_local.click();
		//JavascriptExecutor jse = (JavascriptExecutor)driver;
		//jse.executeScript("arguments[0].click()", btn_ChooseFile_local);
		
		ExtentsReport.testInfo("ModelFabricDataExplorationPage clicked on 'Choose File' button Successful");
		
	/*	try {
			Thread.sleep(500);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
/*		
		StringSelection ss = new StringSelection(ElementName);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(ss, null);
	   // Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
	    Robot robot;
		try {
			robot = new Robot();
			robot.delay(300);
			robot.keyPress(KeyEvent.VK_ENTER);
	        robot.keyRelease(KeyEvent.VK_ENTER);
	        robot.keyPress(KeyEvent.VK_CONTROL);
	        robot.keyPress(KeyEvent.VK_V);
	        robot.keyRelease(KeyEvent.VK_V);
	        robot.keyRelease(KeyEvent.VK_CONTROL);
	        robot.keyPress(KeyEvent.VK_ENTER);
	        robot.delay(200);
	        robot.keyRelease(KeyEvent.VK_ENTER);
		}
		catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		ExtentsReport.testInfo("ModelFabricDataExplorationPage Uploaded file " + parameterMap.get("Fileupload") +" successful");
		
		ele = new WebDriverWait(driver, 12000).until(ExpectedConditions.visibilityOf(btn_Submit));
		btn_Submit.click();
		
		ele = new WebDriverWait(driver, 12000).until(ExpectedConditions.visibilityOf(lnk_Warnings));
		
		if (ele.isDisplayed()) {
			ele.click();
			java.util.List<WebElement> rows = driver.findElements(By.xpath("//*[@id='overview-warnings']/table/tbody/tr"));
			System.out.println("Table Rows " + rows.size());
		}
			
		
	}
			
			
}
