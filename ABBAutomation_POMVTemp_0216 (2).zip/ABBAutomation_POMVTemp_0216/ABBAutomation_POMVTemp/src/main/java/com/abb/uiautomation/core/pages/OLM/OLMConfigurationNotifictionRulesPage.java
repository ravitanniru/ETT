package com.abb.uiautomation.core.pages.OLM;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class OLMConfigurationNotifictionRulesPage extends WebDriverManager {
	
	public OLMConfigurationNotifictionRulesPage() {
		// this.driver = WebDriverManager.getWebDriver("Chrome");
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//span[@class = 'title'][text() = 'Notifications Rules']")
	public WebElement banner_NotificationsRules;
	
	//ID - DYNAMIC
	//@FindBy(id = "mat-input-10")
	@FindBy(xpath = "(//select)[8]")
	public WebElement lst_UserID;
	
	//ID - NOT AVAILABLE
	@FindBy(xpath = "//a[@mattooltip = 'Add Row']")
	public WebElement lnk_AddRow;
	
	//ID - NOT AVAILABLE
	@FindBy(xpath = "//a[@mattooltip = 'Reset']")
	public WebElement lnk_Reset;
	
	//ID - NOT AVAILABLE
	@FindBy(xpath = "//button/span[text() = ' Cancel ']")
	public WebElement btn_Cancel;
		
	//ID - NOT AVAILABLE
	@FindBy(xpath = "//button/span[text() = ' Save ']")
	public WebElement btn_Save;
			
	//ID - NOT AVAILABLE
	@FindBy(xpath = "//button/span[text() = ' Submit ']")
	public WebElement btn_submit;
	
	public void OLMConfigurationNotifictionRules(HashMap<String, String> parameterMap) {
		
		WebElement ele = null;
		
		try {
			EventLibrary.Click_Element_JSE(banner_NotificationsRules);	
			
			ele = EventLibrary.Verify_Element_Exist(lst_UserID);
			EventLibrary.Select_ListElement(ele, 1, parameterMap.get("UserID"));
			
			ele = EventLibrary.Verify_Element_Exist(lnk_AddRow);
			EventLibrary.Click_Element_JSE(ele);
			
			ele = EventLibrary.Verify_Element_Exist(btn_Save);
			EventLibrary.Click_Element_JSE(ele);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
