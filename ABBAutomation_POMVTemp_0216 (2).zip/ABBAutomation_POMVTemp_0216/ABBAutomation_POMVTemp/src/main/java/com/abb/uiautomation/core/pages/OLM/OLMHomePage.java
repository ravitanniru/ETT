package com.abb.uiautomation.core.pages.OLM;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.abb.uiautomation.core.constants.AbbConstants;
import com.abb.uiautomation.core.log.TestLogger;
import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class OLMHomePage extends WebDriverManager {

	public OLMHomePage() {
		// this.driver = WebDriverManager.getWebDriver("Chrome");
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//html/body/app-root/div[2]/app-detail/div[2]/iframe")
	public WebElement iframeElement;

	//@FindBy(xpath = "(//div[text()='Loss Configuration']")
	@FindBy(xpath = "(//div[@class='title'])[1]")
	public WebElement lnk_LossConfigurtaion;

	//@FindBy(xpath = "(//div[text()=' Loss Management ']")
	@FindBy(xpath = "(//div[@class='title'])[2]")
	public WebElement lnk_LossManagement;

	//@FindBy(xpath = "(//div[text()=' Root Cause Analysis']")
	@FindBy(xpath = "(//div[@class='title'])[3]")
	public WebElement lnk_RootCauseAnalysis;

	//@FindBy(xpath = "(//div[text()='Loss Prevention ']")
	@FindBy(xpath = "(//div[@class='title'])[4]")
	public WebElement lnk_LossPrevention;

	public void OLMMoveToTab(HashMap<String, String> parameterMap) {

		WebElement ele = null;

		System.out.println("Moved to frame title");
		WebDriverWait wait = new WebDriverWait(driver, 5000);
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("iframe-div"));
		System.out.println("Moved to frame");

		String ElementName = parameterMap.get("tabName");
		System.out.println("Eelement Name in SADMoveToTab " + ElementName);

		if (ElementName.trim().equalsIgnoreCase("Loss Configuration")) {
			System.out.println("in SAD");
			ele = new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(lnk_LossConfigurtaion));

		} else if (ElementName.equalsIgnoreCase("Loss Management")) {
			ele = new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(lnk_LossManagement));

		} else if (ElementName.equalsIgnoreCase("Root Cause Analysis")) {
			ele = new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(lnk_RootCauseAnalysis));

		} else if (ElementName.equalsIgnoreCase("Loss Prevention")) {
			ele = new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(lnk_LossPrevention));
		}

		if (ele.isDisplayed()) {
			
			System.out.println("Element - " + ElementName + " - Displayed");
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ele.click();
			ExtentsReport.testInfo("SADNewSystemPage Clicked on " + ElementName +" Successful");
			//driver.switchTo().defaultContent();
			
		} else {
			
			System.out.println("Element - " + ElementName + " - Not Displayed");
			
		}
		ExtentsReport.testInfo("OLMHomePage Clicked on " + ElementName + " Successful");
	}
}
