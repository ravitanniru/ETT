package com.abb.uiautomation.core.testexecution;

import java.lang.reflect.Method;


import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.annotations.Parameters;
import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.services.AbbUiAutomationService;



public class SuiteTestExecution {
	
	@BeforeTest
	public void beforetest() {
		
		//ExtentReport.configureReport();
		System.out.println("@@@@@@   in Before Test   @@@@@@");
		ExtentsReport.configureReport();

	}
	
	@Parameters({"ModuleName", "ExecutionType", "BrowserType"})
	@Test
	public void runtest(String EnviornmentName,String ModuleName, String ExecutionType, String BrowserType) throws InterruptedException {
		
		
		//executeKshApisServiceS(ExtentsReport.getExtentTestObj(),ExtentsReport.getReportObj());
		try {
			 AbbUiAutomationService service = new  AbbUiAutomationService();
			 //service.execute("C:\\Abbuiautomation\\SanityTestsuitePOM.xlsx");
			 service.execute(EnviornmentName,ModuleName,ExecutionType,BrowserType);
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@AfterTest
	public void aftertest() {
		//ExtentReport.endTest();
		System.out.println("@@@@@@   in End Test   @@@@@@");
		ExtentsReport.endTest();
	}
	

  	@AfterMethod
  	public void afterMethod(ITestResult result,Method testName) {   		
  		//ExtentReport.getResult(result,testName.getName());
		System.out.println("@@@@@@   in After Method   @@@@@@");
		System.out.println(".....result ..." + result + ".....testName..." + testName.getName());
  		ExtentsReport.getResult(result,testName.getName());

  	}

}
