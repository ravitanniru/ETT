package com.abb.uiautomation.core.pages.SAD;

import java.util.HashMap;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class SADHistoricalAnomalyTrendPage extends WebDriverManager {
	
	public SADHistoricalAnomalyTrendPage() {
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}

}
