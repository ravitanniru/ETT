package com.abb.uiautomation.core.pages.SAD;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class SADNewSystemPage extends WebDriverManager{

	public SADNewSystemPage() {
		// this.driver = WebDriverManager.getWebDriver("Chrome");
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "iframe-div")
	public WebElement frame_iframeParent;
	
	//ID -DYNAMIC
	@FindBy(id="mat-input-30")
	public WebElement input_Search;
	
	//ID - NOT DEFINED
	@FindBy(xpath ="")
	public WebElement btn_CloseSearch;
	
	//ID - NOT DEFINED
	@FindBy(xpath="")
	public WebElement btn_searchSearch;
	
	
	
	@FindBy(xpath = "//button//span[contains(.,'New System')]")
	public WebElement NewSystemElement;
	
	
	public void ConfigureNewSystem(HashMap<String, String> parameterMap)
	{
		WebElement ele = null;
		String ElementName = parameterMap.get("option");

		System.out.println("Eelement Name in ConfigureNewSystem " + ElementName);
		
		if (ElementName.equalsIgnoreCase("New System")) {			
			System.out.println("in NewSystem");
			ele = EventLibrary.Verify_Element_Exist(NewSystemElement);
		} 
		else  {
			System.out.println("in NewSystem Not Found");
		}
		
		if (ele.isDisplayed()) {
			
			System.out.println("Element - " + ElementName + " - Displayed");
			
			ele.click();
			ExtentsReport.testInfo("SADNewSystemPage Clicked on " + ElementName +" Successful");
			
		} else {
			System.out.println("Element - " + ElementName + " - Not Displayed");
		}
		
		ExtentsReport.testInfo("SADNewSystemPage Clicked on " + ElementName +" Successful");
		
		ExtentsReport.testPasedMessage("SADNewSystemPage Executed Successfully");
	}
}
