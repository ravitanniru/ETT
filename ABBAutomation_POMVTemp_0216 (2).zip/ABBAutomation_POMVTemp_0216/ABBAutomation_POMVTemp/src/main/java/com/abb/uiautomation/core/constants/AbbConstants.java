package com.abb.uiautomation.core.constants;

public interface AbbConstants {

	String EMPTY_STR = "";

	
	int COL_CONTROL = 2;
	
	int COL_TESTSUITESHEET_TESTCASE_ID = 0;
	int COL_TESTSUITESHEET_TESTCASE_NAME = 1;
	int COL_TESTSUITESHEET_TESTCASE_Description = 2;
	int COL_TESTSUITESHEET_TESTCASETOEXECUTE = 3;
	int COL_TESTSUITESHEET_MODULE_NAME =4;
	int COL_TESTSUITESHEET_EXECUTION_TYPE =5;
	
	
	int COL_TESTCASESHEET_TESTCASEID = 1;
	int COL_TESTDATSHEET_TESTCASEID = 1;
	
	
	int COL_TESTCASE_ID = 0;
	int COL_TEST_STEP_ID = 1;
	int COL_CONTROL_ELEMENT =2;
	int COL_CONTROL_TEXT = 3;
	int COL_ACTION_KEYWORD = 3;
	int COL_PAGE_OBJECT = 4;
	int COL_LOCATOR_TYPE = 4;
	int COL_LOCATOR_VALUE = 5;
	int COL_DATA_SET = 6;
	int COL_TEST_EXP_DATA = 7;
	
	
	String TestSuiteSheetName = "TestSuite";
	String TestCaseSheetName = "TestCase";
	String TestDataSheetName = "TestData";
	
	String FAIL = "FAIL";
	String PASS = "PASS";
	String SKIP ="SKIP";
	
	String Current_Test_Step_Result = "PASS";
	String Current_Test_Case_Result = "FAIL";
	
	String URL = "https://genix-uat-r01.westeurope.cloudapp.azure.com/dacapp/dac/App/applications/All";

}
