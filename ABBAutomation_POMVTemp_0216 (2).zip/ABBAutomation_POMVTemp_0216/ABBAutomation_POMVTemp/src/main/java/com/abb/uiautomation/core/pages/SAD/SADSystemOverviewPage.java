package com.abb.uiautomation.core.pages.SAD;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.abb.uiautomation.core.constants.AbbConstants;
import com.abb.uiautomation.core.log.TestLogger;
import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class SADSystemOverviewPage extends WebDriverManager {
	
	public SADSystemOverviewPage() {
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//html/body/app-root/div[2]/app-detail/div[2]/iframe")
	public WebElement iframeElement;
	
	//ID available but its Dynamic
	//@FindBy(id = "mat-input-12")
	//@FindBy(xpath ="//select[contains(.,'ALL')]")
	@FindBy(xpath = "(//select)[1]")
	public WebElement lst_Country;
	
	//ID available but its Dynamic
	//@FindBy(id = "mat-input-13")
	@FindBy(xpath ="(//select)[2]")
	public WebElement lst_Region;
	
	//ID available but its Dynamic
	//@FindBy(id = "mat-input-14")
	@FindBy(xpath ="(//select)[3]")
	public WebElement lst_Plant;
	
	//ID available but its Dynamic
	//@FindBy(id = "mat-input-14")
	@FindBy(xpath ="((//select)[4]")
	public WebElement lst_System;
	
	//ID not available
	@FindBy(xpath = "(//button/span[text()= ' Submit '])[1]")
	public WebElement btn_Submit_SelectLocation;
	
	//ID available but its Dynamic
	//@FindBy(id = "mat-input-18")
	
	//ID not available
	@FindBy(xpath = "(//button/span[text()= ' Submit '])[2]")
	public WebElement btn_Submit_SelectSystem;
	
	//ID not available
	@FindBy(xpath = "//button/span[text()= ' Update ']")
	public WebElement btn_Update;
	
	//ID not available
	@FindBy(xpath = "//button/span[text()= ' Reset ']")
	public WebElement btn_Reset;
		
	
	

}
