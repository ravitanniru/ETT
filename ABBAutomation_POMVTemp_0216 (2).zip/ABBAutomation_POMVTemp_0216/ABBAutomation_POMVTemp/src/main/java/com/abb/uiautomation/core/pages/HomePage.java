package com.abb.uiautomation.core.pages;

import java.util.HashMap;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class HomePage extends WebDriverManager {

	// WebDriver driver;

	public HomePage() {
		// this.driver = WebDriverManager.getWebDriver("Chrome");
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}

	// @FindBy(id = "SystemAnomalyDetection")
	@FindBy(xpath = "//div[@title='System Anomaly Detection']")
	public WebElement lnk_SAD;

	// @FindBy(id = "0000")
	@FindBy(xpath = "//div[@title='Opportunity Loss Manager (OLM)']")
	public WebElement lnk_OLM;

	// @FindBy(id = "navbox-trigger")
	@FindBy(xpath = "//*[@id=\"navbox-trigger\"]/i[@class='fa fa-lg fa-th']")
	public WebElement btn_AllApplicationsIcon_xpath;

	// ID NOT AVAILABLE
	// @FindBy(xpath="//img[@src = './fonts/abb_svg_icons/abb_digital-apps.svg']")
	@FindBy(xpath = "//span[text()='Digital Apps Center']")
	public WebElement DigitalAppsIcon;

	// ID NOT AVAILABLE
	// @FindBy(xpath="//img[@src =
	// 'fonts/abb_svg_icons/abb_contextual-fusion-hub.svg']")
	public WebElement ContextualFusionHubIcon;

	// ID NOT AVAILABLE
	// @FindBy(xpath="//img[@src = 'fonts/abb_svg_icons/abb_system-twin.svg']")
	@FindBy(xpath = "//span[text()='System Twin Integrity Hub']")
	public WebElement SystemTwinIntegrityHubIcon;

	// ID NOT AVAILABLE
	// @FindBy(xpath="//img[@src =
	// 'fonts/abb_svg_icons/abb_knowlwdge-service-hub.svg']")
	@FindBy(xpath = "//span[text()='Knowledge Services Hub']")
	public WebElement KnowledgeServiceHubIcon;

	// ID NOT AVAILABLE
	// @FindBy(xpath="//img[@src = 'fonts/abb_svg_icons/abb_model-fabric.svg']")
	@FindBy(xpath = "//span[text()='Model Fabric']")
	public WebElement ModelFabricIcon;
	//// span[text()='Model Fabric']

	// ID NOT AVAILABLE
	// @FindBy(xpath="//img[@src = 'fonts/abb_svg_icons/abb_analytics_app.svg']")
	@FindBy(xpath = "//span[text()='Analytics Apps Studio']")
	public WebElement AnalyticsAppsStudioIcon;

	// ID NOT AVAILABLE
	// @FindBy(xpath="//img[@src = 'fonts/abb_svg_icons/abb_industry_insight.svg']")
	@FindBy(xpath = "//span[text()='Industry Insights']")
	public WebElement IndustryInsightIcon;

	// ID NOT AVAILABLE
	@FindBy(xpath = "//span[text()='Asset Twin Viewer']")
	public WebElement AssetTwinViewerIcon;

	// ID NOT AVAILABLE
	@FindBy(xpath = "//span[text()='Platform Administration']")
	public WebElement PlatformAdministrationIcon;

	public void VerifyHomePageElements(HashMap<String, String> parameterMap) {

		WebElement ele = null;
		String ElementName = parameterMap.get("pageName");

		System.out.println("Eelement Name in VerifyHomePageElements " + ElementName);

		switch (ElementName.toLowerCase()) {

		case "system anomaly detection": {
			ele = EventLibrary.Verify_Element_Exist(lnk_SAD);
			break;
		}
		case "opportunity loss manager (olm)": {
			ele = EventLibrary.Verify_Element_Exist(lnk_OLM);
			break;
		}
		case "digital apps center": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(DigitalAppsIcon);
			break;
		}
		case "contextual fusion hub ": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(ContextualFusionHubIcon);
			break;
		}
		case "system twin integrity hub": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(SystemTwinIntegrityHubIcon);
			break;
		}
		case "knowledge services hub": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(KnowledgeServiceHubIcon);
			break;
		}
		case "model fabric": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(ModelFabricIcon);
			break;
		}
		case "analytics apps studio": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(AnalyticsAppsStudioIcon);
			break;
		}
		case "industry insights": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(IndustryInsightIcon);
			break;
		}
		case "asset twin viewer": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(AssetTwinViewerIcon);
			break;
		}
		case "platform administration": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(PlatformAdministrationIcon);
			if (ele != null)
			{
				
			}
			break;
		}
		}
		//Assert.assertEquals(ServiceNameText, parameterMap.get("ServiceName"));
	}

	public void MoveToApplication(HashMap<String, String> parameterMap) {

		ExtentsReport.testInfo("HomePage MoveToApplication Action Method Start");
		WebElement ele = null;
		String ElementName = parameterMap.get("pageName");

		System.out.println("Eelement Name in MoveToApplication " + ElementName);

		switch (ElementName.toLowerCase()) {

		case "system anomaly detection": {
			ele = EventLibrary.Verify_Element_Exist(lnk_SAD);
			break;
		}
		case "opportunity loss manager (olm)": {
			ele = EventLibrary.Verify_Element_Exist(lnk_OLM);
			break;
		}
		case "digital apps center": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(DigitalAppsIcon);
			break;
		}
		case "contextual fusion hub ": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(ContextualFusionHubIcon);
			break;
		}
		case "system twin integrity hub": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(SystemTwinIntegrityHubIcon);
			break;
		}
		case "knowledge services hub": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(KnowledgeServiceHubIcon);
			break;
		}
		case "model fabric": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			ele = EventLibrary.Verify_Element_Exist(ModelFabricIcon);
			break;
		}
		case "analytics apps studio": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(AnalyticsAppsStudioIcon);
			break;
		}
		case "industry insights": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(IndustryInsightIcon);
			break;
		}
		case "asset twin viewer": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(AssetTwinViewerIcon);
			break;
		}
		case "platform administration": {
			try {
				EventLibrary.Click_Element(btn_AllApplicationsIcon_xpath);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ele = EventLibrary.Verify_Element_Exist(PlatformAdministrationIcon);
			break;
		}
		}
		try {
			EventLibrary.Click_Element(ele);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		ExtentsReport.testInfo("HomePage MoveToApplication " + ElementName + " Successful");
		ExtentsReport.testInfo("HomePage MoveToApplication Action Method End");
		/*
		 * if (ele.isDisplayed()) { System.out.println("Element - " + ElementName +
		 * " - Displayed"); ele.click(); } else { System.out.println("Element - " +
		 * ElementName + " - Not Displayed"); }
		 */
	}
}
