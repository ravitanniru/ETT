package com.abb.uiautomation.core.pages.MF;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.HashMap;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class ModelFabricationNewDeploymentPage extends WebDriverManager {
	
	public ModelFabricationNewDeploymentPage()
	{
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);	
	}
	
	@FindBy(xpath = "//html/body/app-root/div[2]/app-detail/div[2]/iframe")
	public WebElement iframeElement;
	
	@FindBy(xpath = "//div/select[@formcontrolname='modelName']")
	public WebElement select_ModelName;
	
	@FindBy(xpath = "//div/input[@formcontrolname='deploymentName']")
	public WebElement input_DeploymentName;
	
	@FindBy(xpath = "//div/textarea[@formcontrolname='deplymentPurpose']")
	public WebElement textarea_DeploymentPurpose;
	
	@FindBy(xpath = "//button//span[contains(.,'Upload')]")
	public WebElement btn_Upload;
	
	@FindBy(xpath = "//div/select[@formcontrolname='computeTarget']")
	public WebElement select_computeTarget;
	
	@FindBy(xpath = "//div/input[@formcontrolname='pipDependencies']")
	public WebElement input_PIPDenpendencies;
	
	@FindBy(xpath = "//div/input[@formcontrolname='condaDependencies']")
	public WebElement input_CondaDenpendencies;
	
	@FindBy(xpath = "//div/textarea[@formcontrolname='script']")
	public WebElement textarea_script;
	
	@FindBy(xpath = "//button//span[contains(.,'Deploy')]")
	public WebElement btn_Deploy;
	
	@FindBy(xpath = "//button//span[contains(.,'Cancel')]")
	public WebElement btn_Cancel;
	
	
	public void MFNewDeploymentActivity(HashMap<String, String> parameterMap) {
		
		WebElement ele = null;
		
		String ElementName = parameterMap.get("ModelName");

		ele = new WebDriverWait(driver, 12000).until(ExpectedConditions.visibilityOf(select_ModelName));
		
		System.out.println("Element Name ; " + ElementName);
		
		Select select1 = new Select(select_ModelName);
		System.out.println("Element Name ; " + select1);
		
		select1.selectByVisibleText(ElementName);
		//select1.selectByValue(parameterMap.get(ElementName));
		
		ExtentsReport.testInfo("ModelFabricationNewDeploymentPage select " + ElementName +" in 'Model Name' Successful");
		
		ElementName = parameterMap.get("DeploymentName");		
		input_DeploymentName.sendKeys(ElementName);
		
		ExtentsReport.testInfo("ModelFabricationNewDeploymentPage enter " + ElementName +" into 'Deployment Name' Successful");
		
		ElementName = parameterMap.get("DeployedFor");
		textarea_DeploymentPurpose.sendKeys(ElementName);
		
		ExtentsReport.testInfo("ModelFabricationNewDeploymentPage enter " + ElementName +" into 'Deployment For' Successful");
		
		ElementName = parameterMap.get("Upload");
		btn_Upload.click();
		
		ExtentsReport.testInfo("ModelFabricationNewDeploymentPage click on '" + ElementName +"' Successful");
		
		StringSelection ss = new StringSelection(ElementName);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(ss, null);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	   // Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
	    Robot robot;
		try {
			robot = new Robot();
			robot.delay(300);
			robot.keyPress(KeyEvent.VK_ENTER);
	        robot.keyRelease(KeyEvent.VK_ENTER);
	        robot.keyPress(KeyEvent.VK_CONTROL);
	        robot.keyPress(KeyEvent.VK_V);
	        robot.keyRelease(KeyEvent.VK_V);
	        robot.keyRelease(KeyEvent.VK_CONTROL);
	        robot.keyPress(KeyEvent.VK_ENTER);
	        robot.delay(200);
	        robot.keyRelease(KeyEvent.VK_ENTER);
		}
		catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ExtentsReport.testInfo("ModelFabricationNewDeploymentPage selected file '" + ElementName +"' Successful");
		ElementName = parameterMap.get("ComputeTarget");
		
		System.out.println("Element Name ; " + ElementName);
		
		ele = new WebDriverWait(driver, 12000).until(ExpectedConditions.visibilityOf(select_computeTarget));
		
		select1 = new Select(select_computeTarget);
		select1.selectByVisibleText(ElementName);
		
		ExtentsReport.testInfo("ModelFabricationNewDeploymentPage select " + ElementName +" in 'Compute Target' Successful");
		
		ElementName = parameterMap.get("ScoringScript");
		textarea_script.sendKeys(ElementName);
		
		ExtentsReport.testInfo("ModelFabricationNewDeploymentPage enter " + ElementName +" into 'Scoring Script' Successful");
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ExtentsReport.testPasedMessage("Model Fabrication New Deployment " + parameterMap.get("DeploymentName")+ " Created Successfully");
		
		ExtentsReport.attachScreenshot(driver, "TestAttach");
		
		System.out.println("Screen Shot capture");
		//ExtentsReport.test.addScreenCapture("C:\\ABBAutomation_POM\\src\\main\\resources\\Reports");
		

		System.out.println("Screen Shot capture");
		
	}
	

	
	
	
	
	

}
