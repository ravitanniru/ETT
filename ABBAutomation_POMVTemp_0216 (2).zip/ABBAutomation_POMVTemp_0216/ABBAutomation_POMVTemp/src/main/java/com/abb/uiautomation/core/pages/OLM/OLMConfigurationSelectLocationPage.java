package com.abb.uiautomation.core.pages.OLM;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.abb.uiautomation.core.report.ExtentsReport;
import com.abb.uiautomation.core.services.EventLibrary;
import com.abb.uiautomation.core.utils.WebDriverManager;

public class OLMConfigurationSelectLocationPage extends WebDriverManager {

	public OLMConfigurationSelectLocationPage() {
		// this.driver = WebDriverManager.getWebDriver("Chrome");
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "iframe-div")
	public WebElement frame_iframeParent;

	// ID -DYNAMIC
	// @FindBy(id="mat-input-8")
	@FindBy(xpath = "(//select)[1]")
	public WebElement lst_Country;

	// ID -DYNAMIC
	// @FindBy(id="mat-input-9")
	@FindBy(xpath = "(//select)[2]")
	public WebElement lst_Region;

	// ID -DYNAMIC
	// @FindBy(id="mat-input-10")
	@FindBy(xpath = "(//select)[3]")
	public WebElement lst_Plant;

	// ID -DYNAMIC
	// @FindBy(id="mat-input-11")
	@FindBy(xpath = "(//select)[4]")
	public WebElement lst_Area;

	// ID -DYNAMIC
	// @FindBy(id="mat-input-12")
	@FindBy(xpath = "(//select)[5]")
	public WebElement lst_Unit;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "(//select)[6]")
	public WebElement lst_LossType;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//button/span[text()=' Import from Existing ']")
	public WebElement btn_ImportFromExisting;

	// ID - NOT AVAILABLE
	@FindBy(xpath = "//button/span[text()=' Create New ']")
	public WebElement btn_CreateNew;

	public void OLMConfigurationCreateNew(HashMap<String, String> parameterMap) {

		WebElement ele = null;
		
		
		try {
			System.out.println("Selecting by visible text");
			ele = EventLibrary.Verify_Element_Exist(lst_Country);
			Select drpCountry = new Select(driver.findElement(By.xpath("(//select)[1]")));
			drpCountry.selectByVisibleText(parameterMap.get("Country"));
			
			//EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Country"));
			ele = EventLibrary.Verify_Element_Exist(lst_Region);
			EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Region"));
		
			//Select drpRegion = new Select(driver.findElement(By.xpath("(//select)[2]")));
			//drpCountry.selectByVisibleText(parameterMap.get("Region"));
			
			//ele = EventLibrary.Verify_Element_Exist(lst_Plant);
			//EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Plant"));
			
			Select drpPlant = new Select(driver.findElement(By.xpath("(//select)[3]")));
			drpPlant.selectByVisibleText(parameterMap.get("Plant"));
			
			//ele = EventLibrary.Verify_Element_Exist(lst_Area);
			//EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Area"));
			
			Select drpArea = new Select(driver.findElement(By.xpath("(//select)[4]")));
			drpArea.selectByVisibleText(parameterMap.get("Area"));
			
			ele = EventLibrary.Verify_Element_Exist(lst_Unit);
			EventLibrary.Select_ListElement(ele, 1, parameterMap.get("Unit"));
			
			ele = EventLibrary.Verify_Element_Exist(lst_LossType);
			EventLibrary.Select_ListElement(ele, 1, parameterMap.get("LossDetails"));
			
			Thread.sleep(1000);
			
			ele = EventLibrary.Verify_Element_Exist(btn_CreateNew);
			EventLibrary.Click_Element(ele);
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
