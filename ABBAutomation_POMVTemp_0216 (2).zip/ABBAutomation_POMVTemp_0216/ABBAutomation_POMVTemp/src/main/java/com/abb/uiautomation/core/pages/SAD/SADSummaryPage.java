package com.abb.uiautomation.core.pages.SAD;

import java.util.HashMap;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.abb.uiautomation.core.utils.WebDriverManager;

//import junit.framework.Assert;

public class SADSummaryPage extends WebDriverManager{

	public SADSummaryPage() {
		this.driver = WebDriverManager.driver;
		System.out.println("Login page Constructor " + driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//span[text()=' Save ']")
	public WebElement btn_Save ;
	
	@FindBy(xpath = "//span[.=' Submit ']")
	public WebElement btn_Submit ;
	
	@FindBy(xpath = "//span[contains(text(),'Yes, I have saved it!')]")
	public WebElement btn_Yes_I_havesaved_it ;
	                 
	@FindBy(xpath = "(//*[@id='cdk-step-content-0-5']//table/tbody/tr//td[contains(@class,'mat-cell cdk-column-tag_name mat-column-tag_name ng-star-inserted')])[1]")
	public WebElement td_TagCode ;
	
	@FindBy(xpath = "(//table/tbody/tr//td[contains(@class,'mat-cell cdk-column-tag_description mat-column-tag_description ng-star-inserted')])[1]")
	public WebElement td_TagName ;
	
	
	public void CreateSADSummary(HashMap<String, String> parameterMap) throws InterruptedException {
		WebElement ele = null;
		
		System.out.println("Moved to frame");
	 	
	 	new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(btn_Submit));
		if (btn_Submit.isDisplayed())
		{
			System.out.println("-----SADSummaryPage---- Submit button Element Dispalyed");
			//ele.click();
		}
		else
		{
			System.out.println("-----SADSummaryPage---- Submit button Not Element Dispalyed");
		}
		
		try {
			WebElement ele1 = new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(td_TagCode));
			//Assert.assertTrue("The Elemet " + ele1 + " is appeared on Page", true);
			//Assert.assertEquals(true, lbl_Location.isDisplayed());
			System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$Element is found$$$$$$$$$$$$$$$$$$$$$$$$");
		} catch (Throwable t) {
			System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$Element NOT found$$$$$$$$$$$$$$$$$$$$$$$$");
			System.out.println(t.getMessage());
			//Assert.assertTrue(t.getMessage(), false);
			//Assert.assertFalse(false);
			t.printStackTrace();
		}
		
		try {
			WebElement ele1 = new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(td_TagName));
			//Assert.assertTrue("The Elemet " + ele1 + " is appeared on Page", true);
			//Assert.assertEquals(true, lbl_Location.isDisplayed());
			System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$Element is found$$$$$$$$$$$$$$$$$$$$$$$$");
		} catch (Throwable t) {
			System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$Element NOT found$$$$$$$$$$$$$$$$$$$$$$$$");
			System.out.println(t.getMessage());
			//Assert.assertTrue(t.getMessage(), false);
			//Assert.assertFalse(false);
			t.printStackTrace();
		}
		
		
		Thread.sleep(3000);
		btn_Submit.click();
		
		/*JavascriptExecutor jse1 = (JavascriptExecutor)driver;
		jse1.executeScript("arguments[0].click()", btn_Submit);*/
		Thread.sleep(1000);
		
		btn_Yes_I_havesaved_it.click();
	}
}
