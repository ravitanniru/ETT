package com.abb.uiautomation.core.utils;

import org.openqa.selenium.By;

public class ByObjectUtils {
	
	public static By getByObject(String locatorType, String locatorValue)
	{
		System.out.println("in getByObject Start");
		By object = null;
		if ("xpath".equalsIgnoreCase(locatorType)) {
			object = By.xpath(locatorValue);

		} else if ("id".equalsIgnoreCase(locatorType)) {

			object = By.id(locatorValue);
		}
		System.out.println("in getByObject End  " + object);
		
		return object;
	}

}
