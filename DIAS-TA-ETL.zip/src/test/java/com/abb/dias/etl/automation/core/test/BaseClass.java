package com.abb.dias.etl.automation.core.test;


import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import com.abb.dias.etl.automation.core.model.TestInputConfig;
import com.abb.dias.etl.automation.core.file.reader.ExcelReader;

public class BaseClass {
	public static HashMap<String, String> etlAtmnConfigHashMap;
	public static HashMap<String, String> azureApiInfoHashMap;
	public static LinkedHashMap<String, TestInputConfig> inputDataHashMap;
	public static HashMap<String, String> icmDbConfigHashMap;
	public static HashMap<String, String> tokenInfoHashMap;
	
	
	final static Logger logger = Logger.getLogger(BaseClass.class.getName());

	/***
	 * This method Read input Excel file having multiple sheets(config info) and loads
	 *  into respective HashMap 
	 */
	public void loadEtlAutmnInputs(String filePath, String fileName, String sheetName)  {
		try {
		Workbook workbook = ExcelReader.getWorkBook(filePath, fileName);
		String etlAtmnConfigSheetName = sheetName;
		
		System.out.println("Reading sheet : "+ etlAtmnConfigSheetName);
		Sheet etlAtmnConfigSheet = workbook.getSheet(etlAtmnConfigSheetName);
		etlAtmnConfigHashMap = ExcelReader.readExcel(etlAtmnConfigSheet);
		System.out.println("etlAtmnConfigHashMap "+etlAtmnConfigHashMap);
		etlAtmnConfigHashMap.forEach((configParam, value) -> {
			System.out.println("Key: " + configParam + ", Value: " + value);
		});

		String azureApiInfoSheetName = etlAtmnConfigHashMap.get("azureApiInfoExcelName");
		System.out.println("Reading sheet : "+ azureApiInfoSheetName);
		Sheet azureApiInfoSheet = workbook.getSheet(azureApiInfoSheetName);
		azureApiInfoHashMap = ExcelReader.readExcel(azureApiInfoSheet);
		azureApiInfoHashMap.forEach((configParam, value) -> {
			System.out.println("Key: " + configParam + ", Value: " + value);
		});

		String inputDataSheetName = etlAtmnConfigHashMap.get("inputExcelName");
		System.out.println("Reading sheet : "+ inputDataSheetName);
		Sheet inputDataSheet = workbook.getSheet(inputDataSheetName);
		inputDataHashMap = ExcelReader.readInputData(inputDataSheet);
		inputDataHashMap.forEach((pipelineName, testInputConfigObj) -> {
			System.out.println("Key: " + pipelineName + ", Value: " + testInputConfigObj.toString());
		});

		String icmDbConfigSheetName = etlAtmnConfigHashMap.get("icmDbConfigExcelName");
		System.out.println("Reading sheet : "+ icmDbConfigSheetName);
		Sheet icmDbConfigSheet = workbook.getSheet(icmDbConfigSheetName);
		icmDbConfigHashMap = ExcelReader.readExcel(icmDbConfigSheet);
		icmDbConfigHashMap.forEach((configParam, value) -> {
			System.out.println("Key: " + configParam + ", Value: " + value);
		});

		String tokenInfoSheetName = etlAtmnConfigHashMap.get("tokenInfoExcelName");
		System.out.println("Reading sheet : "+ tokenInfoSheetName);
		Sheet tokenInfoSheet = workbook.getSheet(tokenInfoSheetName);
		tokenInfoHashMap = ExcelReader.readExcel(tokenInfoSheet);
		tokenInfoHashMap.forEach((configParam, value) -> {
			System.out.println("Key: " + configParam + ", Value: " + value);
		});
		}
		catch (IllegalStateException ise) {
			System.out.println("Expected String value..");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
