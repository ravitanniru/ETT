package com.abb.dias.etl.automation.core.test;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.abb.dias.etl.automation.core.report.ExtentsReport;
import com.abb.dias.etl.automation.core.rest.api.RestApiUtility;
import com.abb.dias.etl.automation.core.database.DbConnectionUtil;
import com.abb.dias.etl.automation.core.database.SqlScriptRunner;
import com.abb.dias.etl.automation.core.environment.manager.EnvironmentManager;
import com.abb.dias.etl.automation.core.file.comparator.FileComparator;
import com.abb.dias.etl.automation.core.file.upload.FileUploadUtility;
import com.abb.dias.etl.automation.core.util.Util;

import io.restassured.response.Response;

public class EtlTest extends BaseClass {
	final static Logger logger = Logger.getLogger(EtlTest.class.getName());
	String token = null;

	@BeforeTest
	public void beforetest() {
		try {
		Reporter.log("Performing pre-requisite activities"); 
		
		//Loads ETL automation user input from excel
		loadEtlAutmnInputs(EnvironmentManager.getInputExcelFileLocation(), EnvironmentManager.getInputExcelFileName(), EnvironmentManager.getInputExcelSheetName());
		Reporter.log("Loaded ETL automation user input from Excel");
		
		//Load test data to CDL Landing container
		Response appStudioTokenResponse = RestApiUtility.generateTokenForAppStudio(tokenInfoHashMap);
		System.out.println(appStudioTokenResponse.asString());
		String appStudioToken = appStudioTokenResponse.getBody().jsonPath().getString("access_token");
		System.out.println("apps studio token"+appStudioToken);
		Reporter.log("Token generated for App Studio..");
		
		//if("true".equals(loadSourceData)) {
		HashMap<String, List<File>> folderMap = FileUploadUtility.getFilesInDir(etlAtmnConfigHashMap.get("sourceDataFolder"));
		RestApiUtility.uploadFile(azureApiInfoHashMap.get("fileUploadURL"), appStudioToken, azureApiInfoHashMap.get("containerName"), folderMap);
		//}
		
		//Establish connection with SQL database
		String truncateDbURL = icmDbConfigHashMap.get("sqlServerDriver").trim() + icmDbConfigHashMap.get("hostName").trim() + ";user="+ icmDbConfigHashMap.get("truncateUserName").trim() +";password="+ icmDbConfigHashMap.get("truncateUserPassword").trim() +";database="+ icmDbConfigHashMap.get("databaseName").trim();
		Connection con = DbConnectionUtil.getDbConnection(truncateDbURL);
		Reporter.log("Created connection with database..");
		
		//Truncate data from ICM db tables
		SqlScriptRunner.runScript(con);
		
		ExtentsReport.configureReport(etlAtmnConfigHashMap.get("extentHtmlReportLocation"));
		}
		catch (Exception e) {
			logger.error("expection while running before test");
		}
	}

	@Test
	public void triggerAndMonitorPipeline() {
		String actualDatatFolderLoc = etlAtmnConfigHashMap.get("actualDataFromDbFolder");
		String expectedDataFolderLoc = etlAtmnConfigHashMap.get("expectedDataFolder");
		String dataComparisionResultFolder = etlAtmnConfigHashMap.get("dataComparisionResultFolder");
		String responseFolder = etlAtmnConfigHashMap.get("responseFolder");
		String responseFileName = responseFolder + Util.getFileSeparator() + "response_" + Util.getCurrentTimestamp()+".log";
		String dataMovementSTG = "SrcToStg";
		String dataMovementDMN = "StgToDmn";
		
		Reporter.log("Started ETL Automation Framework..");
		logger.info("Started ETL Automation Framework..");
		 JSONParser parse = new JSONParser();
		try {
			String baseURI = azureApiInfoHashMap.get("baseURL")
					.replace("{subscriptionId}", azureApiInfoHashMap.get("subscriptionId"))
					.replace("{resourceGroup}", azureApiInfoHashMap.get("resourceGroup"))
					.replace("{dataFactory}", azureApiInfoHashMap.get("dataFactory"));
			
			// Iterate through HashMap having User Input Test Data and trigger pipeline
			// accordingly
			inputDataHashMap.forEach((pipelineName, testInputConfigObj) -> {
				//Generate token from Azure 
				Response tokenResponse = RestApiUtility.generateToken(tokenInfoHashMap);
				token = tokenResponse.getBody().jsonPath().getString("access_token");
				int monitorApiDelay = testInputConfigObj.getMonitorAPIDelayInMilliSeconds();
				//Reporter.log("Generated token needed for Azure ETL automation..");
				
				long testCaseStartTime = System.currentTimeMillis();
				Reporter.log("Testing Pipeline: " + pipelineName + ", Test Input: " + testInputConfigObj.toString());
				logger.info("Testing Pipeline: " + pipelineName + ", Test Input: " + testInputConfigObj.toString());
				ExtentsReport.startTest(
						"Test Case Id: " + testInputConfigObj.getTestCaseId() + " &  Pipeline Name: " + pipelineName);

				String triggerUri = baseURI + azureApiInfoHashMap.get("triggerPipelineEndPoint").replace("{pipeline}",
						pipelineName.replace(" ", "%20"));
				ExtentsReport.testInfo("Calling Azure Trigger API : " + triggerUri);
				Response triggerResponse = RestApiUtility.postRequest(triggerUri, token);
				
				ExtentsReport.testInfo("Azure Trigger API Response : " + triggerResponse.asString());
				logger.info("Azure Trigger API Response : " + triggerResponse.asString());
				Util.writeResponseToFile(triggerResponse.asString(), responseFileName);
				
				if(triggerResponse.getStatusCode() != 200) {
					ExtentsReport.testFail("Check Point1: Trigger API Failed");
					return;
				}

				Assert.assertTrue(triggerResponse.getBody().asString().contains("runId"));
				
				if(triggerResponse.getBody().asString().contains("runId"))
					ExtentsReport.testPasedMessage("Check Point1: Trigger API Success");
				else
					ExtentsReport.testFail("Check Point1: Trigger API Failed");
				
				ExtentsReport.testInfo("Trigger Api response time is : " + triggerResponse.getTime() + " Milli seconds");
				
				String runId = triggerResponse.getBody().jsonPath().getString("runId");
				
				try {
					Thread.sleep(monitorApiDelay);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
				// Monitor pipeline status String monitorUri =
				String monitorUri = baseURI + azureApiInfoHashMap.get("moniterPipelineEndpoint").replace("{runId}", runId);
				ExtentsReport.testInfo("Calling Azure Monitor API : " + monitorUri);
				Response monitorResponse = RestApiUtility.postRequest(monitorUri, token);
				
				ExtentsReport.testInfo("Azure Monitor API Response : " + monitorResponse.asString());
				logger.info("Azure Monitor API Response : : " + monitorResponse.asString());
				if(monitorResponse.getStatusCode() != 200) {
					ExtentsReport.testFail("Check Point2: Monitor API Failed");
					return;
				}
				
				Util.writeResponseToFile(monitorResponse.asString(), responseFileName);
				
				 
				try {
					JSONObject jobj = (JSONObject)parse.parse(monitorResponse.asString());
					JSONArray activityArray = (JSONArray) jobj.get("value"); 
					//Get data for Results array
					for(int i=0;i<activityArray.size();i++)
					{
						JSONObject activityObj = (JSONObject)activityArray.get(i);
						System.out.println("Elements under results array");
						System.out.println("\n status: " +activityObj.get("status"));
						
					if("Succeeded".equalsIgnoreCase(activityObj.get("status").toString()))
						ExtentsReport.testPasedMessage("Check Point2: "+ activityObj.get("activityName") + " - Monitor API Success");
					else if("InProgress".equalsIgnoreCase(activityObj.get("status").toString())) {
						ExtentsReport.testWarnMessage("Check Point2: "+ activityObj.get("activityName") + " - Monitor API InProgress..Apply Re-try");
						boolean endRetry = false;
						for(int numRtry=0;numRtry < testInputConfigObj.getNumRetries();numRtry++)
						{
							try {
								Thread.sleep(testInputConfigObj.getMonitorAPIDelayInMilliSeconds());
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
							Response monitorRTryResponse = RestApiUtility.postRequest(monitorUri, token);
							ExtentsReport.testInfo("Azure Monitor API Response : Re-try-"+ numRtry+ " "  + monitorRTryResponse.asString());
							logger.info("Azure Monitor API Response : Re-try-"+ numRtry+ " "  + monitorRTryResponse.asString());
							Util.writeResponseToFile(monitorRTryResponse.asString(), responseFileName);
							
							JSONObject monitorRespObjRTry = (JSONObject)parse.parse(monitorRTryResponse.asString());
							JSONArray monitorActivityRTryArray = (JSONArray) monitorRespObjRTry.get("value");
							for(int k=0;k < monitorActivityRTryArray.size();k++)
							{
								JSONObject activityRTryObj = (JSONObject)monitorActivityRTryArray.get(i);
								
								if((k == (monitorActivityRTryArray.size() - 1)) && ("Succeeded".equalsIgnoreCase(activityRTryObj.get("status").toString()))) {
									ExtentsReport.testPasedMessage("Check Point2: "+ activityRTryObj.get("activityName") +  " - Monitor API Success");
									endRetry = true;
									break;
								}
								else if((numRtry == (testInputConfigObj.getNumRetries() - 1)) && ("InProgress".equalsIgnoreCase(activityRTryObj.get("status").toString()))) {
									ExtentsReport.testFail("Check Point2: " + "Re-try-"+ numRtry + " "+activityRTryObj.get("activityName") +  " - All Re-tries exhausted..Hence Monitor API considerd Failed");
									break;
								}
								else if("InProgress".equalsIgnoreCase(activityRTryObj.get("status").toString())) 
									break;
								else if("Queued".equalsIgnoreCase(activityRTryObj.get("status").toString()))
									break;
								else if("Failed".equalsIgnoreCase(activityRTryObj.get("status").toString()))
									ExtentsReport.testFail("Check Point2: "+ activityRTryObj.get("activityName") +  " - Monitor API Failed");
								
							}
							
							if(endRetry == true)
								break;
						}
					}		
					else if("Failed".equalsIgnoreCase(activityObj.get("status").toString()))
						ExtentsReport.testFail("Check Point2: "+ activityObj.get("activityName") +  " - Monitor API Failed");
					
				} 
					ExtentsReport.testInfo("Monitor Api response time is : " + (monitorResponse.getTime() + monitorApiDelay) + " Milli seconds");
					logger.info("Monitor Api response time is : " + (monitorResponse.getTime() + monitorApiDelay) + " Milli seconds");
					
					}catch (ParseException e) {
					e.printStackTrace();
				}
				
				String dbURL = icmDbConfigHashMap.get("sqlServerDriver").trim() + icmDbConfigHashMap.get("hostName").trim() + ";user="+ icmDbConfigHashMap.get("userName").trim() +";password="+ icmDbConfigHashMap.get("userPassword").trim() +";database="+ icmDbConfigHashMap.get("databaseName").trim();		
				Connection con = DbConnectionUtil.getDbConnection(dbURL);
				// Validate data in ICM only if data validation set to TRUE and query is provided
					//Staging data validation
				if(testInputConfigObj.isDataValidation() == true && ! "NA".equalsIgnoreCase(testInputConfigObj.getStagingQuery())) {
					String stagingQueryStr =testInputConfigObj.getStagingQuery(); 
					String[] stgQueries = stagingQueryStr.split(";");//Format = tableName: SQL Query
					for (String stgQ : stgQueries) {
						String tableName = stgQ.split(":")[0];
						DbConnectionUtil.getActualData(stgQ.split(":")[1], stgQ.split(":")[0], pipelineName, actualDatatFolderLoc, con);
						//ExcelToTextConverter.convertExcelToText(actualDatatFolderLoc, pipelineName, tableName);
						try {
							FileComparator.generateFileDiff(expectedDataFolderLoc, actualDatatFolderLoc, pipelineName, tableName, dataComparisionResultFolder, EnvironmentManager.getDataDiffTemplateFileName(), dataMovementSTG);
						} catch (IOException e) {
							ExtentsReport.testFail(
									"Expection occured while trying to compare Expected and Actual data files for table "+tableName +"!!");
							e.printStackTrace();
						}
					}
					
				}
					//Dimension/Fact data validation
					if(testInputConfigObj.isDataValidation() == true && ! "NA".equalsIgnoreCase(testInputConfigObj.getDimensionQuery())) {
					String dimensionQueryStr = testInputConfigObj.getDimensionQuery(); 
					String[] dmQueries = dimensionQueryStr.split(";");
					for (String dmQ : dmQueries) {
						String tableName = dmQ.split(":")[0];
						DbConnectionUtil.getActualData(dmQ.split(":")[1], dmQ.split(":")[0], pipelineName,  actualDatatFolderLoc, con);
						//ExcelToTextConverter.convertExcelToText(actualDatatFolderLoc, pipelineName, dmQ.split(":")[0]);
						try {
							FileComparator.generateFileDiff(expectedDataFolderLoc, actualDatatFolderLoc, pipelineName, tableName, dataComparisionResultFolder, EnvironmentManager.getDataDiffTemplateFileName(), dataMovementDMN);
						} catch (IOException e) {
							ExtentsReport.testFail(
									"Expection occured while trying to compare Expected and Actual data files for table "+tableName +"!!");
							e.printStackTrace();
						}
						}
					}
					
					long testCaseEndTime = System.currentTimeMillis();
					Reporter.log("Total time taken to complete test case execution: "+ (testCaseEndTime - testCaseStartTime) + "ms");
			});
		} 
		catch (Exception e) {
			ExtentsReport.testError("Exception occured while running test case, check the details in Test Runner logs Tab or Lo4j logs");
			e.printStackTrace();
		}
		
	}

	@AfterTest
	public void aftertest() {
		ExtentsReport.endTest();
		Reporter.log("Ended ETL Automation Framework..");
		logger.info("Ended ETL Automation Framework..");
	}

	@AfterMethod
	public void afterMethod(ITestResult result, Method testName) {
		ExtentsReport.getResult(result, testName.getName());

	}

}
