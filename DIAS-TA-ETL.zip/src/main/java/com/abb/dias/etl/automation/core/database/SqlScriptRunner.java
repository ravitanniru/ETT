package com.abb.dias.etl.automation.core.database;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.sql.Connection;
import java.sql.SQLException;

import org.apache.ibatis.jdbc.ScriptRunner;

import com.abb.dias.etl.automation.core.util.Util;

public class SqlScriptRunner {
	public static String fileSeperator = Util.getFileSeparator();
	public static String sqlFile = "."+ fileSeperator + "src"+ fileSeperator + "main"+ fileSeperator + "resources"+ fileSeperator + "dataTruncateScript.sql";
public static void runScript(Connection con) {
	 //Initialize the script runner
    ScriptRunner sr = new ScriptRunner(con);
	try {
		//Creating a reader object
		System.out.println(sqlFile);
	    Reader reader = new BufferedReader(new FileReader(new File(sqlFile)));
	    //Running the script
	    System.out.println("running script.....");
	    sr.setSendFullScript(true);
	    sr.runScript(reader);
	    System.out.println("executed script");
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	}
	finally {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
}
