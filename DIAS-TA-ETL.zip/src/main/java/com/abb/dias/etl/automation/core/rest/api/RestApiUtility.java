package com.abb.dias.etl.automation.core.rest.api;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class RestApiUtility {
	/***
	 * This method generate token for Azure
	 * @param tokenInfoHashMap
	 * @return Response object having token info
	 */
	
	public static Response generateToken(HashMap<String, String> tokenInfoHashMap) {
		Response response =
        		RestAssured.given().auth().preemptive().basic(tokenInfoHashMap.get("clientId"), tokenInfoHashMap.get("clientSecret"))   
                        .formParam("grant_type", tokenInfoHashMap.get("grantType"))
                        .formParam("resource", tokenInfoHashMap.get("resource"))
                        .when()
                        .post(tokenInfoHashMap.get("tokenURL"));
        return response;
	}
	/**
	 * This method generate token for App Studio application
	 * @param tokenInfoHashMap
	 * @return
	 */
	public static Response generateTokenForAppStudio(HashMap<String, String> tokenInfoHashMap) {
		System.out.println("generate token for App Studio");
		Response response =
        		RestAssured.given().auth().preemptive().basic(tokenInfoHashMap.get("appStudioClientId"), tokenInfoHashMap.get("appStudioClientSecret"))   
                        .formParam("grant_type", tokenInfoHashMap.get("appStudioGrantType"))
                        .formParam("resource", tokenInfoHashMap.get("appStudioResource"))
                        .when()
                        .post(tokenInfoHashMap.get("appStudioTokenURL"));
		
        return response;
	}
	
	/**
	 * This menthod is used to make all post requests 
	 * @param uri
	 * @param token
	 * @return Response object
	 */
	public static Response postRequest(String uri, String token) {
		RestAssured.baseURI = uri;
		RestAssured.urlEncodingEnabled = false;
		Response response = RestAssured.given().auth().oauth2(token).accept(ContentType.JSON).when()
				.post(RestAssured.baseURI).then().contentType(ContentType.JSON). 
				extract().response(); 
		return response;
	}
	
	public static void uploadFile(String uri, String token, String containerName, HashMap<String, List<File>> folderMap) {
		RestAssured.baseURI = uri;
		folderMap.forEach((folderName, fileList) -> {
			System.out.println("folderName "+folderName);
			fileList.forEach(file->{
				System.out.println("file "+file);
				RestAssured.given().auth().oauth2(token).accept(ContentType.JSON)   
                .formParam("containerName", containerName)
                .formParam("uploadPath", folderName)
                .multiPart("file",file)
                .when()
                .post(RestAssured.baseURI)
                .then()
                .assertThat()
                .statusCode(200);
			});
		});
					 
	}
}
