package com.abb.dias.etl.automation.core.file.comparator;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.apache.commons.text.diff.CommandVisitor;
import org.apache.commons.text.diff.StringsComparator;

import com.abb.dias.etl.automation.core.report.ExtentsReport;
import com.abb.dias.etl.automation.core.util.Util;

public class FileComparator {
	public static String fileSeperator = Util.getFileSeparator();
	public static String textFormat = "utf-8";
	public static Properties prop;
	
	public static void generateFileDiff(String expectedDataFolderLoc, String actualDataFolderLoc, String pipelineName, String tableName, String dataComparisionResultFolder, String templateFileLoc, String dataMovementType) throws IOException {
		String underScoreDelimiter = "_";
		String pipelineNameModified = pipelineName.replace(" ", underScoreDelimiter);
		String actualDataFileName = actualDataFolderLoc + fileSeperator +  pipelineNameModified + underScoreDelimiter + tableName.trim() + underScoreDelimiter + "actual" + underScoreDelimiter + "icm" + underScoreDelimiter + "data.txt";
		String expectedDataFileName = expectedDataFolderLoc + fileSeperator +  pipelineNameModified + underScoreDelimiter + tableName.trim() + underScoreDelimiter + "expected" + underScoreDelimiter + "icm" + underScoreDelimiter + "data.txt";
		String dataComparisionHTML = dataComparisionResultFolder + fileSeperator + pipelineNameModified + underScoreDelimiter + tableName.trim() +underScoreDelimiter + Util.getCurrentTimestamp() +  ".html";
		
		System.out.println("actualDataFileName"+actualDataFileName);
		System.out.println("expectedDataFileName"+expectedDataFileName);
			LineIterator file1 = FileUtils.lineIterator(new File(actualDataFileName), textFormat);
		LineIterator file2 = FileUtils.lineIterator(new File(expectedDataFileName), textFormat);

		// Initialize visitor.
		FileCommandsVisitor fileCommandsVisitor = new FileCommandsVisitor();

		// Read file line by line so that comparison can be done line by line.
		while (file1.hasNext() || file2.hasNext()) {
			/*
			 * In case both files have different number of lines, fill in with empty
			 * strings. Also append newline char at end so next line comparison moves to
			 * next line.
			 */
			String left = (file1.hasNext() ? file1.nextLine() : "") + "\n";
			String right = (file2.hasNext() ? file2.nextLine() : "") + "\n";

			// Prepare diff comparator with lines from both files.
			StringsComparator comparator = new StringsComparator(left, right);

			if (comparator.getScript().getLCSLength() > (Integer.max(left.length(), right.length()) * 0.4)) {
				/*
				 * If both lines have atleast 40% commonality then only compare with each other
				 * so that they are aligned with each other in final diff HTML.
				 */
				comparator.getScript().visit(fileCommandsVisitor);
			} else {
				/*
				 * If both lines do not have 40% commanlity then compare each with empty line so
				 * that they are not aligned to each other in final diff instead they show up on
				 * separate lines.
				 */
				StringsComparator leftComparator = new StringsComparator(left, "\n");
				leftComparator.getScript().visit(fileCommandsVisitor);
				StringsComparator rightComparator = new StringsComparator("\n", right);
				rightComparator.getScript().visit(fileCommandsVisitor);
			}
		}

		fileCommandsVisitor.generateHTML(dataComparisionHTML, templateFileLoc);

		System.out.println(FileUtils.contentEquals(new File(actualDataFileName),
				new File(expectedDataFileName)));
		if (FileUtils.contentEquals(new File(actualDataFileName),
				new File(expectedDataFileName)) == true)
			ExtentsReport.testPasedMessage(
					dataMovementType + ": Expected "+ expectedDataFileName +" and Actual "+ actualDataFileName +" output matched !!");
		else {
			
			ExtentsReport.testFail(
					dataMovementType + ": Expected "+ expectedDataFileName +" and Actual "+ actualDataFileName +" output mis-match !!");
			
		}
	}
}

