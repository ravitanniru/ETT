package com.abb.dias.etl.automation.core.environment.manager;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import com.abb.dias.etl.automation.core.util.Util;

public class EnvironmentManager {
	public static String fileSeperator = Util.getFileSeparator();
	public static String configFileLoc = "."+ fileSeperator + "src"+ fileSeperator + "main"+ fileSeperator + "resources"+ fileSeperator + "config.properties";
	private static Properties prop;
	/*
	 * This method returns input excel file location
	 */
	public static String getInputExcelFileLocation() {

		return prop.getProperty("etl.autmn.input.filePath");
	
	}
	/**
	 * This method returns input excel file Name
	 * @return
	 */
	public static String getInputExcelFileName() {

		return prop.getProperty("etl.autmn.input.fileName");
	
	}
	
	/**
	 * This method returns input excel etl automation config sheet Name
	 * @return
	 */
	public static String getInputExcelSheetName() {

		return prop.getProperty("etl.autmn.input.config.sheetName");
	
	}
	
	/**
	 * This method returns data difference template file Name
	 * @return
	 */
	public static String getDataDiffTemplateFileName() {

		return prop.getProperty("etl.atmn.data.diff.template");
	
	}
	
	/**
	 * Static block for initializing config properties
	 */
	static{
		prop = new Properties();
		try {
			File file = new File(configFileLoc);
			prop.load(new FileInputStream(file));
		} catch (IOException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
