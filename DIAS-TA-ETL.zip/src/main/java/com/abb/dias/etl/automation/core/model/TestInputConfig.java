package com.abb.dias.etl.automation.core.model;

public class TestInputConfig {
	private int testCaseId;
	private String pipelineName;
	private boolean executePipeline;
	private int monitorAPIDelayInMilliSeconds;
	private int numRetries;
	private String monitorStatus;
	private boolean dataValidation;
	private String stagingQuery;
	private String dimensionQuery;
	
	public int getTestCaseId() {
		return testCaseId;
	}
	public void setTestCaseId(int testCaseId) {
		this.testCaseId = testCaseId;
	}
	public String getPipelineName() {
		return pipelineName;
	}
	public void setPipelineName(String pipelineName) {
		this.pipelineName = pipelineName;
	}
	public boolean isExecutePipeline() {
		return executePipeline;
	}
	public void setExecutePipeline(boolean executePipeline) {
		this.executePipeline = executePipeline;
	}
	public int getMonitorAPIDelayInMilliSeconds() {
		return monitorAPIDelayInMilliSeconds;
	}
	public void setmonitorAPIDelayInMilliSeconds(int monitorAPIDelayInMilliSeconds) {
		this.monitorAPIDelayInMilliSeconds = monitorAPIDelayInMilliSeconds;
	}
	public int getNumRetries() {
		return numRetries;
	}
	public void setNumRetries(int numRetries) {
		this.numRetries = numRetries;
	}
	public String getMonitorStatus() {
		return monitorStatus;
	}
	public void setMonitorStatus(String monitorStatus) {
		this.monitorStatus = monitorStatus;
	}
	public boolean isDataValidation() {
		return dataValidation;
	}
	public void setDataValidation(boolean dataValidation) {
		this.dataValidation = dataValidation;
	}
	public String getStagingQuery() {
		return stagingQuery;
	}
	public void setStagingQuery(String stagingQuery) {
		this.stagingQuery = stagingQuery;
	}
	public String getDimensionQuery() {
		return dimensionQuery;
	}
	public void setDimensionQuery(String dimensionQuery) {
		this.dimensionQuery = dimensionQuery;
	}
	@Override
	public String toString() {
		return "TestInputConfig [testCaseId=" + testCaseId + ", pipelineName=" + pipelineName + ", executePipeline="
				+ executePipeline + ", monitorAPIDelayInMilliSeconds=" + monitorAPIDelayInMilliSeconds + ", numRetries="
				+ numRetries + ", monitorStatus=" + monitorStatus + ", dataValidation=" + dataValidation
				+ ", stagingQuery=" + stagingQuery + ", dimensionQuery=" + dimensionQuery + "]";
	}

}
