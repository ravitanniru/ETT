package com.abb.dias.etl.automation.core.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Util {
	public static String timestampFormat = "yyyy-MM-dd-HH-mm-ss";
	public static String dateFormat = "M/d/yyyy";
	public static String responseFileName = "response.txt";
	public static File responseFile;
	public static Writer writer = null;
	public static FileOutputStream fop = null;
	public static File file;
	
	/**
	 * This method returns current datetime string in defined format
	 * @return
	 */
	public static String getCurrentTimestamp() {
		Calendar cal = Calendar.getInstance();
		 
        SimpleDateFormat dateTime = new SimpleDateFormat(timestampFormat);
        System.out.println(dateTime.format(cal.getTime()));
        return dateTime.format(cal.getTime());
	}
	/**
	 * This function formats date into expected format
	 * @param date
	 * @return
	 */
	public static String dateFormatter(Date date) {
		SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
		return formatter.format(date);
	}
	/***
	 * This method writes response into response.log file
	 * @param responseStr
	 * @param responseFile
	 */
	public static void writeResponseToFile(String responseStr, String responseFile) {
		try {
			file = new File(responseFile);
			fop = new FileOutputStream(file, true);

			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			// get the content in bytes
			byte[] contentInBytes = responseStr.getBytes();

			fop.write(contentInBytes);
			fop.flush();
			fop.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fop != null) {
					fop.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static String getFileSeparator() {
		return System.getProperty("file.separator");
	}
	
}
