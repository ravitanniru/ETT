package com.abb.dias.etl.automation.core.file.reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.abb.dias.etl.automation.core.model.TestInputConfig;

public class ExcelReader {
	/**
	 * This method read config data from excel
	 * 
	 * @param filePath
	 * @param fileName
	 * @param sheetName
	 * @return workbook
	 * @throws IOException
	 */

	public static Workbook getWorkBook(String filePath, String fileName) throws IOException {
		File file = new File(filePath + "\\" + fileName);
		FileInputStream inputStream = new FileInputStream(file);
		Workbook workbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if (fileExtensionName.equals(".xlsx")) {
			workbook = new XSSFWorkbook(inputStream);
		}
		else if (fileExtensionName.equals(".xls")) {
			workbook = new HSSFWorkbook(inputStream);
		}
		return workbook;
	}

	/**
	 * Read ETLAutomationConfig from input Excel sheet
	 * 
	 * @return HashMap having ETLAutomationConfig details
	 */
	public static HashMap<String, String> readExcel(Sheet sheet) throws IllegalStateException, Exception {
		HashMap<String, String> etlAutomationConfigHashMap = new HashMap<String, String>();
		int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();
		// Create a loop over all the rows of excel file to read it
		for (int i = 1; i < rowCount + 1; i++) {
			Row row = sheet.getRow(i);
			System.out.print("row Number " + i);
			etlAutomationConfigHashMap.put(getCellData(sheet, 0, i).trim(), getCellData(sheet, 1, i).trim());
			// }
		}
		return etlAutomationConfigHashMap;
	}

	/**
	 * Read ETLAutomationConfig from input Excel sheet
	 * 
	 * @return HashMap having ETLAutomationConfig details
	 */
	public static LinkedHashMap<String, TestInputConfig> readInputData(Sheet sheet) throws IllegalStateException, Exception {
		LinkedHashMap<String, TestInputConfig> testInputConfigHashMap = new LinkedHashMap<String, TestInputConfig>();
		int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();
		System.out.println("rowCount "+rowCount);
		// Create a loop over all the rows of excel file to read it
		for (int i = 1; i < rowCount + 1; i++) {
			TestInputConfig testInputConfig = new TestInputConfig();
			Row row = sheet.getRow(i);

			// Ignore records for those pipelines for which execute pipeline is set to false
			if (Boolean.parseBoolean(getCellData(sheet, 2, i).trim()) == false)
				continue;

			// Create a loop to print cell values in a row
			String pipelineName = "";
			for (int j = 0; j < row.getLastCellNum(); j++) {
				if (j == 0) {
					System.out.println(getCellData(sheet, j, i).trim());
					testInputConfig.setTestCaseId(Integer.parseInt(getCellData(sheet, j, i).trim()));// testCaseId
				} else if (j == 1) {
					testInputConfig.setPipelineName(getCellData(sheet, j, i).trim());// pipelineName
					pipelineName = getCellData(sheet, j, i);
					System.out.println("pipelineName ***"+pipelineName);
				} else if (j == 2)
					testInputConfig.setExecutePipeline(Boolean.parseBoolean(getCellData(sheet, j, i).trim()));// executePipeline
				else if (j == 3)
					testInputConfig.setmonitorAPIDelayInMilliSeconds((Integer.parseInt(getCellData(sheet, j, i).trim())));// monitorAPIDelayInMilliSeconds
				else if (j == 4)
					testInputConfig.setNumRetries(Integer.parseInt(getCellData(sheet, j, i).trim()));// numRetries
				else if (j == 5)
					testInputConfig.setMonitorStatus(getCellData(sheet, j, i).trim());// monitorStatus
				else if (j == 6)
					testInputConfig.setDataValidation(Boolean.parseBoolean(getCellData(sheet, j, i).trim()));// dataValidation
				else if (j == 7)
					testInputConfig.setStagingQuery(getCellData(sheet, j, i).trim());// StagingQuery
				else if (j == 8)
					testInputConfig.setDimensionQuery(getCellData(sheet, j, i).trim());// dimensionQuery
			}
			testInputConfigHashMap.put(pipelineName, testInputConfig);
		}
		return testInputConfigHashMap;
	}

	@SuppressWarnings("deprecation")
	public static String getCellData(Sheet sheet, int colNum, int rowNum) {
		try {
			Row row = sheet.getRow(rowNum);
			Cell cell = row.getCell(colNum);
			//TODO: Remove deprecated methods
			if (cell.getCellTypeEnum() == CellType.STRING)
				return cell.getStringCellValue().trim();
			else if (cell.getCellTypeEnum() == CellType.NUMERIC)
				return String.valueOf(new Double(cell.getNumericCellValue()).intValue());
			else if (cell.getCellTypeEnum() == CellType.BLANK)
				return "";
			else
				return String.valueOf(cell.getBooleanCellValue());
		} catch (Exception e) {
			e.printStackTrace();
			return "row " + rowNum + " or column " + colNum + " does not exist  in Excel";
		}
	}
	
	

}
