package com.abb.dias.etl.automation.core.database;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.abb.dias.etl.automation.core.util.Util;

public class DbConnectionUtil{
	/**
	 * Create database connection
	 * 
	 * @return
	 */
	public static String underScoreDelimiter = "_";
	public static String sqlServerDriverClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	public static Connection getDbConnection(String dbURL) {
		System.out.println("db Url"+dbURL);
		Connection conn = null;
		try {
				System.out.println("Establishing connection");
				Class.forName(sqlServerDriverClass);
				conn = DriverManager.getConnection(dbURL);
				System.out.println("conn "+conn);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return conn;
	}
	
	/**
	 * This method fetches data from db and writes it to an excel file
	 * @param sql
	 * @param tableName
	 * @param pipelineName
	 * @param outPutLoc
	 * @return
	 */

	public static void getActualData(String sql, String tableName, String pipelineName, String outPutLoc, Connection con ) {
		ResultSet rs = null;
		Writer writer = null;
		try {
			String pipelineNameModified = pipelineName.replace(" ", underScoreDelimiter);
			File file = new File(outPutLoc + Util.getFileSeparator() + pipelineNameModified + underScoreDelimiter + tableName + underScoreDelimiter + "actual" + underScoreDelimiter + "icm" + underScoreDelimiter + "data.txt");
			writer = new BufferedWriter(new FileWriter(file));
			
			Statement sta = con.createStatement();
			rs = sta.executeQuery(sql);
 
            DbToTextExport.writeHeaderLine(rs, writer);
 
            DbToTextExport.writeDataLines(rs, writer);
 
            sta.close();
            
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				if (writer != null) {
					writer.close();
				}
				if(rs != null) {
					rs.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
