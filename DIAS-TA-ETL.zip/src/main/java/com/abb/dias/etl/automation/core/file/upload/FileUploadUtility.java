package com.abb.dias.etl.automation.core.file.upload;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.testng.Reporter;

import com.abb.dias.etl.automation.core.util.Util;

public class FileUploadUtility {
	public static String fileSeperator = Util.getFileSeparator();
	final static Logger logger = Logger.getLogger(FileUploadUtility.class.getName());
	public static String baseLocation;

	/***
	 * This method get list of all files under folder
	 * 
	 * @param srcFldrLoc
	 * @return HashMap having key -> folder name, value -> List of all files under
	 *         that folder
	 */
	public static HashMap<String, List<File>> getFilesInDir(String srcFldrLoc) {
		HashMap<String, List<File>> folderMap = new HashMap<>();
		List<File> filesList = new ArrayList<File>();
		baseLocation = srcFldrLoc;
		return listFiles(srcFldrLoc, folderMap
				,filesList);//Directory target Location is root
	}
	/**
	 * This methos gets HashMap having file name 
	 * @param srcFldrLoc
	 * @param folderMap
	 * @param filesList
	 * @return
	 */

	public static HashMap<String, List<File>> listFiles(String srcFldrLoc, HashMap<String, List<File>> folderMap,
			 List<File> filesList) {
		File directory = new File(srcFldrLoc);
		// Get all files from a directory.
		File[] fList = directory.listFiles();
		if (fList != null)
			for (File file : fList) {
				if (file.isFile()) { 
					filesList.add(new File(file.getAbsolutePath()));
					folderMap.put(getDirName(srcFldrLoc, file), filesList);
				} else if (file.isDirectory()) {
					listFiles(srcFldrLoc + fileSeperator + file.getName(), folderMap,
							new ArrayList<File>());
				}
			}
		return folderMap;
	}
	
	/**
	 * This method returns directory name for uploading to CDL
	 * @param srcFldrLoc
	 * @param file
	 * @return
	 */
	public static String getDirName(String srcFldrLoc, File file) {
		int index = baseLocation.lastIndexOf("/");
		String selectedString = baseLocation.substring(index + 1, baseLocation.length());
		return (StringUtils.substringBetween(file.getAbsolutePath(), selectedString, file.getName()).substring(1));
	}
	
}
