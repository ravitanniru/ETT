package com.abb.dias.etl.automation.core.database;

import java.io.Writer;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Date;
import com.abb.dias.etl.automation.core.util.Util;

public class DbToTextExport {
	public static String underScoreDelimiter = "_";
	public static String tildDelimiter = "~";
	public static String newLineCharacter = "\n";
	
	public static void writeHeaderLine(ResultSet result, Writer writer) {
		try {
			// write header line containing column names
			ResultSetMetaData metaData = result.getMetaData();
			int numberOfColumns = metaData.getColumnCount();
			String header = "";
			for (int i = 1; i <= numberOfColumns; i++) {
				String delimiter =tildDelimiter;
				if(i == numberOfColumns)//Skip adding delimiter for last column
					 delimiter = "";
				header += metaData.getColumnName(i) + delimiter;
			}
			writer.write(header);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void writeDataLines(ResultSet result, Writer writer)
			throws SQLException, ClassCastException {
		try {
			ResultSetMetaData metaData = result.getMetaData();
			int numberOfColumns = metaData.getColumnCount();

			while (result.next()) {
				String data = "";
				for (int i = 1; i <= numberOfColumns; i++) {
					Object valueObject = result.getObject(i);
					String delimiter = tildDelimiter;
					if(i == numberOfColumns) {//Skip adding delimiter for last column
						 delimiter = "";
					}
					
					if (valueObject instanceof String) {
						data += ((String) valueObject) + delimiter;
					}  else if (valueObject instanceof Boolean)
						data += ((Boolean) valueObject) + delimiter;
					else if (valueObject instanceof Double)
						data += ((double) valueObject) + delimiter;
					else if (valueObject instanceof Float)
						data += ((float) valueObject) + delimiter;
					else if (valueObject instanceof Date) {
						data += Util.dateFormatter((Date) valueObject) + delimiter;
					} else if (valueObject instanceof BigDecimal) {
						data += ((BigDecimal) valueObject).doubleValue() + delimiter;
					}
					else
						data += delimiter;
				}
				writer.write(newLineCharacter + data);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}